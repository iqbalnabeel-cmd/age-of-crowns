// WHERE IS THE BAR NOW?
//
// The crown-count sweep turned up something bigger than the thing it was built to test. The
// FOUR crown world, the one 48 was tuned on, now reaches a winner in only 2 of 5 games. It used
// to be 12 of 12.
//
// v8.9 did that. The free lords made every city on the map cost a real army and real days, so a
// bar of 48 is no longer "most of the map", it is "more of the map than anyone can finish taking".
// The anchor the scaling formula is built on has moved, so the anchor has to be re-measured
// before the formula means anything.
//
// This sweeps the bar itself at one world size and reports where a game reliably ends.
import * as R from '../server/rules.mjs';

const WORLDS = Number(process.env.WORLDS || 6);
const DAYS   = Number(process.env.DAYS   || 75);
const CROWNS = Number(process.env.CROWNS || 4);
const BARS   = (process.env.BARS || '48,44,40,36,32').split(',').map(Number);
const SEEDS  = [20260912,7771,31337,4242,98765,5150,60613,11235,271828,141421].slice(0,WORLDS);

const KEYS = Object.keys(R.EMPIRES);
function seed(n){let s=n>>>0;Math.random=function(){s=(s*1664525+1013904223)>>>0;return s/4294967296;};}
function crownsFor(n,sd){
  // A seeded shuffle, so "6 crowns" means six crowns drawn from the eight rather than always the
  // same six. Playing the first n in list order made 3 crowns mean "three neighbours in western
  // Europe" and 6 mean "a thin chain from Britain to Mongolia", which measures geography, not size.
  let s=(sd^0x9e3779b9)>>>0;
  const rnd=()=>{s=(s*1664525+1013904223)>>>0;return s/4294967296;};
  const a=KEYS.slice();
  for(let i=a.length-1;i>0;i--){const j=Math.floor(rnd()*(i+1));[a[i],a[j]]=[a[j],a[i]];}
  return a.slice(0,n);
}

function play(bar,sd){
  const line=crownsFor(CROWNS,sd);
  seed(sd);
  R.newGame(line[0],line.slice(1),'norm');
  const G=R.getG();
  G.rate=0; G.need=bar; G.player='nobody';
  for(const k in G.emp)G.emp[k].ai=true;
  for(let d=1;d<=DAYS;d++){
    R.advanceClock(24);
    if(R.getG().over)return {won:true,day:d};
  }
  const H=R.getG();
  return {won:false,day:null,best:Math.max(...Object.keys(H.emp).map(k=>R.provsOf(k).length))};
}

const free=Object.keys(R.MAPD5.provs).length-CROWNS*R.HOME_CITIES;
console.log('WHERE THE BAR LANDS   ('+CROWNS+' crowns, '+free+' free cities, '+SEEDS.length+' worlds, '+DAYS+' day limit)');
console.log('');
console.log('  bar   share of free   reached a winner   median day   range       stalled leaders');
for(const bar of BARS){
  const runs=SEEDS.map(sd=>play(bar,sd));
  const won=runs.filter(r=>r.won);
  const days=won.map(r=>r.day).sort((a,b)=>a-b);
  const med=days.length?days[Math.floor(days.length/2)]:null;
  const share=((bar-R.HOME_CITIES)/free);
  const stalled=runs.filter(r=>!r.won).map(r=>r.best);
  console.log('  '+String(bar).padStart(3)+'       '+share.toFixed(2)+'          '+
    (won.length+'/'+runs.length).padStart(8)+'         '+
    String(med===null?'never':med).padStart(5)+'      '+
    (days.length?(days[0]+' to '+days[days.length-1]).padEnd(10):'-'.padEnd(10))+
    '  '+(stalled.length?stalled.join(', '):'none'));
}
console.log('');
console.log('  Pick the lowest bar that finishes nearly every world inside the limit, then read');
console.log('  its share of free cities. That share becomes WINLINE_FREE_SHARE and the formula');
console.log('  carries it to every other world size.');

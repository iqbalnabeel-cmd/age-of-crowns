// CAN THE WORLD BE WON AT EVERY SIZE?
//
// 48 of 80 was measured and tuned on a FOUR crown world. Nobody ever checked it anywhere else,
// and the number of crowns decides how much of the map is free to take: 3 crowns leaves 62 free
// cities, 8 leaves only 32. Against a fixed bar of 48 you need 42 cities beyond your own, so at
// four crowns there are just enough free ones and at eight there are ten too few.
//
// Measured before v8.9: four crowns reached a winner in 12 of 12 games, EIGHT IN 5 OF 14. The
// eight crown world was not harder. It was unfinishable.
//
// This harness asks one question at every world size: does a game end, and when. It runs both
// bars so the change is evidence rather than opinion:
//   FIXED   the old 48 at every size
//   SCALED  winLineFor(n), anchored so four crowns still comes out at exactly 48
//
// Nobody sits in the player's chair and every crown is played by the same brain, which is the
// only honest way to ask whether a world is winnable at all.
import * as R from '../server/rules.mjs';

const WORLDS = Number(process.env.WORLDS || 8);
const DAYS   = Number(process.env.DAYS   || 90);
const SIZES  = (process.env.SIZES || '3,4,6,8').split(',').map(Number);
const SEEDS  = [20260912,7771,31337,4242,98765,5150,60613,11235,271828,141421,86420,13579].slice(0,WORLDS);

const KEYS = Object.keys(R.EMPIRES);
function seed(n){let s=n>>>0;Math.random=function(){s=(s*1664525+1013904223)>>>0;return s/4294967296;};}
function crownsFor(n,sd){
  // A seeded shuffle, so "6 crowns" means six crowns drawn from the eight rather than always the
  // same six. Playing the first n in list order made 3 crowns mean "three neighbours in western
  // Europe" and 6 mean "a thin chain from Britain to Mongolia", which measures geography, not size.
  let s=(sd^0x9e3779b9)>>>0;
  const rnd=()=>{s=(s*1664525+1013904223)>>>0;return s/4294967296;};
  const a=KEYS.slice();
  for(let i=a.length-1;i>0;i--){const j=Math.floor(rnd()*(i+1));[a[i],a[j]]=[a[j],a[i]];}
  return a.slice(0,n);
}

function play(crowns,bar,sd){
  const line=crownsFor(crowns,sd);
  seed(sd);
  R.newGame(line[0],line.slice(1),'norm');
  const G=R.getG();
  G.rate=0;
  G.need=bar;                       // the bar under test
  G.player='nobody';                // nobody is protected and the brain plays every seat
  for(const k in G.emp)G.emp[k].ai=true;
  for(let d=1;d<=DAYS;d++){
    R.advanceClock(24);
    if(R.getG().over)return {won:true,day:d,best:topHeld()};
  }
  return {won:false,day:null,best:topHeld()};
}
function topHeld(){
  const G=R.getG();
  return Math.max(...Object.keys(G.emp).map(k=>R.provsOf(k).length));
}

const rows=[];
for(const n of SIZES){
  const free=Object.keys(R.MAPD5.provs).length-n*R.HOME_CITIES;
  for(const [label,bar] of [['FIXED',R.NEED5],['SCALED',R.winLineFor(n)]]){
    const runs=SEEDS.map(sd=>play(n,bar,sd));
    const won=runs.filter(r=>r.won);
    const days=won.map(r=>r.day).sort((a,b)=>a-b);
    rows.push({n,label,bar,free,
      won:won.length,of:runs.length,
      med:days.length?days[Math.floor(days.length/2)]:null,
      lo:days[0]||null, hi:days[days.length-1]||null,
      stalled:runs.filter(r=>!r.won).map(r=>r.best)});
  }
}

console.log('CAN THE WORLD BE WON?   ('+SEEDS.length+' worlds each, '+DAYS+' day limit, nobody in your chair)');
console.log('');
console.log('  crowns  free  bar  rule     reached a winner   median day   range');
let prev=null;
for(const r of rows){
  if(prev!==null&&prev!==r.n)console.log('');
  prev=r.n;
  const rate=r.won+'/'+r.of;
  console.log('    '+String(r.n).padStart(2)+'    '+String(r.free).padStart(4)+'  '+String(r.bar).padStart(3)+
    '  '+r.label.padEnd(7)+'  '+rate.padStart(10)+'        '+
    String(r.med===null?'never':r.med).padStart(5)+'       '+
    (r.lo===null?'-':r.lo+' to '+r.hi));
  if(!r.won&&r.stalled.length)console.log('              stalled with the leader on '+r.stalled.join(', ')+' cities, bar was '+r.bar);
}

// The claims this harness exists to test. The premise was that 48 is wrong at the big world
// sizes; the sweep (tools/v90-barsweep.mjs) then showed it had also stopped working at four,
// because v8.9's free lords moved the anchor. So the bar under test must beat 48 EVERYWHERE,
// not just at eight crowns.
let fails=0;
const ok=(c,m)=>{console.log((c?'  PASS  ':'  FAIL  ')+m);if(!c)fails++;};
console.log('');
const scaled=rows.filter(r=>r.label==='SCALED');
const fixed=rows.filter(r=>r.label==='FIXED');
const rate=r=>r.won/r.of;
const worstScaled=scaled.reduce((w,r)=>rate(r)<rate(w)?r:w,scaled[0]);
const worstFixed=fixed.reduce((w,r)=>rate(r)<rate(w)?r:w,fixed[0]);
ok(scaled.every(r=>rate(r)>=0.6),
   'the measured bar reaches a winner in most worlds at EVERY size (worst: '+worstScaled.n+' crowns, '+worstScaled.won+'/'+worstScaled.of+')');
ok(rate(worstFixed) < rate(worstScaled),
   'and it beats the old fixed 48, whose worst size is '+worstFixed.n+' crowns at '+worstFixed.won+'/'+worstFixed.of);
// The eight crown world is the one Nabeel parked. It has to be the clearest win of the lot.
const eightF=rows.find(r=>r.n===8&&r.label==='FIXED'), eightS=rows.find(r=>r.n===8&&r.label==='SCALED');
if(eightF&&eightS)ok(rate(eightS)>rate(eightF),
   'the eight crown world goes from '+eightF.won+'/'+eightF.of+' at bar '+eightF.bar+' to '+eightS.won+'/'+eightS.of+' at bar '+eightS.bar);
// A bar nobody can reach is one failure mode; a bar you trip over is the other.
const meds=scaled.filter(r=>r.med!==null).map(r=>r.med);
ok(meds.length<2||Math.min(...meds)>=20,
   'and no size is won so fast it is not a war (quickest median '+Math.min(...meds)+' days)');
ok(meds.length<2||Math.max(...meds)-Math.min(...meds)<=30,
   'a game takes a similar time at every size (median '+Math.min(...meds)+' to '+Math.max(...meds)+' days)');

console.log('\n'+(fails?fails+' RED':'ALL GREEN'));
process.exit(fails?1:0);

// THE SAFETY NET.
//
// The original suite was 63 harnesses and it died with the sandbox, twice. This is not a
// replacement for all of it. It is the set of things that, if any one of them broke, would make
// the game wrong in a way a play-test might not notice for a week: the rulings Nabeel gave, the
// save format that is also the multiplayer wire format, and the numbers that were measured.
//
// Everything here runs in node against server/rules.mjs, which is the same code the server runs.
import * as R from '../server/rules.mjs';

let fails=0;
const ok=(c,m)=>{console.log((c?'  PASS  ':'  FAIL  ')+m);if(!c)fails++;};
function seed(n){let s=n>>>0;Math.random=function(){s=(s*1664525+1013904223)>>>0;return s/4294967296;};}
function fresh(me,rivals,diff){seed(20260912);R.newGame(me||'abb',rivals||['byz','fra','mon'],diff||'norm');const G=R.getG();G.rate=0;return G;}
const CITIES=Object.keys(R.MAPD5.provs).length;
const CELLKEYS=Object.keys(R.MAPD5.cells).sort();

console.log('1. A WORLD OPENS IN ONE PIECE');
{
  const G=fresh();
  ok(Object.keys(R.MAPD5.cells).length===367,'367 cells');
  ok(CITIES===80,'80 cities');
  ok(Object.keys(G.emp).length===4,'four crowns');
  ok(R.provsOf('abb').length===6,'you start with six cities');
  ok(G.t===0&&R.gameDay()===1,'and it is the morning of day one');
}

console.log('\n2. THE CLOCK RUNS A FULL WAR WITHOUT THROWING');
{
  fresh();
  let err=null;
  try{ for(let d=0;d<45;d++){ R.advanceClock(24); if(R.getG().over)break; } }catch(e){ err=e; }
  ok(!err,'45 days of war, no exception'+(err?': '+err.message:''));
  const H=R.getG();
  ok(H.t>0,'the clock moved ('+Math.round(H.t/24)+' days)');
  const ghost=Object.keys(H.armies).filter(c=>!R.MAPD5.cells[c]);
  ok(ghost.length===0,'no army stands on a cell that does not exist'+(ghost.length?': '+ghost.slice(0,3):''));
  const badCol=Object.keys(H.col||{}).filter(id=>!/^m\d+$/.test(id));
  ok(badCol.length===0,'every column id is still m-prefixed, so it cannot collide with a cell id');
}

console.log('\n3. NO CROWN DECLARES ON YOU FIRST  (Nabeel\'s ruling, v8.5)');
{
  fresh();
  let broken=null;
  for(let d=0;d<30&&!broken;d++){
    R.advanceClock(24);
    const H=R.getG();
    for(const k in H.emp){ if(k===H.player)continue; if(R.atWar(k,H.player))broken='day '+R.gameDay()+': '+k; }
    if(H.over)break;
  }
  ok(!broken,'thirty days and nobody drew on you'+(broken?': '+broken:''));
}

console.log('\n4. THE SAVE IS ALSO THE WIRE, SO IT HAS TO BE EXACT');
{
  const snap=g=>JSON.stringify({
    t:Math.round(g.t*1000), turn:g.turn, player:g.player, over:!!g.over, need:g.need,
    // Read every map through a FIXED, sorted key list. A fresh world inserts cells as
    // c0,c1,c2... and an unpacked one as c0,c1,c10,c100..., so joining values in dictionary
    // order compares iteration order and not ownership. That looked exactly like a broken
    // save format and was not one. Third time a harness in this project has measured the
    // wrong thing; it is always worth asking before believing a red.
    cells:CELLKEYS.map(c=>g.cellOwner[c]||'-').join(''),
    armies:Object.keys(g.armies).sort().map(c=>c+':'+g.armies[c].e+':'+R.cnt(g.armies[c].u)).join(','),
    cols:Object.keys(g.col||{}).sort().map(i=>i+':'+g.col[i].to+':'+(g.col[i].no||'')+(g.col[i].ty||'')).join(','),
    gold:Object.keys(g.emp).sort().map(k=>k+':'+Math.round(g.emp[k].gold)).join(',')
  });
  for(const days of [0,3,9,20]){
    fresh();
    if(days)R.advanceClock(24*days);
    const before=snap(R.getG());
    const code=await R.makeSaveCode();
    // setG is the load. readSaveCode RETURNS the world and does not install it, so a harness
    // that calls it and then reads getG() is comparing the world to itself and passes whatever
    // happens. That is what this test did for four builds. The real path is net.js line 65 and
    // worker.js line 75: setG(unpackSave(...)).
    R.setG(await R.readSaveCode(code));
    ok(before===snap(R.getG()),'day '+String(days).padStart(2)+': the world survives the round trip exactly ('+(code.length/1024).toFixed(2)+'KB on the wire)');
  }
  // v9.0: an OLD code has no bar in it and must come back as the 48 it was played under, never
  // as this build's 30. A world that quietly lowers its own win line on reload is a world that
  // announces a winner who had not won.
  fresh();
  const S=R.packSave();
  delete S.nd;
  R.setG(R.unpackSave(S));
  ok(R.getG().need===R.NEED5,'a pre-v9.0 save reloads with its own bar of '+R.NEED5+', not this build\'s '+R.WINLINE);
}

console.log('\n5. THE WIN LINE  (v9.0)');
{
  // The bar was measured, so the thing to guard is that it is the measured number, that it is a
  // property of the world rather than a constant, and that it never asks for more than the map
  // has on it.
  ok(R.WINLINE===30,'the bar is the measured 30 of '+CITIES);
  const G=fresh();
  ok(G.need===R.winLineFor(4),'a new world carries its own bar ('+G.need+')');
  for(const n of [2,3,4,5,6,7,8]){
    const free=CITIES-n*R.HOME_CITIES;
    const bar=R.winLineFor(n);
    if(bar>free+R.WINLINE_FREE_MARGIN){ ok(false,n+' crowns: bar '+bar+' asks for more than the '+free+' free cities plus the margin'); }
  }
  ok(true,'and at no world size does it exceed what starts free (2 to 8 crowns all give '+R.winLineFor(8)+')');
  // every crown really does start with HOME_CITIES, which the whole rail is built on
  const starts=Object.keys(R.EMPIRES).map(k=>{seed(7);R.newGame(k,[Object.keys(R.EMPIRES).find(x=>x!==k)],'norm');return R.provsOf(k).length;});
  ok(starts.every(n=>n===R.HOME_CITIES),'every crown starts with exactly HOME_CITIES ('+R.HOME_CITIES+'): '+starts.join(','));
  // and the bar is what actually ends a game, not NEED5 hiding somewhere
  seed(99); R.newGame('abb',['byz'],'norm');
  const H=R.getG(); H.rate=0; H.need=R.provsOf('abb').length+1;
  const target=Object.keys(R.MAPD5.provs).find(p=>R.ownerOf(p)==='neutral');
  R.getG().cellOwner[R.provOf(target).citycell]='abb';
  R.checkWin('abb');
  ok(R.getG().over,'reaching the stored bar ends the game, whatever NEED5 says');
}

console.log('\n6. THE FREE LORDS  (v8.9)');
{
  const G=fresh();
  const free=Object.keys(R.MAPD5.provs).filter(p=>R.ownerOf(p)==='neutral');
  ok(free.length>=50,free.length+' free cities on the map');
  ok(free.every(p=>R.bldLv(p,'walls')>=1),'every one of them has walls on the first morning');
  const thin=free.filter(p=>{const a=G.armies[R.provOf(p).citycell];return !a||R.cnt(a.u)<7;});
  ok(thin.length===0,'and none is a walk-in'+(thin.length?' ('+thin.length+' under 7 men)':''));
  const tiered=new Set();
  for(const c in G.armies){ if(G.armies[c].e!=='neutral')continue;
    for(const t in G.armies[c].u)if(R.UNITS[t].tier>1)tiered.add(t); }
  ok(tiered.size===0,'a free lord never fields anything above tier 1, so he can hold and never march');
  const field=Object.keys(G.armies).filter(c=>G.armies[c].e==='neutral'&&!R.MAPD5.cells[c].city);
  ok(field.length>100,field.length+' levies hold the open country between the free cities');
  const taken=field[0];
  G.cellOwner[taken]='abb'; delete G.armies[taken];
  R.advanceClock(24*5);
  ok(R.cellOwnerOf(taken)!=='neutral'||!R.getG().armies[taken],'ground taken off a free lord grows no new levy behind you');
}

console.log('\n7. OUTRIDERS SEE AND NEVER TAKE  (Nabeel\'s ruling, v8.5)');
{
  const G=fresh();
  const home=R.CITYCELL['mes0'];
  const out=(R.moveAdj(home)||[]).find(c=>R.cellOwnerOf(c)!=='abb'&&!G.armies[c]);
  if(!out){ ok(true,'skipped: no empty neighbour to ride into'); }
  else{
    // the unit key is `scout`. `outrider` is not a unit, and a harness using it silently tests
    // nothing, because scoutOnly() then returns false for an unknown key.
    R.placeArmy(home,'abb',{scout:4},0,0);
    R.departColumn(home,out,{scout:4},'abb');
    for(let i=0;i<40;i++)R.advanceClock(0.25);
    ok(R.cellOwnerOf(out)!=='abb','a force of nothing but riders took no ground');
  }
}

console.log('\n8. THE MAP STILL SAYS WHERE IT IS  (v8.8a)');
{
  fresh();
  const cells=Object.keys(R.MAPD5.cells);
  const names=cells.map(c=>R.landName(c));
  ok(names.every(n=>n&&n!=='open country'),'all '+cells.length+' cells are named');
  const dup={};names.forEach(n=>dup[n]=(dup[n]||0)+1);
  ok(Object.keys(dup).filter(n=>dup[n]>1).length===0,'and no two share a name');
  let exact=0,nextDoor=0;const stray=[];
  for(const cid in R.MAPD5.cells){
    if(R.MAPD5.cells[cid].city)continue;
    const e=R.LANDNAMES[cid]; if(!e)continue;
    const px=R.MAPPROJ.mx*e[1]+R.MAPPROJ.cx, py=R.MAPPROJ.my*e[2]+R.MAPPROJ.cy;
    let best=null,bd=Infinity;
    for(const oc in R.MAPD5.cells){const c=R.MAPD5.cells[oc];const d=Math.hypot(c.x-px,c.y-py);if(d<bd){bd=d;best=oc;}}
    if(best===cid)exact++; else if((R.moveAdj(cid)||[]).includes(best))nextDoor++; else stray.push(e[0]+' lands on '+R.landName(best));
  }
  console.log('        lands on its own cell '+exact+', next door '+nextDoor+', elsewhere '+stray.length);
  ok(stray.length===0,'no name belongs somewhere else entirely'+(stray.length?': '+stray.slice(0,3).join(', '):''));
  ok(exact>=250,exact+' of 287 land exactly on the cell they name');
  ok(Object.values(R.LANDNAMES).every(e=>e[0]!=='Fustat'&&e[0]!=='Karkh'),'Fustat and Karkh are not listed apart from the cities they are part of');
}

console.log('\n9. A WAR STILL ENDS, AT EVERY WORLD SIZE');
{
  // If nothing can be taken the change went too far and the game is a stalemate with scenery.
  // The lineup is shuffled per world: playing the first n empires in list order measures
  // geography and calls it size, which is how the v9.0 sweep first went wrong.
  const KEYS=Object.keys(R.EMPIRES);
  const lineup=(n,sd)=>{let s=(sd^0x9e3779b9)>>>0;const rnd=()=>{s=(s*1664525+1013904223)>>>0;return s/4294967296;};
    const a=KEYS.slice();for(let i=a.length-1;i>0;i--){const j=Math.floor(rnd()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a.slice(0,n);};
  for(const n of [4,8]){
    let ended=0;const tried=[20260912,7771,31337];
    for(const sd of tried){
      const line=lineup(n,sd);
      seed(sd); R.newGame(line[0],line.slice(1),'norm');
      const G=R.getG(); G.rate=0; G.player='nobody';
      for(const k in G.emp)G.emp[k].ai=true;
      for(let d=0;d<90;d++){ R.advanceClock(24); if(R.getG().over){ended++;break;} }
    }
    ok(ended>=2,n+' crowns: '+ended+' of '+tried.length+' worlds reach a winner inside 90 days (bar '+R.winLineFor(n)+')');
  }
}

console.log('\n'+(fails?fails+' RED':'ALL GREEN'));
process.exit(fails?1:0);

// THE MAP HALF of v9.0. The rules half is tools/regress.mjs and tools/v90-winline.mjs.
//
// The bar moved from 48 to 30 and stopped being a constant. Three places in the interface used to
// carry 48: the header markup, the Standings footer, and the help text. A number baked into
// markup is a number that lies the moment the rule behind it changes, and the header one was
// literally written into the HTML by hand.
//
// What this has to prove:
//   1. the game starts and reports itself as v9.0
//   2. the header quotes the bar THIS world is played under, read from the world
//   3. the Standings screen says it too, with the real city total
//   4. the help text no longer promises 48
//   5. an old save loaded into this build keeps its own bar of 48 and the header says 48
//   6. it all still fits on a phone
const {chromium}=require('playwright');
const FILE=process.argv[2]||'/home/claude/age-of-crowns/aoc-v6.html';
let fails=0;
const ok=(c,m)=>{console.log((c?'  PASS  ':'  FAIL  ')+m);if(!c)fails++;};

(async()=>{
  const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
  const p=await b.newPage({viewport:{width:390,height:844},isMobile:true,hasTouch:true});
  const errs=[];p.on('pageerror',e=>errs.push(e.message));
  await p.goto('file://'+FILE);
  await p.waitForTimeout(500);
  await p.evaluate(()=>{
    let s=20260912;Math.random=function(){s=(s*1664525+1013904223)>>>0;return s/4294967296;};
    selEmpire='abb';selRivals.clear();['byz','fra','mon'].forEach(k=>selRivals.add(k));selDiff='norm';
    refreshStart();
  });
  await p.evaluate(()=>document.getElementById('startBtn').onclick());
  await p.waitForTimeout(1400);
  await p.evaluate(()=>{G.rate=0;closeDrawer(true);});

  console.log('1. THE WORLD STARTS AND KNOWS ITS OWN BAR');
  {
    const r=await p.evaluate(()=>({
      ver:GAME_VERSION, need:G.need, says:needToWin(),
      total:Object.keys(MAPD5.provs).length,
      hNeed:document.getElementById('hNeed').textContent,
      hTotal:document.getElementById('hTotal').textContent
    }));
    console.log('        '+r.ver+': bar '+r.need+' of '+r.total+', header reads '+r.hNeed+' of '+r.hTotal);
    ok(r.ver==='v9.0','the file reports itself as v9.0');
    ok(r.need===30,'a fresh four crown world is played to 30');
    ok(r.hNeed===String(r.need),'the header quotes the world\'s own bar, not a number in the markup');
    ok(r.hTotal===String(r.total),'and the real city total');
  }

  console.log('\n2. THE STANDINGS SCREEN SAYS IT TOO');
  {
    const r=await p.evaluate(()=>{
      showStandings();
      const t=document.getElementById('mBody').textContent.replace(/\s+/g,' ');
      return {t,need:needToWin()};
    });
    ok(new RegExp('hold\\s*'+r.need+'\\b','i').test(r.t),'Standings says "hold '+r.need+'": '+(r.t.match(/First to hold[^.]*\./)||['not found'])[0]);
    ok(!/\b48\b/.test(r.t),'and 48 appears nowhere on it');
    await p.evaluate(()=>closeModal());
  }

  console.log('\n3. THE HELP NO LONGER PROMISES 48');
  {
    const r=await p.evaluate(()=>({has48:/48 of the 80/.test(HELP_HTML),has30:/30 of the 80/.test(HELP_HTML)}));
    ok(!r.has48,'the help text does not still say 48 of the 80 cities');
    ok(r.has30,'it says 30, and explains why that is not modest');
  }

  console.log('\n4. AN OLD SAVE KEEPS ITS OWN BAR');
  {
    // The one thing that must never happen: a world saved under 48 reloading at 30 and announcing
    // a winner who had not won. The bar travels with the world, not with the build.
    const r=await p.evaluate(async()=>{
      const code=await makeSaveCode();
      const S=packSave(); delete S.nd;          // what a pre-v9.0 code looks like
      setG(unpackSave(S));
      renderHdr();            // the one function that writes the header from the world
      return {need:G.need,header:document.getElementById('hNeed').textContent};
    });
    console.log('        loaded a bar-less save: G.need '+r.need+', header '+r.header);
    ok(r.need===48,'a pre-v9.0 world reloads at 48, the bar it was played under');
    ok(r.header==='48','and the header follows it rather than showing this build\'s 30');
  }

  console.log('\n5. AND IT ALL STILL FITS ON A PHONE');
  {
    const r=await p.evaluate(()=>{
      showStandings();
      const pn=document.getElementById('mBody');
      const tiny=[...pn.querySelectorAll('*')].filter(el=>{
        const t=(el.textContent||'').trim();
        if(!t||el.children.length)return false;
        return parseFloat(getComputedStyle(el).fontSize)<11;
      }).length;
      const wide=pn.scrollWidth>pn.clientWidth+2;
      const hdr=document.getElementById('hdr');
      return {tiny,wide,w:pn.clientWidth,hdrWide:hdr?hdr.scrollWidth>hdr.clientWidth+2:false};
    });
    ok(!r.wide,'the Standings screen does not overflow sideways at '+r.w+'px');
    ok(r.tiny===0,'and nothing on it is under 11px ('+r.tiny+' found)');
    console.log('        the header scrolls sideways by design: '+r.hdrWide);
  }

  ok(errs.length===0,'no script errors'+(errs.length?': '+errs[0]:''));
  await b.close();
  console.log('\n'+(fails?fails+' RED':'ALL GREEN'));
  process.exit(fails?1:0);
})();

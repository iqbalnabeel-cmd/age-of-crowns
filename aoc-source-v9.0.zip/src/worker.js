// ==================== v7.9: THE WORLD SERVER — no browser, ever ====================
// build.mjs staples data.js + rules.js + orders.js + this file together into one worker.js at the
// repo root. One file, because Nabeel uploads to GitHub by hand from a phone and two files are a
// great deal easier than five.

// ---- the world ----
// ==================== v7.9: one shared world ====================
// A Durable Object is a single object with its own storage that Cloudflare guarantees exists in
// exactly one place at a time. That is precisely what a game world is: one authoritative copy of
// G, one clock, and every player talking to it.
//
// The design has one idea behind it. The save format is already a complete, tiny description of a
// world (about 1.6KB packed for a game in full flow), and it is already tested to round-trip
// exactly. So the save code IS the wire format, the storage format and the protocol. Nothing new
// had to be invented to send a world down a wire.
//
// The rules run here unchanged. That was the whole point of keeping data.js and rules.js clean of
// the browser for the last eight builds.


const TICK_MS   = 15000;     // how often the world moves on its own
const MAX_IDLE_H = 72;       // a world nobody has touched for three days stops advancing
// v8.6: a shared world holds every crown, so the only seat limit left is how many there are. The
// old SEATS_MIN/SEATS_MAX governed the host's rival picker, which no longer decides anything
// online. EMPIRE_KEYS comes from the rules, so adding an empire adds a seat and nothing here has
// to be told about it.
const EMPIRE_KEYS = Object.keys(EMPIRES);
// v8.0: a world waits in the lobby until somebody begins it. Before that its clock does not move
// at all, so a friend who joins twenty minutes late is not born twenty minutes behind. The host
// begins it; anyone in it may begin it once the world is this old, so a host who wanders off
// cannot strand everybody else in a waiting room for ever.
const AUTO_BEGIN_H = 1;

const json = (o, status) => new Response(JSON.stringify(o), {
  status: status || 200,
  headers: {'content-type':'application/json','access-control-allow-origin':'*'}
});

function token(){
  const b = new Uint8Array(16);
  crypto.getRandomValues(b);
  return [...b].map(x => x.toString(16).padStart(2,'0')).join('');
}

export class World {
  constructor(state, env){
    this.state = state;
    this.env = env;
    this.sockets = new Set();
    this.loaded = null;                      // {save, meta} once read from storage
  }

  // ---- storage ----------------------------------------------------------
  async load(){
    if(this.loaded) return this.loaded;
    const [save, meta] = await Promise.all([
      this.state.storage.get('save'),
      this.state.storage.get('meta')
    ]);
    this.loaded = save ? {save, meta: meta || {}} : null;
    return this.loaded;
  }

  // Persist what is already in this.loaded, and do NOT repack. `withWorld` is the only thing that
  // may write this.loaded.save, because it is the only thing that knows G is this world's. This
  // used to call packSave() itself, which quietly packed whichever world happened to be in front
  // of the rules at the time.
  async save(){
    await this.state.storage.put({save: this.loaded.save, meta: this.loaded.meta});
  }

  // Put this world's G in front of the rules and keep it there for the whole of `fn`. Nothing in
  // here may await, or another world could be swapped in underneath it.
  withWorld(fn){
    setG(unpackSave(this.loaded.save));
    const out = fn();
    this.loaded.save = packSave();
    return out;
  }

  // ---- the clock --------------------------------------------------------
  // The world advances by however much REAL time has passed, times the rate the world was created
  // with. That means it keeps running whether anyone is watching or not, and a player who closes
  // the tab and comes back tomorrow finds the war has moved on.
  advance(now){
    const m = this.loaded.meta;
    // Still in the lobby. Hold the clock at zero and keep the mark moving with real time, so the
    // wait itself is never played out the moment somebody presses Begin.
    if(!m.started){ m.tickedAt = now; return false; }
    const last = m.tickedAt || now;
    let hours = (now - last) / 3600000 * (m.rate || 1);
    const idleH = (now - (m.touchedAt || now)) / 3600000;
    if(idleH > MAX_IDLE_H) hours = 0;              // nobody has played in three days: hold it
    m.tickedAt = now;
    if(hours <= 0) return false;
    this.withWorld(() => { try{ advanceClock(Math.min(hours, 24 * 30)); }catch(e){} });
    return true;
  }

  // ---- what a client is told -------------------------------------------
  snapshot(){
    const m = this.loaded.meta;
    let head = {};
    this.withWorld(() => {
      head = {
        day: gameDay(),
        hours: Math.round((getG().t || 0) * 100) / 100,
        over: !!getG().over,
        outcome: getG().outcome || null,
        // v8.0: the crowns nobody has taken, so the lobby can show what is still on offer rather
        // than making a joiner guess and be handed whatever is left.
        free: Object.keys(getG().emp).filter(k => !m.seats[k] && getG().emp[k].alive)
                    .map(k => ({k, name: empName(k)})),
        standings: Object.keys(getG().emp).map(k => ({
          k, name: empName(k), cities: provsOf(k).length,
          alive: getG().emp[k].alive, human: !!m.seats[k]
        })).sort((a,b) => b.cities - a.cities)
      };
    });
    return {
      code: m.code, rate: m.rate, created: m.created,
      started: !!m.started, host: m.host || null,
      // Once the world is this old anyone in it may begin it, so the client can stop saying
      // "waiting for the host" and offer the button instead.
      canAnyoneBegin: (Date.now() - (m.created || 0)) / 3600000 >= AUTO_BEGIN_H,
      players: Object.keys(m.seats).map(k => ({empire: k, name: m.seats[k].name})),
      save: this.loaded.save,
      ...head
    };
  }

  broadcast(){
    if(!this.sockets.size) return;
    const msg = JSON.stringify({type:'state', state: this.snapshot()});
    for(const ws of [...this.sockets]){
      try{ ws.send(msg); }catch(e){ this.sockets.delete(ws); }
    }
  }

  async scheduleTick(){
    const at = await this.state.storage.getAlarm();
    if(at === null) await this.state.storage.setAlarm(Date.now() + TICK_MS);
  }

  async alarm(){
    if(!(await this.load())) return;
    const moved = this.advance(Date.now());
    if(moved){ await this.save(); this.broadcast(); }
    const idleH = (Date.now() - (this.loaded.meta.touchedAt || 0)) / 3600000;
    if(idleH < MAX_IDLE_H || this.sockets.size) await this.state.storage.setAlarm(Date.now() + TICK_MS);
  }

  // ---- routes -----------------------------------------------------------
  async fetch(request){
    const url = new URL(request.url);
    const path = url.pathname.replace(/^\/+|\/+$/g, '').split('/').pop();

    if(request.method === 'OPTIONS') return new Response(null, {headers:{
      'access-control-allow-origin':'*','access-control-allow-methods':'GET,POST,OPTIONS',
      'access-control-allow-headers':'content-type'}});

    if(path === 'create') return this.create(request);

    if(!(await this.load())) return json({error:'No such world. Check the code.'}, 404);

    // Any touch keeps the world alive and brings its clock up to date first, so a player never
    // acts on a stale picture.
    this.loaded.meta.touchedAt = Date.now();
    const moved = this.advance(Date.now());

    let out;
    if(path === 'join')       out = await this.join(request);
    else if(path === 'begin') out = await this.begin(request);
    else if(path === 'state') out = await this.stateRoute();
    else if(path === 'order') out = await this.order(request);
    else if(path === 'ws')    return this.socket(request);
    else out = json({error:'Unknown request.'}, 404);

    if(moved) this.broadcast();
    await this.scheduleTick();
    return out;
  }

  async create(request){
    const body = await request.json().catch(() => ({}));
    const code = String(body.code || '').toUpperCase();
    if(await this.load()) return json({error:'That world already exists.'}, 409);

    // v8.6 — EVERY CROWN IS ON THE MAP IN A SHARED WORLD.
    //
    // This used to build the world from the host's rival picker, so a world contained the host plus
    // the two to five crowns the host had chosen, and there was nothing else for a joiner to be.
    // Nabeel's report: the second player is forced to pick one of the two other empires the first
    // user selected. He is right, and the picker was never the thing to fix: choosing your
    // neighbours is a single-player idea. In a shared world you do not get to choose who else may
    // play, only which crown is yours.
    //
    // So an online world always holds all eight. Whoever takes none of them is played by the game,
    // which is what the help has promised since v8.0.
    const empire = EMPIRE_KEYS.includes(String(body.empire)) ? String(body.empire) : 'hre';
    const rivals = EMPIRE_KEYS.filter(k => k !== empire);
    const rate = [1, 60, 600, 3600].includes(Number(body.rate)) ? Number(body.rate) : 1;
    const name = String(body.name || 'Player').slice(0, 24);

    newGame(empire, rivals, ['easy','norm','hard'].includes(body.diff) ? body.diff : 'norm');
    const g = getG();
    g.t = 0; g.rate = 1;                         // the world's own rate lives in meta, not in G
    const tk = token();
    this.loaded = {
      save: packSave(),
      meta: {code, rate, created: Date.now(), tickedAt: Date.now(), touchedAt: Date.now(),
             host: empire, started: false,
             seats: {[empire]: {name, token: tk}}}
    };
    await this.state.storage.put({save: this.loaded.save, meta: this.loaded.meta});
    await this.scheduleTick();
    return json({code, token: tk, empire, state: this.snapshot()});
  }

  async join(request){
    const body = await request.json().catch(() => ({}));
    const name = String(body.name || 'Player').slice(0, 24);
    const m = this.loaded.meta;

    // Coming back to a seat you already hold: same token, same crown.
    if(body.token){
      const mine = Object.keys(m.seats).find(k => m.seats[k].token === body.token);
      if(mine) return json({token: body.token, empire: mine, state: this.snapshot()});
    }

    let want = body.empire && String(body.empire);
    const free = [];
    this.withWorld(() => {
      for(const k in getG().emp) if(!m.seats[k] && getG().emp[k].alive) free.push(k);
    });
    if(!free.length) return json({error:'Every crown in this world is taken.'}, 409);
    if(!want || !free.includes(want)) want = free[0];

    const tk = token();
    m.seats[want] = {name, token: tk};
    await this.save();
    this.broadcast();
    return json({token: tk, empire: want, free, state: this.snapshot()});
  }

  // v8.0: leave the lobby and start the clock. Anyone holding a crown may ask; only the host is
  // answered, until the world is old enough that a vanished host would otherwise strand everybody.
  async begin(request){
    const body = await request.json().catch(() => ({}));
    const m = this.loaded.meta;
    const who = Object.keys(m.seats).find(k => m.seats[k].token === body.token);
    if(!who) return json({error:'You do not hold a crown in this world.'}, 403);
    if(m.started) return json({ok: true, state: this.snapshot()});
    const oldEnough = (Date.now() - (m.created || 0)) / 3600000 >= AUTO_BEGIN_H;
    if(who !== m.host && !oldEnough){
      const hostName = (m.seats[m.host] && m.seats[m.host].name) || 'whoever made this world';
      return json({error: hostName + ' has to begin this world.'}, 403);
    }
    m.started = true;
    m.startedAt = Date.now();
    m.tickedAt  = Date.now();
    await this.save();
    this.broadcast();
    return json({ok: true, state: this.snapshot()});
  }

  async stateRoute(){
    await this.save();
    return json(this.snapshot());
  }

  async order(request){
    const body = await request.json().catch(() => ({}));
    const m = this.loaded.meta;
    const who = Object.keys(m.seats).find(k => m.seats[k].token === body.token);
    if(!who) return json({error:'You do not hold a crown in this world.'}, 403);
    // Nothing happens in the lobby. Without this a host could spend an hour recruiting while
    // everyone else watched a waiting room.
    if(!m.started)
      return json({result: {ok:false, why:'The world has not begun yet.'}, state: this.snapshot()});

    // The ONE place a player's authority is checked. applyOrder is handed the empire the token
    // belongs to, never the one the client claims, so a client cannot move somebody else's army
    // however it is edited.
    let result;
    this.withWorld(() => { result = applyOrder(who, body.order || {}); });
    await this.save();
    this.broadcast();
    return json({result, state: this.snapshot()});
  }

  socket(request){
    if(request.headers.get('Upgrade') !== 'websocket')
      return json({error:'Expected a websocket.'}, 426);
    const pair = new WebSocketPair();
    const [client, server] = Object.values(pair);
    server.accept();
    this.sockets.add(server);
    server.addEventListener('close', () => this.sockets.delete(server));
    server.addEventListener('error', () => this.sockets.delete(server));
    try{ server.send(JSON.stringify({type:'state', state: this.snapshot()})); }catch(e){}
    return new Response(null, {status:101, webSocket: client});
  }
}


// ---- the front door ----
// The front door. Everything real happens inside the World durable object; this only works out
// which world a request is for and hands it over.
//
// A world code is six characters a person can read out loud over the phone. It is not a secret:
// anyone with the code can take a free crown, which is exactly what sharing it is for. What a
// player cannot do is act for a crown they do not hold, and that is checked inside the world
// against a token, not against anything the client says about itself.


const CORS = {
  'access-control-allow-origin': '*',
  'access-control-allow-methods': 'GET,POST,OPTIONS',
  'access-control-allow-headers': 'content-type'
};
const gateJson = (o, s) => new Response(JSON.stringify(o), {
  status: s || 200, headers: {'content-type':'application/json', ...CORS}
});

// No vowels and no 0/O/1/I, so a code cannot spell anything and cannot be misheard.
const ALPHABET = 'BCDFGHJKLMNPQRSTVWXYZ23456789';
function newCode(){
  const b = new Uint8Array(6);
  crypto.getRandomValues(b);
  return [...b].map(x => ALPHABET[x % ALPHABET.length]).join('');
}

export default {
  async fetch(request, env){
    const url = new URL(request.url);
    if(request.method === 'OPTIONS') return new Response(null, {headers: CORS});

    const parts = url.pathname.replace(/^\/+|\/+$/g, '').split('/');
    if(parts[0] !== 'api') return gateJson({error:'Not found. The game itself is on GitHub Pages.'}, 404);

    // POST /api/new  — make a world and hand back its code
    if(parts[1] === 'new' && request.method === 'POST'){
      const body = await request.json().catch(() => ({}));
      const code = newCode();
      const id = env.WORLD.idFromName(code);
      const stub = env.WORLD.get(id);
      const res = await stub.fetch(new Request('https://world/create', {
        method: 'POST',
        headers: {'content-type':'application/json'},
        body: JSON.stringify({...body, code})
      }));
      return new Response(res.body, {status: res.status, headers: {'content-type':'application/json', ...CORS}});
    }

    // /api/<CODE>/<join|state|order|ws>
    const code = String(parts[1] || '').toUpperCase();
    const verb = parts[2] || 'state';
    if(!/^[A-Z0-9]{4,10}$/.test(code)) return gateJson({error:'That is not a world code.'}, 400);
    if(!['join','begin','state','order','ws'].includes(verb)) return gateJson({error:'Unknown request.'}, 404);

    const stub = env.WORLD.get(env.WORLD.idFromName(code));
    return stub.fetch(new Request('https://world/' + verb, {
      method: request.method,
      headers: request.headers,
      body: request.method === 'POST' ? await request.text() : undefined
    }));
  }
};


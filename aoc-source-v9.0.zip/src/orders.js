// ==================== v7.9: ORDERS — the only way to change the world ====================
// Runs on a server. No browser, ever.
//
// Until now the interface reached straight into the rules: buyUnit5 spent the player's gold and
// pushed onto the training queue itself, cellClick called departColumn directly. That is fine when
// the only player is sitting at the keyboard, and impossible the moment a second one is somewhere
// else, because there is no single place that says "is this person allowed to do that".
//
// An order is a small plain object. It says who is giving it and what they want. `applyOrder`
// validates it against the live world and either does it or says why not. The browser calls this,
// and so does the Durable Object holding the shared world, so an order means exactly the same
// thing whichever end runs it. It is also, conveniently, the whole network protocol.
//
// Every order returns {ok:true, ...} or {ok:false, why:'a sentence a player can read'}.

function orderFail(why){return {ok:false,why};}

// The four things every order has to be checked for, in one place, because forgetting one of them
// on a server is how a player takes someone else's army for a walk.
function orderCheck(e){
  if(!G)return orderFail('There is no world yet.');
  if(G.over)return orderFail('The game is over.');
  if(!e||!G.emp[e])return orderFail('That crown is not in this game.');
  if(!G.emp[e].alive)return orderFail('That crown no longer holds anything.');
  return null;
}

function ownArmy(cid,e){
  const a=G.armies[cid];
  if(!a)return null;
  return a.e===e?a:null;
}

// What a player asked to send, clamped to what is actually standing there. A client that asks for
// ten spearmen when six are present gets six, not an error and not ten.
function clampWant(army,want){
  const out={};
  if(!want)return Object.assign({},army.u);
  for(const t in want){
    const n=Math.max(0,Math.min(Math.floor(want[t]||0),army.u[t]||0));
    if(n)out[t]=n;
  }
  return out;
}

const ORDERS={

  // ---- movement ----
  march(e,a){
    const army=ownArmy(a.from,e);
    if(!army)return orderFail('You have no force there.');
    if(!a.to||a.to===a.from)return orderFail('Choose somewhere to march to.');
    if(sealedBorder(a.to,e))return orderFail('You are at peace with the crown that holds it.');
    const want=clampWant(army,a.want);
    if(!cnt(want))return orderFail('Choose at least one unit to send.');
    const path=fullPathTo(a.from,a.to,e);
    if(!path||path.length<2)return orderFail('There is no road from here to there.');
    // v8.1: `wp` is the rest of the route. It is cleaned rather than refused, because a client
    // that sends one nonsense stop should still march the stops that make sense. Only the first
    // leg is checked here; each later one is worked out when the column reaches it, which is the
    // only honest moment in a world where ground changes hands while you are marching across it.
    const id=departColumn(a.from,a.to,want,e,a.wp);
    return id?{ok:true,column:id}:orderFail('They could not set off.');
  },

  halt(e,a){
    const c=G.col&&G.col[a.id];
    if(!c)return orderFail('That column has already halted.');
    if(c.e!==e)return orderFail('That is not your column.');
    return haltColumn(a.id)?{ok:true}:orderFail('It cannot halt here.');
  },

  stop(e,a){
    const army=ownArmy(a.cid,e);
    if(!army)return orderFail('You have no force there.');
    delete army.ord;
    if(army.siege)delete army.siege;
    return {ok:true};
  },

  // ---- war ----
  attack(e,a){
    const army=ownArmy(a.from,e);
    if(!army)return orderFail('You have no force there.');
    const foe=G.armies[a.to];
    const owner=cellOwnerOf(a.to);
    if(!foe&&owner===e)return orderFail('That ground is already yours.');
    const other=foe?foe.e:owner;
    if(other!=='neutral'&&other!==e&&!hostileTo(e,other))
      return orderFail('You are at peace with '+empName(other)+'. Declare war first.');
    const want=clampWant(army,a.want);
    if(!cnt(want))return orderFail('Choose at least one unit to send.');
    const path=fullPathTo(a.from,a.to,e);
    if(!path||path.length<2)return orderFail('There is no road from here to there.');
    const id=departColumn(a.from,a.to,want,e);
    return id?{ok:true,column:id}:orderFail('They could not set off.');
  },

  intercept(e,a){
    const army=ownArmy(a.from,e);
    if(!army)return orderFail('You have no force there.');
    const tg=interceptTargets(a.from,e);
    if(!tg[a.id])return orderFail('That column is out of reach.');
    const want=clampWant(army,a.want);
    if(!cnt(want))return orderFail('Choose at least one unit to send.');
    const force=takeForce5(a.from,want);
    if(!cnt(force))return orderFail('Nobody was free to ride.');
    const rep=intercept5(a.from,a.id,force,e,{dmap:G._takenD,noAnim:1});
    return {ok:true,report:rep};
  },

  siege(e,a){
    const army=ownArmy(a.from,e);
    if(!army)return orderFail('You have no force there.');
    const want=clampWant(army,a.want);
    if(!cnt(want))return orderFail('Choose at least one unit to send.');
    return layStartSiege(a.from,a.to,want,e)?{ok:true}:orderFail('They cannot invest that city from here.');
  },

  liftSiege(e,a){
    const army=ownArmy(a.cid,e);
    if(!army||!army.siege)return orderFail('There is no siege of yours there.');
    liftSiege(a.cid);
    return {ok:true};
  },

  // ---- the sea ----
  cross(e,a){
    const army=ownArmy(a.from,e);
    if(!army)return orderFail('You have no force there.');
    const want=clampWant(army,a.want);
    if(!cnt(want))return orderFail('Choose at least one unit to send.');
    const r=orderCrossing(a.from,a.to,want,e);
    return r?{ok:true}:orderFail('There is no way across from here.');
  },

  // ---- the city ----
  // v7.9: this logic used to live in buyUnit5 in ui.js, which meant a server could not recruit at
  // all. Moved here whole, minus the two lines that repainted the screen.
  // v8.7: `a.q` means the player pressed Queue rather than Recruit. A queued order is accepted
  // whatever the treasury says and waits its turn; a plain one still refuses on the spot when the
  // gold is short, which is what the AI relies on to not spend money it does not have.
  recruit(e,a){
    const t=a.t;
    if(!UNITS[t]&&t!==SHIP_KEY)return orderFail('There is no such unit.');
    if(ownerOf(a.pid)!==e)return orderFail('That city is not yours.');
    const emp=G.emp[e];
    if(t===SHIP_KEY){
      if(!isPort(a.pid))return orderFail('That city has no harbour.');
      if(!a.q&&emp.gold<SHIP.cost)return orderFail('Not enough gold.');
    }else{
      if(!canRecruit(a.pid,t))return orderFail(UNITS[t].name+' need a '+recruitGateText(a.pid,t)+' in this city.');
      if(!a.q&&emp.gold<UNITS[t].cost)return orderFail('Not enough gold.');
      const cap=RECRUIT_CAP+2*bldLv(a.pid,'granary');
      if(!a.q&&recruitedThisTurn(a.pid)>=cap)return orderFail('This city has already mustered '+cap+' recruits today.');
    }
    if(cityQueue(a.pid).length>=QUEUE_MAX)return orderFail('That city already has a full queue.');
    queuePush(a.pid,{k:'u',t});
    pumpQueues();
    return {ok:true};
  },

  cancelRecruit(e,a){
    if(ownerOf(a.pid)!==e)return orderFail('That city is not yours.');
    const q=(G.train&&G.train[a.pid])||[];
    const item=q[a.i];
    if(!item)return orderFail('Nothing is in training there.');
    const cost=item.t===SHIP_KEY?SHIP.cost:UNITS[item.t].cost;
    G.emp[e].gold+=Math.floor(cost/2);              // half back, as it always has been
    q.splice(a.i,1);
    return {ok:true};
  },

  // ---- v8.7: the city queue ----
  // Three orders, and between them they are the whole feature. Note what is NOT here: there is no
  // "pay for a queued item" order, because a queued item is never paid for by anybody pressing
  // anything. pumpQueues does it on the clock, which is what "as soon as the resources are
  // available" has to mean in a world that runs whether you are watching or not.
  queueMove(e,a){
    if(ownerOf(a.pid)!==e)return orderFail('That city is not yours.');
    const q=(G.q&&G.q[a.pid])||[];
    const i=a.i|0, j=i+(a.dir<0?-1:1);
    if(!q[i])return orderFail('Nothing is waiting in that place in the queue.');
    if(j<0||j>=q.length)return orderFail('It is already at the end of the queue.');
    const t=q[i];q[i]=q[j];q[j]=t;
    pumpQueues();                                   // the new front may be affordable at once
    return {ok:true};
  },

  queueDrop(e,a){
    if(ownerOf(a.pid)!==e)return orderFail('That city is not yours.');
    const q=(G.q&&G.q[a.pid])||[];
    if(!q[a.i|0])return orderFail('Nothing is waiting there.');
    q.splice(a.i|0,1);                              // no refund: nothing was ever charged for it
    if(!q.length&&G.q)delete G.q[a.pid];
    pumpQueues();
    return {ok:true};
  },

  queueClear(e,a){
    if(ownerOf(a.pid)!==e)return orderFail('That city is not yours.');
    if(!G.q||!G.q[a.pid])return orderFail('That city has nothing waiting.');
    delete G.q[a.pid];
    return {ok:true};
  },

  // These three all take the one project slot a city has, so they all queue the same way. Without
  // `a.q` they still refuse when the gold is short, exactly as before; with it they wait.
  build(e,a){
    if(ownerOf(a.pid)!==e)return orderFail('That city is not yours.');
    if(!BLD[a.b])return orderFail('There is no such building.');
    if(!canBuildIn(a.pid,e))return orderFail('That cannot be built here right now.');
    if(bldLv(a.pid,a.b)>=BLD[a.b].max)return orderFail('That is already fully built.');
    if(!a.q&&G.emp[e].gold<BLD[a.b].cost[bldLv(a.pid,a.b)])return orderFail('Not enough gold.');
    if(cityQueue(a.pid).length>=QUEUE_MAX)return orderFail('That city already has a full queue.');
    queuePush(a.pid,{k:'b',b:a.b});
    pumpQueues();
    return {ok:true};
  },

  annex(e,a){
    if(ownerOf(a.pid)!==e)return orderFail('That city is not yours.');
    if(isAnnexed(a.pid,e)||isHomeCity(a.pid,e))return orderFail('That city is already part of your realm.');
    if(!a.q&&!canAnnex(a.pid,e))return orderFail('The annexation cannot begin right now.');
    if(!a.q&&G.emp[e].gold<annexCost(a.pid))return orderFail('Not enough gold.');
    if(cityQueue(a.pid).some(x=>x.k==='a'))return orderFail('That annexation is already queued.');
    queuePush(a.pid,{k:'a'});
    pumpQueues();
    return {ok:true};
  },

  road(e,a){
    if(ownerOf(a.pid)!==e)return orderFail('That city is not yours.');
    if(!MAPD5.provs[a.to])return orderFail('There is no such province.');
    if((G.roads||{})[provLinkKey(a.pid,a.to)])return orderFail('That road is already built.');
    if(!a.q&&G.emp[e].gold<ROAD_COST)return orderFail('Not enough gold.');
    if(cityQueue(a.pid).length>=QUEUE_MAX)return orderFail('That city already has a full queue.');
    queuePush(a.pid,{k:'r',np:a.to});
    pumpQueues();
    return {ok:true};
  },

  research(e,a){
    if(!TECH[a.tr])return orderFail('There is no such research.');
    return researchTech(e,a.tr)?{ok:true}:orderFail('You cannot afford that, or it is already at its highest level.');
  },

  // ---- diplomacy ----
  declareWar(e,a){
    if(a.on===e||!G.emp[a.on])return orderFail('There is no such crown.');
    if(atWar(e,a.on))return orderFail('You are already at war with them.');
    declareWar(e,a.on);
    return {ok:true};
  },

  makePeace(e,a){
    if(a.on===e||!G.emp[a.on])return orderFail('There is no such crown.');
    if(!atWar(e,a.on))return orderFail('You are not at war with them.');
    return makePeace(e,a.on,true)?{ok:true}:orderFail('They will not come to terms.');
  }
};

// The one door in. `who` is the empire key the order is being given on behalf of, and the caller
// is responsible for knowing that this really is that player. On a server that means a token; in
// a single-player game it is simply G.player.
function applyOrder(who,order){
  const bad=orderCheck(who);
  if(bad)return bad;
  if(!order||typeof order.type!=='string')return orderFail('That is not an order.');
  const fn=ORDERS[order.type];
  if(!fn)return orderFail('There is no such order: '+order.type);
  try{
    const r=fn(who,order)||orderFail('Nothing happened.');
    if(r.ok)G._orderSeq=(G._orderSeq||0)+1;
    return r;
  }catch(err){
    return orderFail('That order could not be carried out.');
  }
}

function orderTypes(){return Object.keys(ORDERS);}


# Unit art v2 — NOT IN THE BUILD

Nabeel's call, 19 Nov 2026: draw it now, keep it separate, fold it into the build after the v9.1
play test. Nothing in here is referenced by `src/`, so a build is unaffected.

| File | What it is |
| --- | --- |
| `unit-art-v2.mjs` | The shared `<defs>` and the generator that shades the existing art |
| `make-sheet.mjs` | Builds the comparison sheet. `node art/make-sheet.mjs` |
| `unit-sheet.html` | All 23 units, old against new, four empire colours, and map size |

## How it works, and why it was done this way

**It is generated, not redrawn.** 23 units are 7 base figures plus 23 overlays positioned against
those figures. Redrawing a figure by hand moves every overlay on it. So the shaded version runs
over the existing art and adds passes: same paths, same coordinates, nothing can drift.

**Empire colour survives, and that was the hard constraint.** Every body shape is
`fill="currentColor"`. A hand-drawn gradient bakes one empire's colour into the art and silently
breaks the other seven. Instead each coloured shape is drawn a second time filled with
`url(#aocLit)`, a white-to-black gradient at low opacity, which lightens the top-left and darkens
the bottom-right of *whatever colour is underneath*. The `four crowns` column on the sheet is
there to prove it.

**The defs live in the map once.** An SVG id is document-global, so a `<defs>` inside each figure
would put a hundred duplicate ids on a busy map.

## To put it in a build

1. Add `AOC_ART_DEFS` to the map SVG once, near the top.
2. Run `shadeAll(ART)` and `shadeAll(TIERART)` at load, or paste the generated strings into
   `src/data.js` and drop this folder.
3. Decide plate or no plate (see below).

## What the sheet actually shows, honestly

- **The stone plate is the biggest single win.** A figure standing on something reads as standing
  somewhere; a figure on nothing reads as a sticker.
- **Metal improved most.** Catapult arms, trebuchets, the ballista and the bombard gained the most
  from the steel gradient, because they are large flat areas.
- **The shading is real at panel size and slight at map size.** The right-hand column of the sheet
  is the size a unit actually appears at on the map, and at that size very little of this is
  visible. That is worth knowing before spending more on it.
- **The first hand-drawn prototype looked better than any of these**, and the reason is instructive:
  the gain came from REDRAWING (a face, a belt, two separated legs, better proportions), not from
  shading. Generating preserves the old drawing, and the old drawing is the limit.

So the choice after the play test is between keeping this (safe, free, done) and redrawing all 23
by hand (clearly better, days of work, every overlay needs re-aligning).

## What it costs, measured

`node art/bench.js` — times a real `updateMap()` repaint with layout forced, old art against new,
interleaved and taken as medians so machine drift cannot land on whichever ran second.

**Download:** ART + TIERART grow 8,938 bytes to 12,030, plus 1,114 bytes of shared defs added
once. **+4.1KB on a 795KB file, or +0.5%.** Nothing.

**Drawing:** 29% more shapes, and gradient fills instead of flat ones.

| armies on screen | old art | new art | difference |
| --- | --- | --- | --- |
| 20 | 19.4ms | 22.9ms | +3.5ms (+18%) |
| 60 | 21.1ms | 24.7ms | +3.6ms (+17%) |
| 120 | 22.2ms | 26.7ms | +4.5ms (+20%) |

**Read it in proportion.** A full repaint already costs about 20ms and happens on a pan, a zoom
or a clock tick, not every frame. The art is not what makes it 20ms: 367 cells with terrain
hatching, rivers and roads are. The new art adds a fifth to a cost the map already carries.

**The mitigation if it ever matters, and the codebase already has the pattern.** Land labels are
drawn only below `LANDLBL_TH`. Do the same here: flat art when zoomed out, shaded art when zoomed
in. The cost lands where there are fewest figures on screen and disappears where there are most,
and the sheet's `map size` column shows the shading is invisible when zoomed out anyway. That
makes the whole-world view exactly as fast as it is today.

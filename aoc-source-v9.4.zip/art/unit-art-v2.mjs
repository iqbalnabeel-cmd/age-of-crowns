// ==================== UNIT ART v2 — SHADED ====================
// Kept OUT of the build on purpose. Nabeel wants the play test first; this goes in the build after.
//
// The approach matters more than the drawing. Three rules it had to obey:
//
//   1. EMPIRE COLOUR SURVIVES. Every body shape is fill="currentColor", which is how a unit says
//      whose it is. A hand-drawn gradient would have baked one empire's green into the art and
//      silently broken the other seven. So shading is a SECOND pass over the same shape with a
//      white-to-black gradient at low opacity: it lightens the top-left and darkens the
//      bottom-right of whatever colour is underneath, for any colour.
//
//   2. GEOMETRY IS UNTOUCHED. 23 units are 7 base figures plus 23 overlays that are positioned
//      against those figures. Redrawing a figure by hand would move every overlay. So the shaded
//      version is GENERATED from the existing art: same paths, same coordinates, extra passes on
//      top. Nothing can drift.
//
//   3. ONE SET OF GRADIENTS, DEFINED ONCE. An SVG id is document-global, so a <defs> block inside
//      each figure would mean a hundred duplicate ids on a busy map. The defs go in the map once
//      and every figure points at them.
//
// Drop-in: add AOC_ART_DEFS to the map SVG once, then run shadeArt() over ART and TIERART.

// --- the shared defs. Add once, near the top of the map SVG. -----------------------------------
export const AOC_ART_DEFS = [
'<defs>',
// the whole trick: over any fill, this lights the top-left and shades the bottom-right
' <linearGradient id="aocLit" x1="0" y1="0" x2="1" y2="1">',
'  <stop offset="0" stop-color="#ffffff" stop-opacity="0.62"/>',
'  <stop offset="0.34" stop-color="#ffffff" stop-opacity="0.10"/>',
'  <stop offset="0.56" stop-color="#000000" stop-opacity="0.06"/>',
'  <stop offset="1" stop-color="#000000" stop-opacity="0.46"/>',
' </linearGradient>',
// steel: a bright edge, a mid tone, a dark underside
' <linearGradient id="aocSteel" x1="0" y1="0" x2="0.55" y2="1">',
'  <stop offset="0" stop-color="#f6f4ef"/><stop offset="0.45" stop-color="#b7b4ab"/>',
'  <stop offset="1" stop-color="#5d5a54"/>',
' </linearGradient>',
' <linearGradient id="aocWood" x1="0" y1="0" x2="0.7" y2="1">',
'  <stop offset="0" stop-color="#a07a4c"/><stop offset="1" stop-color="#553c23"/>',
' </linearGradient>',
// a soft contact shadow, not a hard ellipse
' <radialGradient id="aocDrop" cx="0.5" cy="0.5" r="0.5">',
'  <stop offset="0" stop-color="#120d08" stop-opacity="0.40"/>',
'  <stop offset="0.65" stop-color="#120d08" stop-opacity="0.16"/>',
'  <stop offset="1" stop-color="#120d08" stop-opacity="0"/>',
' </radialGradient>',
' <linearGradient id="aocPlate" x1="0" y1="0" x2="0" y2="1">',
'  <stop offset="0" stop-color="#c3baa8"/><stop offset="1" stop-color="#8b8273"/>',
' </linearGradient>',
'</defs>'
].join('');

// --- the ground a figure stands on -------------------------------------------------------------
// Two options, because which one is right is a judgement about the map and not about the figure.
// A plate grounds a unit hard, which is what the reference does on its flat green terrain. On
// parchment with province fills it may read as clutter once there are forty of them.
export function groundShadow(cx,cy,rx){
  return '<ellipse cx="'+cx+'" cy="'+cy+'" rx="'+rx+'" ry="'+(rx*0.37).toFixed(2)+'" fill="url(#aocDrop)"/>';
}
export function groundPlate(cx,cy,rx){
  const h=rx*0.37;
  return '<ellipse cx="'+cx+'" cy="'+(cy+0.6)+'" rx="'+(rx*1.06).toFixed(2)+'" ry="'+(h*1.05).toFixed(2)+'" fill="url(#aocDrop)"/>'
    +'<path d="M'+cx+' '+(cy-h)+' L'+(cx+rx)+' '+cy+' L'+cx+' '+(cy+h)+' L'+(cx-rx)+' '+cy+' Z" '
    +'fill="#4e4739" stroke="#2c261f" stroke-width="0.5"/>'
    +'<path d="M'+cx+' '+(cy-h*0.72)+' L'+(cx+rx*0.82)+' '+cy+' L'+cx+' '+(cy+h*0.72)+' L'+(cx-rx*0.82)+' '+cy+' Z" '
    +'fill="url(#aocPlate)"/>';
}

// --- the generator ------------------------------------------------------------------------------
// Takes one of the game's existing art strings and returns the shaded version.
//
//   every fill="currentColor" shape  ->  itself, then a copy filled with the lit/shade gradient
//   the flat grey #8a8a86            ->  the steel gradient
//   the flat brown #7a5233           ->  the wood gradient
//   the old hard ground ellipse      ->  a soft contact shadow, or a stone plate
//
// Only <path>, <circle> and <ellipse> carry fills in this art, which is why a regex is honest
// here rather than reckless. If the art ever grows a <rect> or a <polygon>, add it to the list.
const SHAPE = /<(path|circle|ellipse)\b([^>]*?)\/>/g;
const OLD_GROUND = /<ellipse[^>]*opacity="0\.18"\s*\/>/;

export function shadeArt(src, opts){
  const o = opts || {};
  let out = src;

  // 1. the ground
  const g = OLD_GROUND.exec(out);
  let ground = '';
  if(g){
    const cx = /cx="([\d.]+)"/.exec(g[0]), cy = /cy="([\d.]+)"/.exec(g[0]), rx = /rx="([\d.]+)"/.exec(g[0]);
    const X = cx?+cx[1]:16, Y = cy?+cy[1]:29.8, R = rx?+rx[1]:8;
    ground = o.plate ? groundPlate(X, Y+0.4, R*1.35) : groundShadow(X, Y+0.2, R*1.3);
    out = out.replace(OLD_GROUND, '');
  }

  // 2. materials
  out = out
    .split('fill="#8a8a86"').join('fill="url(#aocSteel)"')
    .split('fill="#7a5233"').join('fill="url(#aocWood)"')
    .split('stroke="#8a8a86"').join('stroke="#cfccc4"')     // a stroke is too thin to hold a gradient
    .split('stroke="#7a5233"').join('stroke="#8a6440"');

  // 3. the shading pass: every coloured body shape gets a copy with the gradient over it.
  //    Strokes are dropped on the copy or every outline would be drawn twice and go muddy.
  const lit = [];
  let m;
  SHAPE.lastIndex = 0;
  while((m = SHAPE.exec(out)) !== null){
    const [, tag, attrs] = m;
    if(attrs.indexOf('fill="currentColor"') < 0) continue;
    const clean = attrs
      .replace(/fill="currentColor"/, 'fill="url(#aocLit)"')
      .replace(/\sstroke="[^"]*"/g, '')
      .replace(/\sstroke-width="[^"]*"/g, '');
    lit.push('<'+tag+clean+'/>');
  }
  return ground + out + lit.join('');
}

// Shade a whole table (ART, or TIERART) in one go.
export function shadeAll(table, opts){
  const out = {};
  for(const k in table) out[k] = shadeArt(table[k], opts);
  return out;
}

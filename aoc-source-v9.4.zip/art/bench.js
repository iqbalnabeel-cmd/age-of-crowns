// DOES THE NEW ART COST ANYTHING TO DRAW?
//
// The art is 29% more shapes and swaps flat fills for gradients, so "it is only 4KB" answers the
// download question and not the frame-rate one. A gradient fill is genuinely dearer to rasterise
// than a solid one, and a busy late-game map has a lot of figures on it.
//
// This times the real repaint the player waits on: updateMap(), with layout forced each time so
// the browser cannot defer the work out of the measurement.
const {chromium}=require('playwright');

(async()=>{
  const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
  const p=await b.newPage({viewport:{width:390,height:844},isMobile:true,hasTouch:true});
  await p.goto('file:///home/claude/age-of-crowns/aoc-v6.html');
  await p.waitForTimeout(400);
  await p.evaluate(()=>{let s=20260912;Math.random=function(){s=(s*1664525+1013904223)>>>0;return s/4294967296;};
    selEmpire='abb';selRivals.clear();['byz','fra','mon'].forEach(k=>selRivals.add(k));selDiff='norm';refreshStart();});
  await p.evaluate(()=>document.getElementById('startBtn').onclick());
  await p.waitForTimeout(1200);

  // the generator, inlined into the page so it can rewrite ART in place
  const gen = require('fs').readFileSync('/home/claude/age-of-crowns/art/unit-art-v2.mjs','utf8')
    .replace(/^export /gm,'')
    + ';globalThis.__ART2={AOC_ART_DEFS,shadeArt,shadeAll};';

  const out = await p.evaluate(({gen})=>{
    eval(gen);
    const AOC_ART_DEFS=globalThis.__ART2.AOC_ART_DEFS;   // const stays inside eval; the functions leak
    G.rate=0; closeDrawer(true);
    const svg=document.getElementById('map');
    svg.insertAdjacentHTML('afterbegin', AOC_ART_DEFS);

    const OLD_ART=Object.assign({},ART), OLD_TIER=Object.assign({},TIERART);
    const NEW_ART=shadeAll(OLD_ART,{plate:true}), NEW_TIER=shadeAll(OLD_TIER,{plate:true});
    const use=(a,t)=>{ for(const k in a)ART[k]=a[k]; for(const k in t)TIERART[k]=t[k]; };

    // put N armies of mixed types on the map, zoomed so they are all actually on screen
    const kinds=Object.keys(UNITS).filter(k=>k!=='galley');
    function populate(n){
      for(const c in G.armies) if(G.armies[c].e===G.player) delete G.armies[c];
      const cells=Object.keys(MAPD5.cells);
      for(let i=0;i<n;i++){
        const t=kinds[i%kinds.length];
        placeArmy(cells[(i*7)%cells.length],G.player,{[t]:3},0,0);
      }
      fitView();                               // whole world on screen, so every figure is really drawn
    }
    function once(){ const r=document.getElementById('map'); updateMap(); r.getBoundingClientRect(); }
    function sample(){ const t=performance.now(); once(); return performance.now()-t; }
    const med=a=>{const b=a.slice().sort((x,y)=>x-y);return b[Math.floor(b.length/2)];};

    const rows=[];
    for(const n of [20,60,120]){
      populate(n);
      const drawn=document.querySelectorAll('#gArmy *').length;
      // Interleave. Run them apart and any drift in the machine lands entirely on whichever went
      // second, which is how the first pass produced 60 armies costing less than 20.
      use(OLD_ART,OLD_TIER); once(); use(NEW_ART,NEW_TIER); once();     // warm both
      const O=[],W=[];
      for(let i=0;i<40;i++){
        use(OLD_ART,OLD_TIER); O.push(sample());
        use(NEW_ART,NEW_TIER); W.push(sample());
      }
      use(OLD_ART,OLD_TIER);
      rows.push({n,drawn,old:med(O),neu:med(W)});
    }
    return rows;
  },{gen});

  console.log('ONE FULL MAP REPAINT, median of 40 interleaved runs, layout forced each time');
  console.log('');
  console.log('  armies   old art     new art     difference        army layer');
  out.forEach(r=>{
    const d=r.neu-r.old, pc=(r.neu/r.old-1)*100;
    console.log('  '+String(r.n).padStart(5)+'    '+r.old.toFixed(1).padStart(6)+'ms    '
      +r.neu.toFixed(1).padStart(6)+'ms    '+(d>=0?'+':'')+d.toFixed(1)+'ms  ('+(pc>=0?'+':'')+pc.toFixed(0)+'%)'
      +'    '+r.drawn+' elements in the army layer');
  });
  console.log('');
  console.log('  For scale: 16.7ms is one frame at 60fps. A repaint happens when the map changes,');
  console.log('  not continuously, so this is the cost of a pan, a zoom or a clock tick.');
  await b.close();
})();

// Build a sheet showing every unit old and new, so the choice is made by looking rather than by
// reading a description of it.
import * as R from '../server/rules.mjs';
import {AOC_ART_DEFS, shadeArt} from './unit-art-v2.mjs';
import {writeFileSync} from 'fs';

const UNITS = R.UNITS;
const order = Object.keys(UNITS).filter(k=>k!=='galley');
const trackOf = t => (UNITS[t] && UNITS[t].track) || t;

function oldArt(t){ return (R.ART[trackOf(t)]||R.ART.spear) + (R.TIERART[t]||''); }
function newArt(t,plate){
  return shadeArt(R.ART[trackOf(t)]||R.ART.spear, {plate}) + shadeArt(R.TIERART[t]||'', {plate});
}

const COLS = ['#2f9e44','#9c36b5','#1971c2','#c92a2a'];   // four empires, to prove colour survives

function cell(t,art,col,px){
  return '<svg viewBox="0 0 32 32" style="width:'+px+'px;height:'+px+'px;color:'+col+'">'+art+'</svg>';
}

let rows='';
order.forEach((t,i)=>{
  const u=UNITS[t];
  rows+='<tr>'
    +'<td class="n"><b>'+u.name+'</b><span>'+t+' · '+u.track+' · tier '+u.tier+'</span></td>'
    +'<td class="a">'+cell(t,oldArt(t),COLS[0],64)+'</td>'
    +'<td class="a lit">'+cell(t,newArt(t,false),COLS[0],64)+'</td>'
    +'<td class="a lit">'+cell(t,newArt(t,true),COLS[0],64)+'</td>'
    +'<td class="a lit sm">'+COLS.map(c=>cell(t,newArt(t,false),c,30)).join('')+'</td>'
    +'<td class="a lit sm">'+cell(t,newArt(t,false),COLS[0],22)+'</td>'
    +'</tr>';
});

const html='<!doctype html><meta charset="utf-8"><title>Age of Crowns — unit art v2</title>'
+'<style>'
+'body{margin:0;background:#171310;color:#e8dcc8;font:14px Georgia,serif}'
+'h1{font-size:18px;letter-spacing:2px;color:#c9a227;padding:16px 18px 4px;margin:0}'
+'p.sub{color:#a89878;padding:0 18px 14px;margin:0;font-size:13px;max-width:760px;line-height:1.5}'
+'table{border-collapse:collapse;width:100%}'
+'th{font-size:11px;letter-spacing:1px;text-transform:uppercase;color:#a89878;padding:10px 8px;'
+'border-bottom:1px solid #5a4730;text-align:center;position:sticky;top:0;background:#171310}'
+'th:first-child{text-align:left}'
+'td{border-bottom:1px solid #2e2620;padding:6px 8px;vertical-align:middle}'
+'td.n{font-size:13px}td.n span{display:block;font-size:10.5px;color:#a89878;letter-spacing:.4px}'
+'td.a{text-align:center;background:#e4d7b8}'
+'td.a.sm svg{margin:0 2px}'
+'</style>'
+'<h1>UNIT ART v2 — shaded</h1>'
+'<p class="sub">Left is what ships in v9.1. The rest are generated from exactly the same paths, so '
+'every tier overlay still lands where it was drawn to land. The four-colour column is the point: '
+'shading is a pass over the fill, not baked into it, so a unit still says whose it is.</p>'
+'<table><tr><th>Unit</th><th>v9.1</th><th>shaded</th><th>+ stone plate</th>'
+'<th>four crowns</th><th>map size</th></tr>'+rows+'</table>'
+'<svg width="0" height="0" style="position:absolute">'+AOC_ART_DEFS+'</svg>';

writeFileSync(new URL('./unit-sheet.html',import.meta.url), html);
console.log('wrote art/unit-sheet.html — '+order.length+' units');

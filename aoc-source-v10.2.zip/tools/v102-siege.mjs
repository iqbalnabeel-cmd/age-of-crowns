// A SIEGE HAD BEEN STARVING A GARRISON EVERY FIFTEEN MINUTES.
//
// `SIEGE_ATTR` was commented "garrison starvation per turn", written when a turn was a DAY.
// v7.0 replaced turns with a clock. `resolveSieges` kept applying the whole rate on every call,
// and it is called from `tickWorld`, which runs every TICK_H of 0.25 hours.
//
// Ninety-six times the intended rate, for thirty builds.
//
// Nabeel found it from the other end: "i had 45 troops in isfan city and ai easily killed my
// troops check logs plz what happened in that city battle." What happened is that twenty men
// besieged forty-five and starved them out in five hours.
//
// It also explains two play tests' worth of "the AI expands way too fast", why ELEVEN measured
// attempts to make free cities tougher all failed, why the Song won half of all games and why
// England won none. None of them were being stormed. They were being besieged, and a siege was
// effectively instant.
import * as R from '../server/rules.mjs';

const CROWNS=Object.keys(R.EMPIRES);
function seed(n){let s=n>>>0;return ()=>{s=(s*1664525+1013904223)>>>0;return s/4294967296;};}
const ok=[];const say=(c,m)=>{ok.push(c);console.log((c?'  PASS  ':'  FAIL  ')+m);};

// Put a garrison under siege and return the day the city fell, or null.
function besiege(garN,walls,besiegers,maxDays,step){
  Math.random=seed(3030);
  R.newGame(CROWNS[0],CROWNS.slice(1),'norm');
  const G=R.getG(), me=G.player, foe=CROWNS[1];
  R.declareWar(foe,me);
  const pid=R.provsOf(me)[0], cc=R.CITYCELL[pid];
  G.bld=G.bld||{}; G.bld[pid]={walls};
  G.armies[cc]={e:me,u:{spear:Math.round(garN*0.45),sword:Math.round(garN*0.3),
                        longbow:garN-Math.round(garN*0.45)-Math.round(garN*0.3)},mv:0};
  const nb=R.moveAdj(cc)[0];
  G.armies[nb]={e:foe,u:{spear:besiegers},mv:0};
  G.armies[nb].siege=cc;
  let hours=0;
  while(hours<maxDays*24){
    R.advanceClock(step);
    hours+=step;
    const g=R.getG().armies[cc];
    if(!g||g.e!==me)return hours/24;
  }
  return null;
}

// THE SAME THING IN A LABORATORY. `besiege` above advances the whole world, so the other seven
// crowns are also moving, fighting and relieving, and the day a city falls is only partly about
// the siege. Measured that way, no walls held 14.5 days and one ring held 7.3, which is backwards
// and was the test's fault, not the game's. This calls the siege tick and nothing else.
function starveDays(garN,walls,step){
  Math.random=seed(3030);
  R.newGame(CROWNS[0],CROWNS.slice(1),'norm');
  const G=R.getG(), me=G.player, foe=CROWNS[1];
  R.declareWar(foe,me);
  const pid=R.provsOf(me)[0], cc=R.CITYCELL[pid];
  G.bld=G.bld||{}; G.bld[pid]={walls};
  G.armies[cc]={e:me,u:{spear:Math.round(garN*0.45),sword:Math.round(garN*0.3),
                        longbow:garN-Math.round(garN*0.45)-Math.round(garN*0.3)},mv:0};
  const nb=R.moveAdj(cc)[0];
  G.armies[nb]={e:foe,u:{spear:20},mv:0};
  G.armies[nb].siege=cc;
  let hours=0;
  while(hours<120*24){
    R.resolveSieges(foe,step);
    hours+=step;
    const g=R.getG().armies[cc];
    if(!g||g.e!==me)return hours/24;
  }
  return null;
}

console.log('1. HIS ISFAHAN: 45 MEN BEHIND LEVEL-2 WALLS, BESIEGED BY 20');
{
  const d=besiege(45,2,20,40,6);
  console.log('    the city holds for '+(d===null?'over 40 days':d.toFixed(1)+' days')+'   (before the fix: 5 HOURS)');
  say(d===null||d>=4,'it holds for days, not hours');
  say(d===null||d<=30,'but a siege still works, so it is a real alternative to storming');
}

console.log('');
console.log('2. WALLS SLOW A SIEGE, AND THE BIGGER GARRISON HOLDS LONGER');
{
  const rows=[];
  [0,1,2,3].forEach(w=>rows.push(['45 men, walls L'+w,starveDays(45,w,6)]));
  rows.push(['90 men, walls L2',starveDays(90,2,6)]);
  rows.push(['20 men, walls L2',starveDays(20,2,6)]);
  const fmt=v=>v===null?'still holding':v.toFixed(1)+' days';
  rows.forEach(r=>console.log('    '+r[0].padEnd(20)+fmt(r[1])));
  const l=[rows[0][1],rows[1][1],rows[2][1],rows[3][1]];
  say(l.every(x=>x!==null)&&l[3]>l[0],'three rings of wall hold longer than none ('+fmt(l[0])+' vs '+fmt(l[3])+')');
  say(l.every((x,i)=>i===0||x>=l[i-1]-0.5),'and each extra ring holds at least as long as the last: '+l.map(fmt).join(', '));
  const big=rows[4][1], small=rows[5][1];
  say(big!==null&&small!==null&&big>small,'twice the garrison holds longer than half it ('+fmt(small)+' vs '+fmt(big)+')');
  console.log('    Both of those were true on paper before and meaningless in play, because the');
  console.log('    whole thing was over inside an afternoon whatever the numbers said.');
}

console.log('');
console.log('3. THE STARVATION IS PER DAY, WHATEVER THE TICK SIZE');
{
  // The bug was that the rate applied per CALL. So the same siege run in different step sizes
  // used to give wildly different answers. It must not any more.
  const coarse=starveDays(45,2,24);
  const fine=starveDays(45,2,1);
  console.log('    stepped a day at a time : '+(coarse===null?'-':coarse.toFixed(1)+' days'));
  console.log('    stepped an hour at a time: '+(fine===null?'-':fine.toFixed(1)+' days'));
  say(coarse!==null&&fine!==null&&Math.abs(coarse-fine)<=2.5,
      'the same siege takes the same time either way  <<< this is the bug, stated exactly');
}

console.log('');
console.log('4. WHAT IT DID TO THE WORLD');
{
  const marks=[1,3,7,14];
  const got={};marks.forEach(d=>got[d]=[]);
  const ends=[];
  for(let w=0;w<6;w++){
    Math.random=seed(4100+w*613);
    const line=CROWNS.slice().sort(()=>Math.random()-0.5);
    R.newGame(line[0],line.slice(1),'norm');
    R.getG().emp[line[0]].ai=true;
    let done=null;
    for(let d=1;d<=100;d++){
      R.advanceClock(24);
      if(marks.includes(d))got[d].push(Object.keys(R.MAPD5.provs).filter(p=>R.ownerOf(p)==='neutral').length);
      if(R.getG().over&&!done){done=d;break;}
    }
    ends.push(done);
  }
  const avg=a=>a.length?a.reduce((x,y)=>x+y,0)/a.length:0;
  console.log('    free cities left of 32     day 1   day 3   day 7  day 14');
  console.log('      before the fix              19       5       3       2');
  console.log('      now                     '+marks.map(d=>avg(got[d]).toFixed(0).padStart(7)).join(''));
  say(avg(got[1])>=22,'only a handful fall on the first day now ('+(32-avg(got[1])).toFixed(0)+', was 13)');
  say(avg(got[7])>=12,'and there is still a land rush to join a WEEK in ('+avg(got[7]).toFixed(0)+' free, was 3)');
  const fin=ends.filter(x=>x);
  say(fin.length===6,'all 6 worlds still reach a winner');
}

console.log('');
const bad=ok.filter(x=>!x).length;
console.log(bad?('  '+bad+' FAILED'):'  ALL GREEN');
process.exit(bad?1:0);

// HIS TWO IDEAS FROM THE v9.9 PLAY TEST.
//
//   "The top resource layer should be clickable, and then when I click on it, it should actually
//    show the stats: how much balance I have, how many resources I'm making in a day, and how
//    many resources I'm spending, just like on Fleet of Nation."
//
//   "Lets build our cities as CON with showing resources n building being built so i know what is
//    happening in each city."
//
// The second one has a rule attached that the first does not: what a city is doing is YOURS to
// know. An enemy's construction has been behind the fog since v7.7 and a progress ring would be
// the first thing in the game to leak it.
const {chromium}=require('playwright');

(async()=>{
  const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
  const ok=[];
  const say=(c,m)=>{ok.push(c);console.log((c?'  PASS  ':'  FAIL  ')+m);};

  async function boot(w,h,mob){
    const p=await b.newPage({viewport:{width:w,height:h},isMobile:mob,hasTouch:mob});
    const errs=[];
    p.on('pageerror',e=>errs.push(String(e)));
    p.on('console',m=>{if(m.type()==='error')errs.push('console: '+m.text());});
    await p.goto('file:///home/claude/age-of-crowns/aoc-v6.html');
    await p.waitForTimeout(400);
    await p.evaluate(()=>{let s=20261125;Math.random=function(){s=(s*1664525+1013904223)>>>0;return s/4294967296;};
      selEmpire='abb';selDiff='norm';refreshStart();});
    await p.evaluate(()=>document.getElementById('startBtn').onclick());
    await p.waitForTimeout(1300);
    await p.evaluate(()=>{G.rate=0;closeDrawer(true);});
    return {p,errs};
  }

  console.log('TAPPING THE RESOURCE STRIP');
  const {p,errs}=await boot(390,844,true);

  const r1=await p.evaluate(()=>{
    const out={};
    const cells=[...document.querySelectorAll('#resbar .rs')];
    out.count=cells.length;
    out.allButtons=cells.every(x=>x.tagName==='BUTTON');
    out.minH=Math.min(...cells.map(x=>Math.round(x.getBoundingClientRect().height)));
    out.minW=Math.min(...cells.map(x=>Math.round(x.getBoundingClientRect().width)));
    return out;
  });
  console.log('  '+r1.count+' cells, each at least '+r1.minW+'x'+r1.minH+'px');
  say(r1.count===6,'six cells: men and the five materials');
  say(r1.allButtons,'every one of them is a real button, not a label');
  say(r1.minH>=40,'and each clears the 40px tap floor ('+r1.minH+'px)');

  const r2=await p.evaluate(()=>{
    const out={};
    const e=G.emp[G.player];
    e.gold=5000; RESK.forEach(x=>{e.res[x]=200;}); e.res.timber=0;
    // something stuck waiting on timber, which is the line his reference does NOT have
    const pid=provsOf(G.player).find(x=>bldLv(x,'range')<1);
    doOrder({type:'build',pid,b:'range',q:1});
    out.waitingCity=provOf(pid).city;
    // tap timber. RESK order is grain, timber, iron, stone, horses; men is cell 0.
    [...document.querySelectorAll('#resbar .rs')][2].click();
    const h=document.getElementById('mBody').innerHTML;
    out.stock=/in store right now/.test(h);
    out.made=/Made each day/.test(h);
    out.spent=/Spent each day/.test(h);
    out.net=!!document.querySelector('.rsNet');
    out.whichCities=/Which cities make it/.test(h);
    out.waiting=/Waiting for timber/.test(h);
    out.namesIt=h.indexOf(out.waitingCity)>=0;
    out.market=/on the Market/.test(h);
    out.rows=[...document.querySelectorAll('.buildrow')].map(x=>x.textContent.replace(/\s+/g,' ').trim()).slice(0,5);
    closeModal();
    return out;
  });
  r2.rows.forEach(x=>console.log('    '+x));
  say(r2.stock&&r2.made&&r2.net,'stock, made per day, and the net are all there');
  say(r2.spent,'and what it is spent on');
  say(r2.whichCities,'it lists which of your cities make it');
  say(r2.waiting&&r2.namesIt,'AND what is stuck waiting for it, by city ('+r2.waitingCity+')');
  say(r2.market,'with a way straight to the Market for it');

  const r3=await p.evaluate(()=>{
    const out={};
    const cells=[...document.querySelectorAll('#resbar .rs')];
    const mb=()=>document.getElementById('mBody').innerHTML;
    cells[1].click();                                  // grain: the only one with a daily drain
    out.grainEaten=/Eaten by your army/.test(mb());
    closeModal();
    cells[0].click();                                  // men
    const h=mb();
    out.menSources=/Where they come from/.test(h);
    out.menCountry=/stretches of country/.test(h);
    out.menNoMarket=!/on the Market/.test(h);          // men are not for sale
    closeModal();
    // every single cell must open without throwing
    let opened=0;
    cells.forEach(c=>{c.click();if(document.querySelector('.rsNet'))opened++;closeModal();});
    out.opened=opened;
    return out;
  });
  say(r3.grainEaten,'grain shows what your army eats, because it is the one with a drain');
  say(r3.menSources&&r3.menCountry,'men show their cities AND their countryside');
  say(r3.menNoMarket,'and men are not offered on the Market, because they are not for sale');
  say(r3.opened===6,'all six open ('+r3.opened+'/6)');

  console.log('');
  console.log('WHAT EACH CITY IS DOING, ON THE CITY');
  const r4=await p.evaluate(()=>{
    const out={};
    closeModal();closeDrawer(true);
    const ps=provsOf(G.player);
    G.emp[G.player].gold=9000; RESK.forEach(x=>{G.emp[G.player].res[x]=900;});
    for(const c in G.armies)delete G.armies[c];
    G.bld={}; G.bld[ps[0]]={walls:2,barracks:1,market:1};
    startBuild(ps[0],'range',G.player);
    advanceClock(2);                                   // part way through
    doOrder({type:'recruit',pid:ps[0],t:'militia'});
    doOrder({type:'recruit',pid:ps[0],t:'militia'});
    const pv=provOf(ps[0]);
    const look=w=>{VB={x:pv.cx-w/2,y:pv.cy-(w/2.2)/2,w,h:w/2.2};lastW=null;applyVB();updateMap();};
    look(300);
    const g=()=>document.querySelector('#gPin g[data-p="'+ps[0]+'"]');
    out.ring=!!g().querySelector('circle[stroke="#c9a227"]');
    out.work=!!g().querySelector('.cwork');
    out.train=!!g().querySelector('.ctrain');
    out.trainN=((g().querySelector('.ctrain text')||{}).textContent)||'';
    out.pins=(g().querySelector('.cpins')||{querySelectorAll:()=>[]}).querySelectorAll('g').length;
    const wb=g().querySelector('.cwork').getBoundingClientRect();
    out.workPx=Math.round(wb.width);
    // the ring must actually move as the work progresses
    const arcOf=()=>{const c=g().querySelector('circle[stroke="#c9a227"]');return c?c.getAttribute('stroke-dasharray'):'';};
    const a1=arcOf(); advanceClock(3); updateMap(); const a2=arcOf();
    out.ringMoves=a1!==a2;
    // nothing of this at a whole-world zoom
    look(1600);
    out.farRing=!!(g()&&g().querySelector('.cwork'));
    look(300);
    // AND an enemy city must give nothing away
    const ep=Object.keys(MAPD5.provs).find(x=>ownerOf(x)!==G.player&&ownerOf(x)!=='neutral');
    G.buildQ[ep]={b:'walls',left:1};
    G.train[ep]=[{t:'militia',left:0.5}];
    updateMap();
    const eg=document.querySelector('#gPin g[data-p="'+ep+'"]');
    out.enemyLeak=!!(eg&&(eg.querySelector('.cwork')||eg.querySelector('.ctrain')||eg.querySelector('circle[stroke="#c9a227"]')));
    out.enemyName=provOf(ep).city;
    return out;
  });
  console.log('    the build chip is '+r4.workPx+'px on screen, and the yard badge reads "'+r4.trainN+'"');
  say(r4.ring,'a progress ring round the hex');
  say(r4.ringMoves,'and it genuinely moves as the work goes on');
  say(r4.work,'a chip above it saying WHAT is being built');
  say(r4.workPx>=9,'big enough to read ('+r4.workPx+'px)');
  say(r4.train&&r4.trainN==='2','a badge for troops in the yard, reading '+r4.trainN);
  say(r4.pins>=3,r4.pins+' pins underneath for what is already finished');
  say(!r4.farRing,'none of it at a whole-world zoom, same gate as the pins');
  say(!r4.enemyLeak,'and an enemy city ('+r4.enemyName+') gives away NOTHING. The fog rule holds');

  await p.screenshot({path:'/home/claude/age-of-crowns/docs/shots/v101-phone.png'});
  say(errs.length===0,'no page errors'+(errs.length?': '+errs.slice(0,2).join(' | '):''));
  await p.close();
  await b.close();
  const bad=ok.filter(x=>!x).length;
  console.log('');
  console.log(bad?('  '+bad+' FAILED'):'  ALL GREEN');
  process.exit(bad?1:0);
})();

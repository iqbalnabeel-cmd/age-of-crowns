# Age of Crowns — deploy links, standing rules, build log

> **How to answer him** is a separate doc: `claude/nabeel-working-preferences.md`. Read that too.
> Short version: TLDR in bullet points, no dashes between statements, plain sentences, mobile first.
>
> **This file is the master copy.** It is mirrored to the project doc `claude/age-of-crowns-deploy.md`
> with `Projects.project_write(local_path=...)`. Edit THIS file, then push it. Do not retype the doc.
>
> **20 Nov 2026: this on-disk master had been lost to a sandbox reclaim and the project doc was the
> only surviving copy.** It was restored from the project doc and pushed back. If `docs/deploy-doc.md`
> is missing at the start of a session, `project_read` it and write it back to disk BEFORE editing,
> or you will end up retyping 17KB by hand, which is the exact thing this file exists to prevent.

## READ THIS FIRST: the sandbox is not storage

**The cloud container holding this project has been reclaimed three times** (19 Sep, early Nov, 11 Nov). Each time `src/`, `tools/`, `build.mjs` and the on-disk copy of this doc went with it. That is what the environment does; it is not a failure of any one session.

**The project survives because the built files are on GitHub.** The repo holds build artefacts and nothing else, but the shipped HTML and `worker.js` between them contain every line of source, so the tree is rebuilt by splitting them back apart along their own section headers. It has now been done three times and takes about ten minutes.

**The 4 Nov recovery is the instructive one.** Only the SERVER file was current on GitHub, so `aoc-v8.9.html` itself was rebuilt from the v8.9 `worker.js` (which carries data.js + rules.js + orders.js) stapled to the v8.8a HTML's interface half. It came out byte-identical in size to the original. **That trick works only when the build in question touched nothing in `ui.js`, `net.js` or `boot.js`** — check before trusting it again.

**What this means for every future session:**
- **The repo is the backup.** The moment a build is delivered, the file on GitHub is the only copy that outlives the container. Say so when delivering.
- **`node build.mjs --verify` exists for exactly this.** It proves the tree reassembles the last shipped HTML byte for byte, so a recovered tree is the tested code and not a lookalike.
- **The split is recoverable because the build never minifies and never reorders.** Keep it that way.
- **Check what is actually on GitHub before answering "is it live".** On 4 Nov he had uploaded `worker.js` and missed the game file, so the server ran the new rules and the only playable file ran the old ones. `git clone --depth 1` and look; do not take "done" as proof.
- **A SOURCE ZIP IS PART OF EVERY DELIVERY. This doc said for weeks that it "has been offered four
  times and never uploaded", and that was simply wrong: `git clone` of the repo on 21 Nov shows
  `aoc-source-v9.0.zip`, `v9.1`, `v9.3` and `v9.4` sitting in it. He has been uploading them all
  along.** Then v9.5, v9.6 and v9.7 shipped without one, because the doc said he did not want it,
  and he had to ask. **Build `aoc-source-v9.x.zip` every time, to that exact name.** It holds
  `src/`, `tools/`, `docs/`, `build.mjs` and `dist/aoc-v9.x.html`, which is the only copy of the
  source that outlives the sandbox.
- **`aoc-v6.html` IS NOT IN THE REPO and never has been.** It is the stable local name the browser
  harnesses load, nothing more. Four builds were delivered with it as a third file he was meant to
  upload, and it is not one. **The delivery is three files: `aoc-v9.x.html`, `worker-server-code.txt`
  (which he renames to `worker.js`), and `aoc-source-v9.x.zip`.**

### The split points
The build concatenates in this order:
`shell-head.html` + `data.js` + `rules.js` + `orders.js` + `ui.js` + `net.js` + `boot.js` + `shell-tail.html`.
Each half begins with a `// ==================== NAME ====================` banner: `DATA + TOP-LEVEL`, `RULES — pure game logic`, `v7.9: ORDERS`, `INTERFACE — browser only`, `v7.9: PLAYING ONLINE`, `BOOT — browser only, runs at load`. **The banners appear more than once in `data.js`** (inside a long explanatory comment), so take the LAST occurrence before the real code, and **prove the boundaries by diffing the `orders.js` slice out of the HTML against the one out of `worker.js`: they must be identical.**

## Standing rules (Nabeel)
1. **Every build delivered comes with the GitHub upload link in the same message.** He updates the repo by hand, so the link has to be one tap away.
2. **Filenames carry the version.** The build emits the versioned copy into `dist/` automatically so it can never be named wrong by hand.
3. **On every build, all three, every time, without being asked:**
   - **a Notion build page** under `Product Roadmap / Age of Crowns / Version history`, titled like `v9.2 — the pace build` — what changed, why, the measurements, the bugs found and what caused them. **Add its row to the Version history index table in the same breath** or the table starts lying.
   - **this doc** — bump the current build, add a build-log row.
   - **the play link** in the chat message.
   - Also keep `START HERE — state of the game` current, since that is the page he actually opens.
4. **Mobile first.** Build for mobile before anything else.
5. **Measure before tuning.** "The game runs long" turned out to be four bugs, not a balance problem. **v8.9, v9.0 and v9.2 are the cleanest examples in the project**: "the AI is too strong" was not an AI problem, "the win line should scale with crown count" turned out not to need scaling at all, and "zoom is sticky" turned out to be a full DOM rebuild on every frame of a pinch. Every one of those answers came from a harness, not from thinking.
6. **Never bump nothing.** If a file has already been handed over under a name, the next build gets a new version number.

## Notion layout (set 11 Nov 2026 — do not undo it)

Until 11 Nov all 43 pages sat flat under `Age of Crowns`, with a v5.6 bug report filed between the v7.8 and v7.9 build pages and the QA pages named eight different ways. Nabeel chose section pages with index tables, consistent renaming, and the duplicate deleted.

```
Product Roadmap / Age of Crowns          39f7af6e-5d2c-80fe-82a8-c47004d9d1b2
├── 📖 START HERE — state of the game    4157af6e-5d2c-8170-9036-fa8d38ab0ff0
├── 🏗️ Version history                   4157af6e-5d2c-818b-af14-fe2430a299e9   (22 build pages)
├── 🧪 QA and play tests                  4157af6e-5d2c-8141-bb97-ca5a610b4a56   (17 test pages)
└── 📐 Design and reference               4157af6e-5d2c-8126-9eae-f4782a2fe555   (7 pages)
```

**The naming convention, and it is the whole point:**
- A build is **`v9.2 — the pace build`**. No `BUILT` prefix, no emoji in the title. The emoji is the page ICON.
- A test is **`QA v9.1 — play test`**, or `QA v5.6d — mobile bug report`. Always `QA <version> — <kind>`.
- Reference keeps its shouted prefix: `WORKING RULES —`, `DESIGN —`, `IDEAS —`, `DECISIONS —`, `GAME DESIGN DOCUMENT`.
- Icons carry the kind at a glance: 🎮 play test, 🐞 bug report, 📝 test report, 📲 mobile.

**Age of Crowns is the only row in the Product Roadmap database** and that is fine: his Claude project houses every game he builds, so the second game becomes the second row. Its Objective and Risk Assessment are in his words; Scope, Timeline and the Date were stale template leftovers and were filled in on 11 Nov. **Do not rewrite his Objective.**

## Current build
**v10.1** — his two play-test ideas: a tappable resource strip, and cities that show their work.
Play: https://iqbalnabeel-cmd.github.io/age-of-crowns/aoc-v10.1.html
Notion: `v10.1 — tap a resource, and see what a city is doing`, 4217af6e-5d2c-8117-9028-f0460b9ee6be

**THE ONE THING HE IS STILL DECIDING: the combat model.** See the v10.0 section. Do not start it
without him.

**THE BACKLOG IS EMPTY AND THE NEXT MOVE IS HIS.** The plan set on 21 Nov was four builds then one
play test: v9.5 market, v9.6 navy, v9.7 menu and pins, v9.8 the last three parked items. All four
shipped the same day. **Seven builds have shipped since the last play test and nobody has ever
taken a game to a win.** Do not start a ninth thing; ask what the play test said.
**He dropped sharper coastlines** (would re-carve all 367 cells and break every save, cosmetic only)
and **parked the app stores** (needs his accounts and money).

## Upload (paste this link every time)
https://github.com/iqbalnabeel-cmd/age-of-crowns/upload/main

Drag the file in, then **scroll to the bottom, choose "Commit directly to the main branch", and press the green Commit changes button**. Three uploads in a row appeared to work and did not land because that last step was missed.

A 404 on the play link right after an upload is usually just GitHub Pages rebuilding. Give it two or three minutes.

**The delivery is three files and they are always these three:**
1. **`aoc-v<version>.html`** — the game.
2. **`worker-server-code.txt`** — the multiplayer server, renamed to `worker.js` on GitHub.
3. **`aoc-source-v<version>.zip`** — the source, which is the backup. See the standing rules above.

`wrangler.toml` is already in the repo and only changes if the Worker's config does.
**Do NOT send `aoc-v6.html`.** It is a local harness name and has never been in the repo. **v8.5 through v9.4 all change the server, so it needs re-uploading on each.**

### The Claude app will not hand over a `.js` file
Both the download button and its dropdown answer **"This file type cannot be opened"**. Deliver the identical bytes as `worker-server-code.txt`, have him upload that, then **rename it on GitHub** (open the file, pencil icon, edit the filename box, commit). Renaming in the browser also avoids Windows producing `worker.js.txt`. Say it in the same message as the file.

## Confirming an upload landed
**The reliable check is `git clone --depth 1` of the public repo and look at the files.** WebFetch is refused on a provenance rule for any URL that has only ever appeared in Claude's own messages, and the `web-fetch` subagent hits the same wall; so does the device bridge when his computer is offline. **If you cannot verify, say so rather than guessing**, and ask him to paste the URL into chat, which puts it in the provenance set.

## Build log
| Version | What it was | Notion page |
| --- | --- | --- |
| v6.4 | Sea pass: transports, interception mid-lane, walking-on-water links cut, AI amphibious invasion | v6.4 — the sea |
| v7.0 | The clock. Turns gone, continuous movement, staggered AI | v7.0 — the clock |
| v7.0a | Columns become first-class objects; attacks take the march time; interception fixed | (in the v7.0 page) |
| v7.1 | Battles run over 6–12 hours; relief can join mid-fight | v7.1 — battles over hours |
| v7.2 to v7.5 | Travel direction, ships take a day, 367 real provinces, a crossing becomes one order | v7.2 to v7.5 — real provinces and crossings |
| v7.6 | The phone pass. 14 controls under 40px raised, labels under 11px raised | v7.6 — the phone pass |
| v7.7 | His test page: the muster bug, Outriders, the bands explained. Plus the save bug deleting every column on reload | v7.7 — scouting |
| v7.8 | A game you can actually win. Frozen garrisons, sieges that never happened, AI odds that ignored walls, the collapse of a crown | v7.8 — a game you can win |
| v7.9 | A shared world. Multiplayer on Cloudflare: a world code, one server clock, an order layer that is the only way the world changes | v7.9 — a shared world |
| v7.9a | The server goes live. Plus the `"type": "module"` field that silently disabled all 40 harnesses | v7.9a — the server goes live |
| v8.0 | A world waits in the lobby until the host begins it. An invite link carries the code | v8.0 — the lobby |
| v8.1 | Waypointing. A column carries the rest of its route and takes the next stop rather than landing | v8.1 — waypointing |
| v8.2 | Rivers and terrain. 96 real crossings, every cell a kind of ground, a road becomes a bridge | v8.2 — rivers and terrain |
| v8.3 and v8.4 | The roads become the network you walk. Snow and suburbs. The Ground view | v8.3 and v8.4 — roads and ground |
| v8.5 | All ten bugs from his first real play-test. Three were one id collision, which was also silently disabling AI land interception | v8.5 — all ten play-test bugs |
| v8.6 | A shared world holds all 8 crowns instead of the host's 2-5, and joining becomes a lookup then a picker | v8.6 — every crown on the map |
| v8.7 | One queue per city holding buildings and troops together, reorderable, paying as gold allows | v8.7 — one queue per city |
| v8.8 | All 367 stretches get a real name, open country becomes tappable, columns get named, Route becomes findable | v8.8 — a map you can talk about |
| v8.8a | The land names were plausible and not accurate. The map is a clean equirectangular projection, so all 287 were rewritten with real coordinates and measured | v8.8a — accurate land names |
| v8.9 | **The free lords.** Eleven free cities were falling on day one. Every grey city becomes a small state: walls from the first morning, a garrison sized to its income, levies holding its own country | v8.9 — the free lords |
| v9.0 | **The win line, measured.** 48 of 80 had quietly stopped being reachable. It becomes 30, stored per world and packed into the save. The parked crown-scaling question answered: it did not need to scale, it needed to be lower | v9.0 — the win line |
| v9.1 | **The shared-worlds lobby.** Multiplayer had had no shell since v7.9. A full lobby screen with My Worlds, Join and New, cards that say what the world did while you were away, every number of which was already on the wire and never read | v9.1 — the shared-worlds lobby |
| v10.1 | **Tap a resource, and see what a city is doing.** The strip becomes six buttons; each opens stock, made per day, which cities make it, what it is spent on, and **what is queued waiting for it**. Plus a progress ring, a what-is-being-built chip and a troops-in-yard badge on **your own** cities only | v10.1 — tap a resource |
| v10.0 | **His play-test fixes.** The city queue had been SILENTLY DELETING any order you were short of materials for, since v9.4; the Build button checked gold and nothing else; `doBuild` had no failure branch at all; and the start screen still said "turn". Plus the measurement that the AI takes 13 of the 32 free cities on day one, and eleven failed attempts to slow it | v10.0 — the play-test fixes |
| v9.9 | **The install pass.** `viewport-fit=cover` so the map reaches the edges of a notched phone and the safe-area padding stops being a no-op, a `theme-color` so Android does not paint a white bar over a dark map, and the `<title>` which had read **v8.8a for eleven builds** and is what the app switcher shows | v9.9 — the install pass |
| v9.8 | **The last three parked items.** Four resource buildings, each buildable only in a city that makes that material; **one annexation at a time**, queueable, binding on the AI too; and the host choosing **Short 20 / Normal 30 / Long 42** before a world begins. Plus the discovery that the AI had never annexed anything in any build | v9.8 — the last three parked items |
| v9.7 | **The in-game menu.** The twelve-icon rail becomes a five-tab bottom bar on phones (Cities, Armies, Chronicle, Standings, More), with the first-ever **Armies list** showing every force and flagging the idle ones, plus **building pins** drawn under each city on the map | v9.7 — the in-game menu |
| v9.6 | **The navy.** Three ships instead of one (War Galley, Archer Galley, Fire Galley), a Naval Dock to unlock the better two, and fleets that bombard a harbour: killing garrison and breaking walls, but never capturing, because ships do not hold ground | v9.6 — the navy |
| v9.5 | **The marketplace.** All eight crowns buy and sell the five materials. No building unlocks it, it is open from the first morning, and an empire you are at war with will not deal with you. Escrow on post, partial fills, five offers each, prices floating between half and three times base | v9.5 — the marketplace |
| v9.4 | **The five materials.** Grain, timber, iron, stone and horses plus a manpower pool; each of the 80 cities makes one, chosen by what the place really was. Gold costs unchanged, materials a second gate from tier 1 up. The army eats grain daily. All 8 crowns play every game and the rival picker is gone | v9.4 — the five materials |
| v9.3 | **The full-window city screen.** A city on a phone opens as a window of its own with a red X and all four tabs inside, 8 build rows at once where the sheet fitted 4. Phones only; a laptop keeps the drawer. Plus the last nine user-facing strings still speaking in turns | v9.3 — the full-window city screen |
| v9.2 | **The pace build.** Everything he wrote down after playing v9.1: the queue float, stacks showing per-type chips when zoomed out, everything three times faster, the free countryside emptied, no wounds or pause for marching, a smooth pinch, the new unit art folded in, and Add to Home Screen | v9.2 — the pace build |

## v10.1 — the resource panel, and the fog rule it nearly broke

**`showResource(r)` is the fifth time in this project that every number already existed and
nothing had read them in one place.** (The others: v9.1's lobby cards, v9.6's fleet composition,
v9.7's Armies list, v9.8's win line.) **Before building a screen that reports on something, check
what is already in `G`.**

- **`resWaiting(r)` is the line his CoN reference does not have and the most useful one on the
  screen.** It walks every city queue and reports what is blocked on THIS material. It is the
  direct answer to the v10.0 bug: an order used to be stuck with nothing anywhere saying so.
- **Men are deliberately not symmetrical.** Cities and countryside listed apart, spent once rather
  than daily, and **no Market button**, because men are not for sale. The harness asserts that.
- **The strip cells are `<button>` now, not `<span>`,** so the browser resets had to be undone in
  CSS: `border:none;background:transparent;font:inherit`. They are 50px tall, over the 40px floor.

### The city work display, and the rule attached to it
**IT IS YOUR CITIES ONLY, AND THAT IS NOT AN OVERSIGHT TO BE FIXED LATER.** What an enemy is
building has been behind the fog since v7.7, when enemy strength became a band rather than a
number. A progress ring over a city you have never scouted would have been the first thing in the
game to leak it. `v101-ui.js` plants a build AND a training order in an enemy city and insists the
map shows neither.

- **The ring's fraction has to be recomputed from what the thing IS**, because `buildQ.left`
  counts down and the total is not stored: `annexDays` for an annexation, `hoursToDays(ROAD_HOURS)`
  for a road, `bldDays(b, bldLv(pid,b))` for a building — the CURRENT level, because it has not
  incremented yet.
- **`bldPin(b, lv)` in data.js is now the single source of a building's glyph**, used by both the
  chip above a city and the pins below it. They were two inlined lists about to drift, which is
  how a Barracks ends up as two different symbols depending on whether it is finished.
- Same `PIN_TH` zoom gate as the pins.

### A harness trap worth remembering
**`closeModal()` hides the modal but leaves its markup in `#mBody`.** A test reading
`document.body.innerHTML` after closing one panel and opening another was still matching the
PREVIOUS panel's text, and reported that the men panel offered men for sale. **Read the container,
not the document.**

## v10.0 — the queue was eating orders, and the pattern behind it

**THE CITY QUEUE SILENTLY DELETED ANY ORDER YOU WERE SHORT OF MATERIALS FOR, FOR SIX BUILDS.**
`queueBlocked` has returned `'res'` and `'men'` since v9.4. `pumpQueues` handled `'gold'`,
`'slot'` and everything else, and everything else meant the splice at the bottom, whose comment
read *"started, or impossible: either way it leaves the queue"*. That line was written in v8.7,
when gold, slot and gone were the only answers that existed.

Nabeel reported it as **"Build and queue buttons not working"**. He pressed +Q with no timber and
the row vanished. He was right, and it was not a button.

- **`'res'` and `'men'` now `continue`, not `break`, which is deliberately UNLIKE gold.** Gold is
  one pool, so the first claim on it blocks everything behind. Materials are five separate pools:
  being short of timber is no reason a wall made of stone should wait.

### THE PATTERN, and this is the useful part
**v9.4 added materials as a SECOND GATE, and three separate places that only knew about gold were
never widened.** All three shipped for six builds and all three surfaced in one play test:

1. `pumpQueues` dropped orders blocked on materials.
2. The Build button's `disabled` test read `e.gold<cost||busy` and nothing else, so with zero
   timber it stayed gold and inviting.
3. `doBuild` had **no else branch at all**, so a refused order said nothing whatsoever.

**When you add a second gate to something, grep for every place that tests the first one.** That
is the whole lesson and it would have caught all three in ten minutes.

### A related honesty bug
**Build and +Q are the same action.** Both push to the queue; `ORDERS.build` returns ok either
way. So `doBuild` logged "Construction begins" when it had only got in line. It now looks at
`G.buildQ[pid]` afterwards and reports which of the two actually happened.

### And the last of the turns, again
The start screen's Continue button said **"turn 3"**. v9.3 cleared out nine strings still speaking
in the turns the game lost in v7.0 and missed this one, **because the start screen is the one
screen no harness had ever measured.** That is the second thing the start screen has hidden: v9.8
found its chips had been 32px tall against a 40px floor since v5. **Measure the start screen.**

## MEASURED — the AI takes the map in 72 hours, and defence does not stop it

His words: *"AI countries are expanding way too fast! It's just day 3, and they're already
conquering most of the map."* Measured over 8 worlds with the player inert, free cities left of 32:

| day | 1 | 3 | 5 | 7 | 14 |
| --- | --- | --- | --- | --- | --- |
| free cities | **19** | **5** | 3 | 3 | 2 |

**Thirteen fall on the first day.** A phone player cannot be present for that.

**ELEVEN VARIANTS WERE MEASURED AND ALL ELEVEN FAILED.** Garrisons x2 and x3; every free city
given walls L3; walls made worth 45% a level instead of 15%; all the combinations; and marching
put back to the old 2.25h. **Day 1 stayed between 18 and 21 in every single one. Day 3 stayed
between 4 and 7.** Do not try to fix this with defence; it has been measured to death.

**The cause is the battle model, and the Chronicle says it in one line:**

> *Mali Empire stormed Marrakesh against Free lords (lost 6, slew 19)*

Mali lost **six men** taking a walled city of eighteen. An attacker with a modest edge wins at
almost no cost, so doubling the defender only means they kill seven instead of six. **This is the
same root cause as the Song winning 12 of 24 games and England winning none.**

**Parked for his decision**, because changing how battles resolve touches everything in the game.

## v9.9 — the install pass, and why nobody saw these for eleven builds

**ALL THREE ONLY EXIST ONCE THE GAME IS INSTALLED, which is why no harness had ever looked.**
v9.2 built Add to Home Screen and asserted the manifest, the icons and the iOS tags, all of which
were right. It never asserted the things the BROWSER provides and the installed app does not.

- **`viewport-fit=cover`.** Installed, there are no browser bars, so on a notched phone the
  parchment has to reach the screen edges or there is a black band top and bottom. Worse: every
  panel in the game already pads itself with `env(safe-area-inset-*)`, and **those return zero
  until this is set**, so the padding had been there doing nothing since v7.6.
- **`theme-color`.** Without it Android paints the status bar white over a dark map, which is the
  first thing you see every single time you open the icon. It is `#171310`, the parchment's dark.
- **The `<title>` said "Age of Crowns v8.8a" and had done for ELEVEN BUILDS.** The project rule is
  that the version is declared once in `data.js` and nothing else carries a version string; this
  line predates the rule. In a browser the title is a tab nobody reads. Installed, **it is what
  the phone's app switcher shows**, so it was eleven builds out of date in the one place you
  cannot miss it. The title is now just the name, and the version lives on the start screen and
  in the manifest where it is generated.

**`v92-ui.js` now asserts all three**, so the install surface cannot drift again.

**The general lesson, and it is the same one as v8.8's land names:** a feature was tested in the
only mode the harness could see. If something behaves differently in a mode you cannot drive,
write down what changes in that mode and check those specific things by hand once.

### What is NOT built, and he chose that
**Add to Home Screen is all he wants (confirmed 22 Nov).** No APK, no Play Store listing. Do not
offer either again unless he raises it. See the CoN research note below for why both are parked.

## v9.8 — the conquest cap, and the dead rule it uncovered

**THE AI HAD NEVER ANNEXED ANYTHING, IN ANY BUILD, EVER.** Found while checking that the new cap
binds the AI: it binds nothing, because over 30 days and 32 settled conquests across eight crowns
the number of annexations started was ZERO. The test was `gold >= annexCost + reserve + 40`;
annexCost was 124 to 170 and an AI crown sits at 50 to 90. **So every AI empire in the project's
history has fought its whole campaign with no buildings outside its six home cities.**

Same class as the v8.5 interception bug and the v9.6 Archer Galley: plausible code, never fired,
invisible because nothing looked. **When you add a rule for the AI, measure that it has fired.**

- **The fix is `e.annexSave`, the same trick as `e.navSave`:** book the money a turn ahead, because
  the troop budget takes every coin as it lands. **The booked money must NOT count against the
  purchase it is booked for** — the first version did, so a crown had to save twice the price.
  France sat on 146 gold with 118 booked for a 118 gold annexation and never bought it.

### One conquest at a time
- **`annexingNow(e)` scans `G.buildQ` by CURRENT owner.** `canAnnex` refuses while it returns
  anything, and `annexBlockedBy` names the city so the refusal has a reason.
- **Capturing a city now clears its `buildQ` and `G.q`.** Inheriting the last owner's half-finished
  annexation handed the conqueror a second one and breached the cap. Found by the cap's own harness.
- **Both `annexHours` and `annexCost` were HALVED.** One at a time turns a parallel cost into a
  serial one; at the old numbers the median game went 26 days to 41. Serialised and quick is the
  shape; serialised and slow is a wall.
- **It costs about a third of the pace and that is the rule working.** 16 worlds, every crown
  played: **16 of 16 finish, median 35, longest 55.**

### The pace numbers moved around and nearly caused a bad tune
Eight worlds at a 60 day limit reported "7 of 8" twice running with medians of 31 and 38. **That is
variance, not a finding.** Widening to sixteen worlds gave 16 of 16. The harness limits are 100 days
now, and `v94-econ`'s worlds run longest because **that harness leaves the player's crown inert**,
which is harder than any real game: run to 140 days all eight of its worlds finish, slowest at 92.
**Do not tune a rule on a number that moves that much between runs.**

### Resource buildings
- **`BLD[b].res` is the third gate kind**, after nothing and `port`. **`bldAllowedIn(pid,b)` is the
  single place all three live**, and `bldGateText(b)` is the single place the refusal is worded.
  Every caller goes through them: `startBuild`, the `build` order, the AI loop, and the city screen.
- **A sawmill only goes up where there is timber, and that is the design.** v9.4 made the 80 cities
  different from each other; a building that let every city make everything would undo it. If
  anyone proposes a generic "works" building, this paragraph is the answer.
- **+50% a level, of the BASE**, added before unrest halves it, so the steps are flat and do not
  compound.

### The host's win line
- **`WINLEN` is three named lengths**, and `newGame(player, rivals, diff, len)` takes a key. **A
  call with no `len` still gets `winLineFor()`**, so every old call site and every old save is
  unchanged. The bar has been per-world and on the wire since v9.0; the only new thing is a picker.
- **The server validates `body.len` against the three keys.** A client that could post a raw number
  would win a shared world on the first morning.

### Two more found by accident
- **The start screen chips have been 32px tall since v5**, against a 40px floor set in v7.6,
  because **no harness had ever measured the start screen**. They are 44 now.
- **A harness that steps 24 hours cannot see a 14 hour event.** The cap's first AI test reported
  "no crown ever had more than ZERO under way" and passed. It samples every 6 hours now AND asserts
  that it caught crowns mid-annexation, so it cannot go quietly vacuous again. **Fifth harness in
  this project found green and measuring something else.**

## v9.7 — the bottom bar, and the rule it follows

**IT IS THE SAME RULE AS v9.3 AND IT NOW HAS TWO INSTANCES, SO IT IS A RULE.** Phone chrome and
laptop chrome are allowed to differ, and the harness asserts OPPOSITE answers at the two widths.
The rail is hidden by `#rail{display:none}` inside the phone media query and `#bbar` appears; a
laptop sees neither line. **Do not "unify" these.** A vertical bar beside a wide map is right, and
the same bar on a 390px phone spends 15% of the map's width on navigation.

- **The bar costs HEIGHT, which is the cheap axis.** 50px of 844 is 6%; the rail was 58px of 390,
  which is 15%. That trade is the entire argument for the build.
- **`#mapwrap` is padded clear of the bar**, and `#abar`/`#actbar`/`#modebar` are lifted by the
  same amount. Anything new that anchors to the bottom of a phone screen must do the same.
- **A bottom SHEET and a bottom BAR both want the bottom.** `#drawer` and `#logdrawer` stop above
  the bar; `body.cityfull` hides the bar and puts the drawer back to `bottom:0`, so the full-window
  city screen really is the whole screen.
- **`updateBBar()` runs from `renderAll`** and from `updateLogBadge`. The two badges are the idle
  army count and the unread chronicle count.

### The Armies list
**Every number in it was already in `G` and nothing had ever read it**, which is the third time
that sentence has been written in this project (v9.1's lobby cards, v9.6's fleet composition, this).
Before building a screen that reports on something, check what is already on the wire.

- **`armyRows()` merges `G.armies` and `G.col`**, because from the player's side those are one
  thing: a force of mine, somewhere. **Idle first** (`rank` in that function), then biggest.
- **`jumpToForce` is `jumpToCity` for armies.** One way of getting to a thing, wherever the list of
  things lives. Both zoom to `MAPD5.W/4` and then open the card.
- **On a phone an army card is NOT the drawer**, it is the floating `#abar`. A harness that opens
  an army and measures `#drawer` measures a closed drawer 500px below the screen.

### The pins
- **`PIN_TH` is 900 and it is registered in `zoomBand()`.** The doc has said since v9.2 that a new
  threshold `updateMap` branches on must go in `zoomBand` too, or it only takes effect after the
  90ms settle. This is the first one added since that was written.
- **Glyph sizes are in SCREEN pixels once multiplied by `s`.** The first version used `5.2*s` and
  measured at **4 screen pixels a chip**: a smudge, not a symbol. 12 gives an 11px chip, which is
  about the floor for a drawn glyph. **Measure a new map glyph with `getBoundingClientRect`
  before believing it.**
- **The city name steps down by `16*s` when a city has pins**, or they are drawn through it.
- **Order is fixed** (walls, barracks, range, stables, workshop, dock, market) so the shape of a
  city's row can be learned rather than read. Walls carry their level; nothing else does.

## v9.6 — the navy, and the invariant that holds it together

**A FLEET IS `f.n` PLUS `f.s`, AND THEY MUST AGREE.** `f.n` is the hull count and everything that
only wants a size still reads it (drawing, blockade, the AI's "how big is that"). `f.s` is what
those hulls ARE: `{galley:3, archer:1, fire:2}`. Keeping `n` is the only reason this was a day's
work rather than a week's: not one existing read of a fleet had to change.

**`sum(f.s) === f.n` is the invariant.** `v96-navy.mjs` re-checks it after EVERY section, including
40 sea battles and 45 days of AI warfare, because a fleet whose composition drifts from its count
gains or loses strength with no ships changing hands. That is the naval money printer.

- **`fleetShips(f)` is the only way to read a composition** and returns `{galley:f.n}` when there
  is none, which is what a pre-v9.6 fleet and a transport both are. **`setShips`** is the only way
  to write one and recomputes `n` from the parts, so the invariant cannot be broken by hand.
- **`thinShips(f, n)` takes the CHEAP hulls first, and `SHIPK` must stay cheapest-first** for that
  to be true. It is a rule with a consequence: a War Galley in front of a Fire Galley is a 30-gold
  shield, so the starter ship never becomes obsolete.
- **`fleetPow(f, attacking)`** is the strength. The `attacking` flag is why a Fire Galley is
  terrifying on the offensive and ordinary at anchor.
- **The volley happens before the melee and both sides fire.** It is capped at `n-1` hulls so a
  fleet can never be destroyed by it alone; without that cap an archer squadron stops being a ship
  and becomes a spell.
- **Save slots 11 and 12 on the navy row**: the composition, and whether the fleet has fired today.
  Unpack **only trusts `s` when it sums to `n`** and otherwise falls back to all galleys. Silently
  preferring a broken composition over an honest hull count would hand somebody a fleet of nothing.

### Bombardment
**A bombardment never captures anything, and this is not a limitation to be fixed later.** Ships do
not hold ground. What it does is kill garrison and break walls so the landing afterwards is
survivable. `BOMB_WALL_TH` is 9 siege weight, which is three Fire Galleys: two War Galleys (weight
1.1) scratch a garrison and nothing more, by design.

- **`f.bd` is the one-shot-a-day flag** and is cleared in the daily rollover beside `G.rec`.
- **`thinArmy` never deletes a garrison**, it leaves one man. Shellfire does not empty cellars.
- **The shore fires back** at `BOMB_RETURN` per wall level, so bombarding a L3 city costs ships.

### Making the AI build a good ship took FOUR attempts, all measured
This is the most instructive sequence in the project since the free lords, because every fix was
plausible and the first three did nothing.

1. **The dock was bolted onto the naval pass.** Zero docks in 30 days: that pass only fires when the
   fleet is small AND the city is free on the same tick. **A building belongs in the building loop.**
2. **It picked a port at random**, so a crown with three harbours used its one dock a third of the time.
3. **It bought the dearest ship it could afford RIGHT NOW.** The naval pass runs after the building
   loop, so the treasury is always near empty; a 30-gold galley always squeaked through and the
   purchase itself kept gold below the price of anything better. **17 galleys, zero archers, by
   crowns that had built the dock.** It now picks what it WANTS and saves.
4. **Saving failed twice.** Telling the yard to wait shrank the fleet and still produced no archers
   (the troop budget took the coins as they landed). Raising `reserve` inside the naval pass
   protected nothing, because **that pass runs AFTER the budget is struck**. `e.navSave` books the
   money a turn ahead and the next tick's reserve honours it. **7 Archer Galleys.**

**The general lesson: when the AI will not buy a thing, find out what its gold is doing at the
moment it decides, not what it can afford on paper.**

### Ordering that bit
- **`const` is not hoisted and `data.js` is one long file.** `SHIP_RES = SHIPS.galley.res` threw
  "Cannot access 'SHIPS' before initialization" the instant the server module loaded, because the
  resource block is built above the ship table. The literal lives in `SHIP_RES` and `SHIPS` reads it.
- **`BLD[b].port` is a new kind of gate**: the first that asks where the city is rather than what it
  has. It is checked in `startBuild`, in the `build` order, and in the AI's building loop.

### Harness traps hit this build
- **`makeSaveCode` is ASYNC.** Handing its Promise to `unpackSave` reports an empty navy and looks
  exactly like a broken save format. The synchronous round trip is `packSave`/`unpackSave`, which is
  what `regress.mjs` uses.
- **`cityClick` takes a PROVINCE id, not a cell.** **The recruit tab's key is `rec`, not `recruit`.**
- **The Chronicle is newest-first**, so `G.log.slice(-1)` reads the opening line of the game.
- **There is no province-owner map.** Ownership lives on the cells; `ownerOf(pid)` reads the city cell.

## v9.5 — the marketplace, and the one bug class that would ruin the game

**THE ORDER BOOK IS A FLAT LIST IN THE SAVE.** `G.mkt` is an array of offers and `G._mkid` is the
next id. Both are packed: top-level save slots `mk` and `mi`. Remember that the save format is also
the multiplayer wire format and the server's storage format, so anything added to an offer is added
to all three at once.

An offer is `{i, e, r, b, n, px}`: id, owner, resource, buying (truthy) or selling, how many left,
gold each. There is no separate escrow store. **The escrow IS the offer**: posting a sell takes the
goods out of `e.res` and the offer's `n` is where they now live; posting a buy takes
`ceil(n*px)` gold out of `e.gold` and the offer holds it. This is why conservation works: there is
only ever one copy of anything.

**The check that matters more than any other.** Total gold + total materials + everything on the
book, summed across every crown, must not change when two crowns trade. `v95-market.mjs` computes
that number before and after post, take, partial fill and cancel. An escrow leak in a market is a
money printer and it would be invisible in play until the economy was meaningless. If you touch
`mktPost`, `mktTake`, `mktCancel` or `mktSweep`, run that harness.

**`mktSweep()` exists because a crown can die holding offers.** When an empire is eliminated its
offers would otherwise sit on the book forever, with real goods inside them that no longer belong
to anybody. The sweep drops them. It is called from the daily tick.

**War is checked at read time AND at write time.** `mktVisible` hides a warring crown's offers so
they never render, and `mktCanDeal` refuses the order anyway. Both are needed: the UI list can be
stale by the time a thumb lands on it, and a multiplayer client can send whatever it likes.

### The AI is the feature

Nobody will ever notice how good the matching engine is. They will notice an empty page. `aiMarket(k)`
runs once a day per AI crown and does three things, and **the third is what makes it a market**:
it takes what it is short of, sells what it has more than six days of production of, and **posts a
buy offer when it is short and nobody is selling**. Without that clause the AI only ever sold, the
book filled with grain, and there was nothing to sell into.

**Do not let sellers all undercut.** The first version shaved 0.1 off the cheapest rival every time,
so within a week every grain offer in the game sat on the floor price. A seller now undercuts about
55% of the time and otherwise prices above the leader. Grain's base is 2, not 1, because at a base
of 1 the floor and the base were the same number and the band had nowhere to go.

### Measured

Book reaches 40 standing offers by day 12 with nobody in the chair, 17 trades executed over 30 days.
Pace: 8 of 8 worlds still reach the win line, median 29 days against v9.4's 25. The help text's
"two to three weeks" was updated to four.

## v9.4 — the economy, and the thing to understand before touching it

**A CITY MAKES ONE MATERIAL, and that is the whole design.** `CITYRES` in data.js maps all 80 city
ids to one of grain/timber/iron/stone/horses. It is MAP DATA, never game state: it is not in the
save, it cannot change, and taking the city is what changes who gets the output. `RES_PER_CITY`
says how much a day. Grain is 25 against 10 for the rest, deliberately — Nabeel asked that early
expansion never feel tight, and grain is the one with a daily drain against it.

**MY FIRST MODEL WAS WRONG AND THE MEASUREMENT IS WHY.** I had materials come from each cell's
TERRAIN. Forest is 28 cells of 367, mountain 14, steppe 21, and they cluster. Measured: seven of
eight crowns could not raise a horseman and England could build nothing but militia. **Nabeel's
city model needs no patch and does something mine could not: it makes the 80 cities different from
each other.** If anyone proposes terrain-driven resources again, this paragraph is the answer.

**THE COVERAGE RULE IS LOAD-BEARING.** Five of a crown's six home cities make one material each and
the sixth doubles the region's speciality. `regress` does not yet assert this; `tools/v94-econ.mjs`
prints it. **If a city is ever reassigned, re-check that every crown still covers all five**, or
that crown silently loses a whole unit track.

- **Gold costs did not change and must not.** Materials are a SECOND gate. That is what let the
  v9.2 pace work survive: measured, the whole economy cost 9% of the pace (median 23 -> 25 days).
- **`hasRes` / `payRes` / `refundRes` / `shortOf` are the only way to touch a stockpile.** Every buy
  path goes through them so a cost can never be charged in one place and checked in another.
  `UNITRES`, `BLDRES`, `ROAD_RES`, `SHIP_RES`, `ANNEX_RES` are the tables; absent means free.
- **Manpower costs the unit's tier.** `unitMen(t)`.
- **Fractions live in `e.frac`, exactly as gold lives in `e.purse`.** At TICK_H of a quarter hour a
  city's 10-a-day is 0.104 a tick; rounding that would mean no material ever arrived at all.
- **The army eats in `tickMaterials`.** GRAIN_FIELD 0.5, GRAIN_HOME 0.25, per man per day, straight
  line. Running out sets `e.hungry` and costs condition; it never deletes men.
- **The AI checks materials before choosing, not only when buying.** Without that it picked a Knight
  with no horses, the recruit failed silently, and it burned its whole guard loop on things it
  could not have.
- **Save: slots 12 and 13 on the empire row**, the five materials and the manpower pool. A pre-v9.4
  code has neither and is given a fresh stockpile rather than zero, which is the right reading.
  **The regress snapshot was widened the same day**, because a snapshot that does not look at a
  field cannot notice it going missing, and this suite has already passed vacuously once.

### All eight crowns, always (v9.4)
The rival picker is gone; `newGame(selEmpire, every other crown, diff)`. This also makes single
player match a shared world, where all eight have been in play since v8.6. **Consequences:** only 32
cities start free instead of 56, so any harness counting free cities or free garrisons needs the
per-city figure, not the total. Games are longer than a 4-crown world was: measured 8/8 finishing,
median 25 days.

### The strip, and the icon rule
**Six numbers on a 390px phone in 51px, no scrolling.** It is a SECOND row (`#resbar`) under `#hdr`,
because `#hdr` already scrolls sideways and anything that scrolls can be missed.
**Icons are drawn (`RESICON`, `MENICON`), never Unicode.** A colour emoji ignores `color` — the v9.1
lobby globe — and zodiac or chess glyphs mean nothing to a player. **First attempt failed because
all six were horizontal bars.** They are six distinct SHAPES now: person, tall stalk, round log end,
wide anvil, square block, horse's head. If a seventh is ever added, give it a shape nothing else has.

## v9.3 — the full-window city screen, and the rule for which panels get one

**The rule, because the next panel will ask for the same treatment.** A panel goes full window when
you are READING AND COMPARING a long list, and stays a sheet when you need the panel AND THE MAP at
the same time. The city qualifies: building and recruiting is a list, and the 72% sheet fitted about
four rows of it. The army panel does not: a full-screen army card hides the thing you are aiming at.
Same for the fleet, a battle and a stretch of open country. `tools/v93-cityscreen-ui.js` asserts all
four are still sheets, so this cannot drift.

- **`showDrawer(title, full)`.** One optional argument; only `openCityPanel` passes `true`. It toggles
  `#drawer.fullcity` and `body.cityfull`, and `closeDrawer` clears both.
- **PHONES ONLY, his call.** All the layout lives inside the existing phone media query
  (`max-width:760px, or (max-height:780px) and (max-width:1000px)`). A laptop keeps the 330px side
  drawer beside a visible map, which is why the harness runs at two widths and asserts OPPOSITE answers.
- **The rail is hidden by `body.cityfull`, not by a combinator.** `#rail` is a SIBLING of `#mapwrap`
  and `#drawer` lives INSIDE `#mapwrap`, so nothing in the drawer's subtree can reach it. A class on
  `<body>` can. The rail is 58 of 390px and width is what a build list is short of.
- **The game header stays.** In the CoN reference the resource bar is still above the city screen, and
  you need your gold on screen while deciding what to build. So the window covers the MAP AREA, not the
  viewport: measure it against `#mapwrap`, never against `innerHeight`.
- **The window is opaque** (`#14100c`). It was `rgba(...,.99)` first and the parchment showed through.

### The last of the turns
The v9.2 queue-float bug was one instance of a family. Nine more user-facing strings still spoke in the
turns the game lost in v7, and most of them were on the recruit tab, where the new screen made them
obvious. All reworded, **after checking the rule behind each one**:

- `G.rec` (the muster) and `G.res` (research) reset at the `gameDay()` boundary in `advanceClock`, so
  "this turn" becomes "today" and "until next turn" becomes "until tomorrow".
- A fleet's `mv` ticks down by the hour in `tickCooldowns` alongside armies, so "sail left this turn"
  becomes "sail left, and it comes back by the hour".
- The march toasts said "within reach this turn" in a game where every province has been a legal
  destination since v7.0.

**The training footnote is now BUILT FROM `TRAIN_HOURS`** rather than typed out. It went stale because
it was typed out, and the next pace change would have done it again.

### Two harness bugs, both the quiet kind
- **It measured the drawer mid-slide.** The open transition is 220ms and the probe ran immediately, so
  it reported the drawer 883px down the screen and called it a layout failure. **Wait out a transition
  before measuring anything positional.**
- **It called `openCityPanel` directly, so `G.selCity` was null and `setCityTab` silently did nothing.**
  Only `cityClick` sets the selection. The harness had been photographing the Overview tab and
  labelling the file `v93-city-build.png`. It now asserts which tab is lit before it shoots.

## v9.2 — what the play test found, and what the measurements said

**This is the first build made entirely from Nabeel playing the game.** Two bugs, three feel notes, four feature asks. It took the first two groups.

### The pace: everything was priced in whole days
Both *"movement speed is too slow"* and *"building time should be reduced"* had one cause. Every project a city took on was priced in **whole days**, left over from the turn game that died in v7. On the real-time clock that is a day of watching a bar fill.

- Units by tier: 24/48/72h → **6/12/20h** (`TRAIN_HOURS`)
- Buildings: a flat 48h → **8h first level, 16h second, 24h for walls L3** (`BLD[b].hrs`, parallel to `cost`, indexed by the level you ALREADY have)
- Roads 48 → **12** (`ROAD_HOURS`), annexation 72-96 → **24-36** (`annexHours`), a galley 24 → **16** (`SHIP.hrs`)
- `MARCH_HOURS` 2.25 → **1.5**, so foot cross the world in 1.8 days instead of 2.7

**The queue still STORES `left` in days.** The save format is also the wire format and the server's storage format, so the unit on disk did not move; only the numbers going in did. `hoursToDays()`, `trainHours/trainDays`, `bldHours/bldDays`, `annexHours/annexDays` are the pairs.

### The free countryside: it is all or nothing
> Having AI in each and every land location is not a good idea. Just have it in major AI cities.

`FREE_FIELD_SHARE` 0.75 → **0**, and the men move indoors: `FREE_GAR_BASE` 8 → 14, `FREE_GAR_PER_INC` 1.6 → 2.0, `FREE_GAR_CAP` 20 → 30.

Measured on the same seeds at the same new pace (`tools/v92-pace.mjs`), free cities still free on day 14:

| | day 1 | day 7 | day 14 | day 21 |
| --- | --- | --- | --- | --- |
| v8.8a, no free lords at all | 44.6 | — | 1.6 | — |
| v9.1, walls **and** countryside | 51.8 | 38.4 | 35.5 | 32.9 |
| **v9.2, walls only** | 49.1 | 21.4 | **16.0** | 15.6 |

**Two attempts to win that back, both measured, both failed.** A thin screen over 25% of cells: 15.3, no better than none. Fortifying free cities harder (garrison 20, walls 2 and 3): 14.4, slightly worse.

**THE FINDING, and it generalises: the brake was march friction, not defence.** A levy in every cell forced the AI to stop and fight and cost it hours. Take the friction away and no amount of wall recovers it. **Do not try to tune this with garrison size; it does not respond.** If he ever wants the brake back, the countryside is the only lever, and it has to be dense.

### Wounded and tired: two rules, both removed
- **`ACT_COOLDOWN` is 0** (was 6 hours after any action, during which a force could march but not attack). `coolDown()` is now a no-op and `isReady()` is always true. The `mv` field stays in the save so an old game ticks down on its own.
- **The `w` flag no longer costs anything in a fight.** It meant "arrived here on the march" and cost a DEFENDER 20%. Four multipliers removed (`fightRound`, `oddsOf5`, and both intercept paths).
- **What was kept:** `INTERCEPT_STRUNG` 0.6 still catches a column on the road, which is his "unless ambushed or engaged". Forced march still costs 20%, because the player opts in and the button says so. Wounds from actual fighting still persist and still heal.
- **The WEARY badge is gone from the map.** A badge for a rule that no longer fires is worse than no badge.
- **A v7.3 landmine was found while in there:** an army coming off a ship was parked with `mv:99`, which stopped meaning "spent this turn" and started meaning ninety-nine HOURS back in v7.0.

### Why zoom was sticky, and the general shape of the fix
`applyVB` set the viewBox (nearly free) and then called `updateMap()` (rebuilds ~4,000 SVG nodes) on **every one of the 60-120 pointermove events a pinch fires per second**.

Measured per frame on a 390×844 phone (`tools/v92-zoombench.js`): viewBox alone 1.0 to 2.6ms; with the rebuild 8.1ms at full zoom out and **19.5ms zoomed in**, against a 16.7ms budget, on a desktop CPU.

**The fix, and the pattern to reuse:** the cheap thing happens every frame, the expensive thing happens only when its OUTPUT would differ. `zoomBand(w)` is a bitmask of every threshold `updateMap` branches on (`CHIPTH`, `ZOOMTH`, `LANDLBL_TH`, 760, 1150) — same band in, same markup out. Rebuild immediately on a band change (or the map lies about what is on it) or on >25% scale drift (which is what keeps figures a constant size on screen); otherwise a 90ms trailing timer. **60 rebuilds per pinch becomes 10.**

### CHIPTH was in the wrong place
`CHIPTH` 500 → **280**. The rule (zoomed out one total, zoomed in one chip per type) has been right since v5.6. 500 of a 1750-wide world is 28% of the map, which on a phone is a dozen provinces. This is the second time he reported it; the first time the rule was checked and the threshold was not.

### The unit art, and the zoom gate
`art/` is now folded into `src/data.js`: `shadeArt`, `shadeAll`, `groundPlate`, and `ART_LIT`/`TIERART_LIT` built lazily by `artLitReady()` so the server never pays for them.

- **The shared gradients are STATIC MARKUP** in `shell-head.html` at the top of `<body>`, in their own 0×0 `<svg id="artdefs">`. An SVG id is document-global, so a `<defs>` per figure means a hundred duplicate ids; and `#map` is rebuilt by `innerHTML` on every repaint, so anything inside it is thrown away.
- **`artBase(t)` takes the zoom gate** (`VB.w <= ART_TH`, 780): shaded on a front, flat when the whole world is on screen. **`artPanel(t)` is always shaded** and is what `artSvg` uses, because a panel draws one figure at 34-44px with nothing competing.
- Cost measured in `art/bench.js`: +18% on a full repaint, +7KB on the file.

### Add to Home Screen, from a single file
- The manifest is built at load as a `data:` URI with an **absolute `start_url`** taken from `location.href` with any `#w=CODE` invite hash stripped. A relative `start_url` inside a data URI resolves against the data URI and the installed app opens nowhere.
- The icon is **rasterised through a canvas from 1.4KB of inline SVG** (`AOC_ICON_SVG`). A baked-in 192+512 PNG pair costs 363KB of base64 on a 790KB file.
- All of it runs in `requestIdleCallback` and is wrapped in try/catch. **Installability must never be able to stop the game loading.**
- **No service worker is possible** in a single file (a SW script must be its own same-origin file; blob: is refused). So Chrome's automatic install banner will not fire. The menu item works and honours everything. iOS ignores manifests and reads the `apple-` meta tags, which are also there.

## The win line (v9.0) — and the harness that lied twice

**The parked question:** should 48 of 80 scale with the crown count? Every crown starts with 6 cities, so 3 crowns leaves 62 free and 8 leaves only 32; against 48 you need 42 beyond your own, so at eight crowns ten must come off other crowns before you start.

**FIRST PASS, AND IT WAS WRONG.** Sweeping the bar per size gave: four crowns wanted 40, eight wanted 34, and **six wanted 30 and often did not finish at all**. Six being harder than eight is not a result, it is a smell. **The harness had always played the first n empires in list order**, so "3 crowns" meant three neighbours in western Europe and "6 crowns" a thin chain from Britain to Mongolia. It was measuring geography and calling it world size. **Shuffle the lineup per world; `tools/v90-winline.mjs` and `v90-barsweep.mjs` both do now.**

**SECOND PASS.** Six worlds each, 90 day limit, nobody in the player's chair, every crown played by the same brain:

| crowns | free | bar 42 | bar 38 | bar 34 | bar 30 |
| --- | --- | --- | --- | --- | --- |
| 2 | 68 | | | | 5/5 day 43 |
| 3 | 62 | | | 6/6 day 32 | 6/6 day 27 |
| 4 | 56 | 3/6 day 40 | 5/6 day 51 | 5/6 day 45 | 6/6 day 43 |
| 6 | 44 | | 5/6 day 49 | 6/6 day 45 | 6/6 day 36 |
| 8 | 32 | | | 4/6 day 50 | 6/6 day 33 |

**One bar finishes every world at every size and it is not a scaling rule. It is 30.** So the bar never needed to follow the crown count; it was simply too high, and **v8.9 is why** — the free lords made every city cost a real army and real days, so 48 had stopped working even in the four-crown world it was tuned on.

- **`WINLINE` is 30.** `WINLINE_FREE_MARGIN` 2 is a **rail, not a rule**. `WINLINE_FLOOR` 12.
- **The bar lives on the world, not in a constant.** `G.need`, set in `newGame` from `winLineFor(crowns)`, packed as `nd`, read everywhere through `needToWin()`.
- **An old code carries no `nd` and falls back to `NEED5` (48), which is right: 48 is what it was played under.** `regress.mjs` guards this.
- **The header had 48 written into the HTML by hand.** A number baked into markup lies the moment the rule behind it moves.

**RE-MEASURED AT THE v9.2 PACE.** Every world at every size now finishes under EITHER bar; the difference is time. Bar 30 gives a median of 16 days against 51 for bar 48, and a three-crown world now closes in a median of **9 days** where v9.0 measured 26. **That is the number to watch if he says a campaign ends too soon, and `WINLINE` is the one-number dial.**

**THE TWO HARNESS BUGS, both the dangerous kind:**
- **`unpackSave` RETURNS the world and does not install it. `setG` is the load.** A harness that called `readSaveCode` and then read `getG()` was comparing the world to itself, so **the save round-trip test passed vacuously for four builds.**
- **The round-trip snapshot joined `cellOwner` in dictionary order.** A fresh world inserts `c0,c1,c2` and an unpacked one `c0,c1,c10,c100`. **It looked exactly like a broken save format and was not one.** Read every map through a fixed, sorted key list.

## The free lords (v8.9, countryside removed in v9.2)

**Nabeel's complaint:** *"AI is still too strong and winning by capturing the empty cities."* Measured on v8.8a: **eleven free cities fell on the first morning**, half the map by day 3, one left by day 14.

**THE AI WAS NOT BEING CLEVER, AND NERFING IT WOULD HAVE BEEN THE WRONG FIX.** A free city was four men behind no walls and the country between the cities belonged to nobody. Each AI thinks four times a day forever and launched **117 columns in ten days**. A human logs in twice a day.

- **A garrison sized to the city**, **walls from the first morning**, **TIER 1 ONLY**.
- **`FREE_FOOT` is militia, levy, shortbow, handxbow, and this rule is load-bearing.** A free lord can hold and can never march on you. Give them cavalry and the map becomes 56 extra empires moving at once. `regress.mjs` fails if anything above tier 1 appears under `neutral`.
- **A levy driven off does not come back.** `growNeutrals` refills a *thinned* levy on ground the lord still holds, never a new one behind a player who took the cell.
- **v9.2 removed the countryside entirely at his request.** See the v9.2 section above for what that cost and for the two tunings that failed to recover it.

**The general lesson:** *when a player says an opponent is too strong, check whether the opponent is strong or the world is empty.*

## Ids, and the collision that cost three builds (v8.5)
Three id spaces, distinct by first character: cells `c0`…`c366`, columns `m1`,`m2`… (`newColId`), fights `f1`,`f2`… (`newFightId`).

Columns used to be `c1`,`c2`…, so a column id was **also** the id of a place. Nabeel reported it as three separate bugs. **It was also hiding a rule that had never worked:** `aiIntercept` looked targets up in `G.armies` (keyed by cell) when `interceptTargets` returns column ids. **4,626 chances across a 45-day game, zero taken.**

**A bug in an id namespace does not look like an id bug.** The rename happens **on the way in** in `unpackSave`. `armyClick` takes what the tapped element SAID it was (`data-col`, `data-fight`).

## Movement cost (v8.5)
- **`fullPathTo` and `marchMap5` must be the same search.** One was breadth-first and the other Dijkstra, so the game quoted one number and walked another road. **89 of 183 marches walked a dearer route than quoted.** Both are Dijkstra over `stepCost`.
- **`stepCost` carries the real crossing distance** (`HOPLEN`, `hopLen(a,b)`). Shortest link 6 map units, longest 230.
- **`MARCH_HOURS` is the time for an AVERAGE stretch.** Multiply by `hopLen` in any harness asserting a march time. **It is 1.5 since v9.2, not 2.25.**
- **A column sent next door may take two hops.** Run the clock until it is gone rather than advancing one leg.

## The AI and the player (v8.5, Nabeel's ruling)
- **No crown ever declares war on the player first.** Not a grace period: that only moves the pile-on later.
- **Once the player has declared, that crown remembers** (`d.pFirst`, packed) and may declare from then on.
- **`nearestTargetCity` prefers a target that is not the player's.**
- **Outriders take no ground.** `scoutOnly(u)` in `claimCell`. **The unit key is `scout`, not `outrider`** — a harness using the wrong key silently tests nothing, because `UNITS['outrider']` is undefined and `scoutOnly` then returns false.

## The mobile floor (set in v7.6, do not quietly lower it)
- **40 CSS px** minimum for anything pressable, 44 wherever it costs no map. Held in `--tap` / `--taps`.
- **11px** minimum for text a player has to read. Rail captions are the one exception.
- Room on a short screen is found by making things **narrower, not shorter**.

## Zoom
- **`ZOOM_MIN_SHORT` is 64**, **`ZOOM_OUT_MARGIN` is 1.04**, **`CHIPTH` is 280** (v9.2), **`ZOOMTH` 780**, **`ART_TH` 780**, **`LANDLBL_TH` 900**.
- **Three places clamp zoom and all must read those constants**: `zoomBy`, the `wheel` handler, the floors in `fitAspect`.
- **Empty parchment at full zoom out in portrait is correct.** The world is 1.6x wider than tall and the phone is the other way round. Do not "fix" it with a cover fit.
- **`applyVB` does NOT rebuild the map on every call since v9.2.** See the v9.2 section. If you add a new zoom threshold to `updateMap`, **add it to `zoomBand()` as well** or it will only take effect after the 90ms settle, which reads as a glitch.

## Pace
- **Rules changes move pace; measure after every one.** v8.5 moved it with no balance dial touched. v8.7 moved it not at all, and the measurement is how you know.
- **MARCH_HOURS was long believed not to be the lever** (halving march time and cooldown once moved day 21 from 24.8 to 24.8). **v9.2 moved it anyway, for feel rather than for balance**, and the balance effect is real but smaller than the free-countryside change beside it.
- **v8.9 is the largest deliberate pace change**, **v9.0 is the correction it forced**, and **v9.2 is the largest change to how fast the game FEELS**.
- **Suburb defence at +15% measured as exactly zero difference over 16 games**, so it went to 1.00. A rule with no measurable effect is complexity you pay for twice.
- **A world size is not a lineup.** Always shuffle which empires are in play when measuring anything about crown count.

## The city queue (v8.7)
- **`G.q[pid]` is a WAITING ROOM, not a rewrite.** `G.buildQ` and `G.train` are untouched, which is why pace did not move and the AI needed no changes.
- **Nothing in the queue has been paid for.** Gold is taken when an item STARTS.
- **`pumpQueues()` runs on the clock**, after `tickIncome`.
- **The blocking rule:** short of **gold** stops the walk; a busy **slot** is stepped over; an impossible item is dropped.
- **`a.q` means "the player pressed +Q".** Without it the order still refuses when gold is short, and **that refusal is what stops the AI overspending.**
- **`left` is in DAYS and is a float.** Every readout of it must go through `etaLabel(left * DAY_H)`. Two did not and shipped `1.0004166666666667t` to the player (v9.2 bug 1).

## Names (v8.8, corrected in v8.8a)
- **THE MAP IS AN EQUIRECTANGULAR PROJECTION AND THIS IS THE MOST USEFUL FACT IN THE PROJECT.** Fitted against all 80 cities: `x = 10.0007*lon + 199.87`, `y = 701.69 - 9.9687*lat`, median error **0.6 map units**. `MAPPROJ` in data.js, `cellLonLat(cid)` in rules.js.
- **`LANDNAMES` is keyed by CELL ID and every entry carries real coordinates**: `c95:['Ramadi',43.31,33.42]`.
- **v8.8 got this wrong and shipped it.** Real names handed out in province-list order, nothing comparing a name to a POSITION. It looked convincing. **A claim you cannot measure is a claim you are hoping about.**
- **Two independent checks in `regress.mjs`:** distance (median 99km, none over 300km) and the reverse (**265 exact, 22 next door, 0 elsewhere**).
- **Where there is genuinely nothing, use the real name of the desert.**
- **A duplicate is a bug**, as is a name that is the same place as its own city (Fustat/Cairo, Karkh/Baghdad).
- **A column is named, not a soldier.** `no`, `ty`, `hm` on the column; `colName(c, short)` builds it; `emp.corps` never resets.
- **Your columns are labelled on the map, an enemy's is not.** The fog rule outranks the label.

## The ground and the map (v8.2 to v8.4)
- **The rivers on screen ARE the rivers in the rules.** 96 of 846 links.
- **A road is a bridge**, and halves rough ground (`TER_ROAD_SHARE`). Inside a city only half the terrain counts (`TER_CITY_SHARE`).
- **Terrain comes from geography, not noise** (`TERZONE`). **`oddsOf5` takes the origin cell**, or the estimate cannot know the attacker is wading a river.
- **Terrain is hatching over a very light wash, never a flat colour**, and never on a city cell.
- **The tracks on screen ARE the ways you can march.** 287 + 160. Paving draws heavy on the same track.
- **`cellChain` walks `moveAdj`, never `CADJ`.** Raw shape-adjacency includes open water.

## Drawing rules that keep biting
- **Anything on the map that costs the player something must SAY what it is.** The weary mark was a bare red `~` with no label and it cost 20% of a fight. **It was given a label in v8.5 and removed entirely in v9.2 when the rule went.**
- **A rule that no longer fires must lose its badge in the same commit.** Chrome reporting "Ready" forever is noise.
- **A force that is neither in `G.armies` nor in `G.col` is drawn by nobody.**
- **A single continuous curve drawn alone at a point reads as a character, not as texture.**
- **An SVG id is document-global.** Anything referenced by `url(#id)` from many figures goes in the page once, outside `#map`, because `#map` is rebuilt by `innerHTML`.

## The save format (v9 — read this before touching packSave)
`packSave` was written for the turn-based game and never updated when v7 landed. **A reload silently deleted every column on the road, every battle in progress, and reset the clock to zero.** Four builds shipped that way.

From v7.9 this matters twice as much: **the save format is also the multiplayer wire format and the server's storage format.**

- **When you add a field to G that must survive a reload, add it to `packSave` and `unpackSave` in the same commit.**
- A field that exists only once something sets it makes the round trip permanently dirty. Declare it in `newGame` AND in `unpackSave`.
- The unit index is `saveUI`/`saveUN`, not a bare `UKEYS.indexOf`.
- v8 codes still load. Keep it that way; he holds old codes.
- **A rename of anything used as a key is a migration.**
- v8.7 added `qq` (city queues). **v8.9 added nothing.** **v9.0 added `nd`, the win line.** **v9.2 added nothing**: the pace change only altered the VALUES going into fields that already existed. The wire is 2.18KB at day 20.
- **`unpackSave` returns; `setG` installs.** Any harness testing the round trip must call `setG`.

## Multiplayer (v7.9, live since v7.9a)
```
https://nabeel-personal-project.iqbalnabeel-bca.workers.dev
```
A bare visit answers `{"error":"Not found. The game itself is on GitHub Pages."}`. That is it working: it only answers on `/api/...`.

- **The Worker project is `nabeel-personal-project`.** A Worker cannot be renamed after creation.
- **The server is `worker.js` at the repo root**, built from `src/data.js` + `src/rules.js` + `src/orders.js` + `src/worker.js`.
- **`src/orders.js` is the only way the world changes**, offline as well as online.
- **Authority is checked on the server against a token**, never against what the client says about itself.
- **An online world holds EVERY crown (v8.6)**, so its bar is `winLineFor(8)`, which is 30 like everything else. **A joiner PICKS and looking costs nothing** (`netPeek`). A crown taken while the picker was open must fail softly.
- **Every number on a lobby card was already on the wire since v7.9 and nothing read it until v9.1.** Before building anything that reports on a world, check `/api/<code>/state` first.
- **Health has never been confirmed from a Claude session.** The sandbox cannot fetch it on the provenance rule. If the root URL answers but creating a world fails: **Durable Objects need the paid Workers plan.**

### Deploying it
1. **A missing `worker.js` reads as a config error.** `The entry-point file at "worker.js" was not found` means the file is not in the repo, nothing more. Five builds failed on this.
2. **A green build still has no public address.** Switch it on under **Domains → Worker URL**, both Production and Preview.
3. **`package.json` is not required.** If one exists it must **not** declare `"type": "module"`.

## Git push is blocked
The sandbox git proxy refuses credentials for this repo (not in the session's authorised set). Do not route around it with curl, the REST API, or a rewritten remote. Only a NEW session started with the repo attached as a source can clear it; the list is fixed at session start, so granting access mid-session does not reach the running one. The Projects/chat GitHub connector is READ-ONLY.

**`git clone` of the public repo DOES work** and is how the project has been recovered three times. Read is fine; write is not.

## Build
`node build.mjs` writes `dist/aoc-<version>.html`, `aoc-v6.html` (the stable name harnesses load), `server/rules.mjs`, and `worker.js`. `--verify` additionally proves the tree rebuilds the last shipped HTML byte for byte.

- **The build fails if `data.js`, `rules.js` or `orders.js` reference the browser.** That guard is the single reason multiplayer took one build instead of five.
- **`server/rules.mjs`'s export list is GENERATED** from the top-level names, so it cannot go stale. `getG()` lives in `rules.js`; do not append a second one.
- **Harnesses import `server/rules.mjs`, a BUILD ARTEFACT.** Run `node build.mjs` first, every time.
- **The version is declared once, in `data.js`.** Nothing else should carry a version string, **and no harness should assert a specific one** — `v90-winline-ui.js` pinned `v9.0` and went red purely because the calendar moved.
- **`--verify` takes an optional filename and otherwise uses this version's shipped file.** It used to hard-code `./aoc-v8.9.html` and silently skipped on every later build. **That fix has now been written twice**, because the first one lived in an unpushable commit made after the source zip and died with the container. **A fix to the build script has to ride a zip, not a commit.**

## Running the suite
```
node build.mjs
node tools/regress.mjs                      # ~4 min. the rulings, the wire format, the names, the bar
node tools/v90-winline.mjs                  # bar 48 against bar 30 at every size. ~8 min, run in background
node tools/v90-barsweep.mjs                 # the sweep behind the bar (CROWNS=, BARS=)
node tools/v90-winline-ui.js                # the header, Standings, help text, on a phone
node tools/v91-lobby-ui.js                  # every lobby state including a dead server
node tools/v92-ui.js                        # every item on his v9.1 play-test page, in a browser
node tools/v92-zoom-ui.js                   # rebuilds per pinch, and the chip/total swap across CHIPTH
node tools/v92-pace.mjs                     # free cities left by day, AI against AI
node tools/v92-zoombench.js                 # what a pinch frame costs, viewBox alone against a rebuild
node tools/v93-cityscreen-ui.js             # the city window at 390x844 AND 1440x900, opposite answers
node tools/v94-econ.mjs                     # can a crown build, is grain a surplus, what the economy cost the pace
node tools/v94-ui.js                        # the strip fits, costs go red, the city names what it makes
node tools/v95-market.mjs                   # the order book: conservation, war, does the AI fill it
node tools/v95-market-ui.js                 # the market screen, phone and laptop, tap by tap
node tools/v96-navy.mjs                     # three ships, the volley, the bombardment, the fleet invariant
node tools/v96-navy-ui.js                   # the Sea tab, the dock gate, the fleet card, a bombardment
node tools/v97-menu-ui.js                   # the bottom bar, the Armies list, the pins, at BOTH widths
node tools/v98-last.mjs                     # the works, the conquest cap, the war length, the pace
node tools/v98-last-ui.js                   # the length picker, the Industry section, the cap on screen
node tools/v100-playtest.mjs                # the queue keeps what it cannot afford yet
node tools/v101-ui.js                       # the resource panels, and the city work display
node art/bench.js                           # what the shaded art costs to draw
```
**Prefer node harnesses over Playwright where the question is about rules.** `server/rules.mjs` runs the same code the server runs and 10 worlds take 12 seconds against several minutes in a browser. **A full-game sweep needs a long timeout** and exceeds the 2-minute foreground limit: run it with `nohup ... &` and poll the log.

## What went wrong with the tests, so it does not happen again
- **A harness can be green and be measuring something else entirely.** Four found so far: `v77-land-intercept` searched the log for the **sea** wording; `v7-ui` asserted the word "column" when it meant "the panel opened"; the save round trip compared the world to itself; the same snapshot compared dictionary iteration order instead of ownership.
- **When a harness goes red after a change, ask what it is actually measuring before assuming the change broke something.** Every red in the v8.9 and v9.0 sessions was a harness bug. **In v9.2 three went red because they asserted the OLD behaviour the user had just asked to change**, which is a different thing again: rewrite the assertion and leave a note saying why, never delete it.
- **An assertion that goes red when the game gets better is a broken assertion.** v9.2's win-line harness asserted bar 30 beats bar 48 on completion rate; at the new pace both finish every world, so the comparison moved to TIME.
- **Scope a DOM assertion to the thing under test.** Counting `#gArmy rect` counts seventy neutral badges and proves nothing; query `#gArmy g[data-a="<cell>"]`.
- **Do not read a shared log to prove your own event happened.** Watch the specific cell, tick by tick.
- **Read every map through a fixed, sorted key list.** Object key order is an engine detail.
- **Do not hold `G`.** `newGame` reassigns it; go through `getG()`.
- **A harness must load `aoc-v6.html`** (or take the file as `argv[2]`). Never `index.html`.
- **Before believing a suite result, check the suite ran.**
- **Give every harness a real assertion and `process.exit(fails?1:0)`.**
- **Seed BEFORE the world is made.** This has caught me three times.
- **Write the harness that reproduces the bug BEFORE the fix.**
- **Ask for the thing that could not pass by accident.**
- **Make the claim measurable rather than being more careful.** v8.8 shipped 287 unchecked facts about geography. Care was not the missing ingredient; a number was.
- **When he asks "is this accurate or a placeholder", go and check.**
- **Prefer a stable metric over a dramatic one.** "Free cities left on day 14" barely moves between seeds; "the day half of them are gone" swings several days.
- **A result that is the wrong shape is a smell, not a finding.** Six crowns looking harder than eight was the harness.
- **Markup containing a reference is not the same as a browser resolving it.** `url(#aocLit)` being in the string proves nothing; a dangling paint reference renders black, silently. Look at a screenshot.
- **A harness that assumes every free city has a garrison will throw.** Since v8.9 a grey city whose garrison was wiped by an attacker who also died stays neutral with no army on it.

## Movement, and where the buttons go
- **The main action row holds four buttons and no more.** A fifth overlaps on a 344px Fold cover. Anything else goes under **More**.
- **Under More is not the same as findable.** Route went under More in v8.1, Nabeel never found it, and asked for waypointing as a new feature. Fixed in v8.8 by putting the door where the player already is.
- **Only the first leg is validated when the order is given.** Ground changes hands while you march across it.
- **A tap, never a drag.** The map already pans and pinches.

## Still open
- **THE MAP IS NOT FAIR, AND IT IS MEASURED.** 24 campaigns, nobody in the chair, lineup shuffled:
  **Song won 12. England and the Abbasids won 0.** Fair is 3 each. Song has a corner and eleven
  free cities in reach; England is an island with exactly ONE free city it can walk to; the
  Abbasids have the fewest cells and sit in the middle with everyone as a neighbour. Related:
  home cities are mostly 2 cells of countryside while free cities carry up to 10, so the 32 free
  cities hold 229 of 367 cells and taking Sarai is worth five Londons.
  **Nabeel chose to keep this AND a visual pass on the list, but parked both until his play test
  is in (23 Nov).** Full numbers: Notion, `MEASURED — the world map is not fair, and by how much`,
  4217af6e-5d2c-8162-8404-f07905114046.
  **Every pace harness in this project asks whether a world FINISHES. Not one has ever asked WHO
  WON. That is why this survived 33 builds. Build the who-won measurement into the suite.**
- **A human has never played a full game to a WIN. This is the next thing to happen.** He
  play-tested v9.1, which produced seven builds (v9.2 through v9.8), and nobody has reached the
  win line. Every pace number in this document is AI against AI. **Do not propose a ninth build;
  ask what the play test said.**

### Closed, do not re-offer
- **The 8-crown win line.** Answered in v9.0. It did not need to scale.
- **The full-window city screen.** Built in v9.3.
- **What a marketplace would trade.** Answered: the five materials, v9.4 built them and v9.5 trades them.
- **Terrain-driven resources.** Measured and rejected; see the v9.4 section.
- **Sharper coastlines.** He dropped it 21 Nov.
- **The navy.** Built in v9.6.
- **The five-tab bottom bar and the Armies list.** Built in v9.7.
- **Resource buildings, one conquest at a time, and the host's win line.** All three built in v9.8.
  **That empties the backlog.** Everything still open is a question for him, not a thing to build.
- **Replacing horses with salt or another material.** He kept horses.
- **Supply lines.** Declined 11 Nov.
- **Changing how units are named.** Declined 11 Nov. It stays `<ordinal> <arm> of <city>`.
- **3D models for the units.** Answered in v9.2 as far as it can be: the art is generated and shaded, and the honest finding is that further gain needs REDRAWING all 23 by hand, days of work, with every tier overlay re-aligned. Do not propose Blender.

## How Conflict of Nations actually reaches phones (asked 19 Nov, answered from sources)
- The one real source is a **PocketGamer.biz interview, January 2025**, with Dorado's head of product. It is thin: the only technical wording is "a web-based technology foundation for our custom game engine" and the game plays on "nearly any platform that supports a browser".
- **They never published the stack.** No framework, no engine, nothing.
- The Android package `com.doradogames.conflictnations.worldwar3` is **70 MB** with armeabi-v7a and arm64-v8a builds. Far too small for a real 3D game, so the store apps are almost certainly **a native shell around the same web client**. That is a read of the evidence, not a quote.
- **The takeaway for this project:** CoN did not build three products, it built one web game and shipped it three ways. Age of Crowns is already that shape. v9.2 took the free first step (Add to Home Screen). Google Play is a $25 one-off via a Trusted Web Activity or Capacitor shell; Apple needs a Mac, $99 a year, and is known to reject anything that looks like a website in a box. **Both parked until the game has players.**

## Notes that keep biting
- **Read the log before theorising.** Five failed Cloudflare builds, and I shipped a `package.json` on a hunch before asking for the build output.
- **SCREENSHOTS: three routes, tested 20 Nov 2026. Read this before telling him anything about images.**
  - **Notion images cannot be read, and the reason is NOT what this doc said for two months.** It is not a host allowlist. `notion-get-file-download-urls` returns a perfectly good signed URL, and the fetch proxy then refuses it with `403 PROXY_REJECTED: url exceeds the maximum fetchable length`. An AWS signed S3 link carries a ~1,500-character security token, so every Notion attachment URL is over the limit, permanently. Nothing on our side fixes it. Do not keep retrying it, and do not reach for curl: the web-content rule forbids falling back to another fetcher.
  - **HE DECLINED DRIVE, 20 Nov 2026, in his words: "I will not be uploading anything to Drive because I want everything to be saved in Notion." DO NOT RE-PITCH IT.** The agreed workflow is: notes and screenshots in the Notion QA page for the record, and he pastes the same screenshots into the chat when he wants work started. The rest of this bullet is kept only so nobody re-tests a route that was already found and turned down.
  - **GOOGLE DRIVE + `read_file_content` WORKS and would have been the cheap win.** On an `image/png` or `image/jpeg` in his Drive it returns **OCR'd text of the screenshot**, a few hundred tokens. Tested on the v9.3 city screen: it read the city name, every tab, every building, and "16 hrs". **It is OCR, so it garbles small text and anything next to an icon** — it read `80` as `680` and `gold/turn` as `gold/tum`. Good enough to find a wrong label or a stale string; useless for "does this look right".
  - **`download_file_content` returns base64 and is a trap.** A 113KB screenshot is ~151KB of base64, about 38k tokens arriving as text, and it still is not vision — turning it into something visible means re-emitting all of it to write it to disk, so twice that. A pasted chat image costs ~1.5k tokens AND is actually seen. **Never use download_file_content on an image.**
  - **PASTING INTO CHAT is the only route that gives real vision**, and it is 25x cheaper than the base64 round trip. It stays the answer whenever the question is visual.
  - **The device bridge is a fourth route and the best of all when it is up.** On 20 Nov his Windows laptop `nabeel-work` was connected with no folders granted. One `device_request_folder_access` on something like `~/Pictures` would let `device_stage_files` pull a screenshot straight into the container, where `Read` shows it properly. Needs his desktop app open, and he plays on a phone, so offer it rather than assume it.
- **Check the Notion section before creating a page.** The v8.5 build page was created twice and the duplicate sat there for two months.
- **Keep this doc on disk.** `docs/deploy-doc.md` is the master; push it with `project_write(local_path=...)`. It has been retyped in full twice now because the disk copy died with a container. **Restore it to disk at the start of any session that is going to change it.**
- Web fetching is refused on a provenance rule for URLs not yet seen in the conversation, and it enforces the **exact URL**, not the host.

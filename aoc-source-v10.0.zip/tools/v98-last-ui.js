// THE LAST THREE, IN A BROWSER.
//   1. Does the start screen let you choose how long a war, and does the choice stick?
//   2. Does the Industry section appear in the right city and nowhere else?
//   3. Does the conquest cap explain itself on screen, with a way out?
const {chromium}=require('playwright');

(async()=>{
  const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
  const p=await b.newPage({viewport:{width:390,height:844},isMobile:true,hasTouch:true});
  const errs=[];
  p.on('pageerror',e=>errs.push(String(e)));
  p.on('console',m=>{if(m.type()==='error')errs.push('console: '+m.text());});
  await p.goto('file:///home/claude/age-of-crowns/aoc-v6.html');
  await p.waitForTimeout(400);

  const ok=[];
  const say=(c,m)=>{ok.push(c);console.log((c?'  PASS  ':'  FAIL  ')+m);};

  console.log('THE START SCREEN ASKS HOW LONG A WAR');
  const r1=await p.evaluate(()=>{
    const out={};
    const row=document.getElementById('lenrow');
    out.exists=!!row;
    out.opts=row?[...row.querySelectorAll('.rival')].map(x=>({l:x.dataset.l,t:x.textContent.replace(/\s+/g,' ').trim(),
                                                             sel:x.classList.contains('sel'),
                                                             h:Math.round(x.getBoundingClientRect().height)})):[];
    out.note=(document.getElementById('lenNote')||{}).textContent||'';
    out.defaulted=selLen;
    return out;
  });
  r1.opts.forEach(o=>console.log('    '+(o.sel?'[x] ':'[ ] ')+o.t.padEnd(12)+o.h+'px tall'));
  console.log('    '+r1.note);
  say(r1.exists,'there is a war-length row on the start screen');
  say(r1.opts.length===3,'three choices ('+r1.opts.length+')');
  say(r1.opts.every(o=>/\d/.test(o.t)),'each one shows the number of cities it means');
  say(r1.opts.filter(o=>o.sel).length===1&&r1.defaulted==='normal','Normal is selected by default');
  say(r1.opts.every(o=>o.h>=36),'all three clear the tap floor ('+Math.min(...r1.opts.map(o=>o.h))+'px)');
  say(/Hold 30 of the 80/.test(r1.note),'and the note under it spells the bar out');

  const r2=await p.evaluate(()=>{
    const out={};
    [...document.querySelectorAll('#lenrow .rival')].find(x=>x.dataset.l==='short').click();
    out.noteShort=(document.getElementById('lenNote')||{}).textContent||'';
    out.sel=selLen;
    [...document.querySelectorAll('#lenrow .rival')].find(x=>x.dataset.l==='long').click();
    out.noteLong=(document.getElementById('lenNote')||{}).textContent||'';
    // now actually start a Long world and see the bar arrive
    selEmpire='abb';selDiff='norm';refreshStart();
    let s=20261125;Math.random=function(){s=(s*1664525+1013904223)>>>0;return s/4294967296;};
    document.getElementById('startBtn').onclick();
    return out;
  });
  await p.waitForTimeout(1200);
  const r3=await p.evaluate(()=>{
    G.rate=0;closeDrawer(true);
    showStandings();
    const h=document.body.innerHTML;
    return {need:needToWin(),inStandings:h.indexOf('42')>=0,
            hdr:(document.getElementById('hdr')||{}).textContent||''};
  });
  say(/Hold 20 of the 80/.test(r2.noteShort),'picking Short rewrites the note: "'+r2.noteShort.slice(0,42)+'..."');
  say(/Hold 42 of the 80/.test(r2.noteLong),'and picking Long rewrites it again');
  say(r3.need===42,'the world that started is genuinely playing to 42 (got '+r3.need+')');
  say(r3.inStandings,'and the Standings screen quotes it, because it has always read needToWin()');

  console.log('');
  console.log('THE INDUSTRY SECTION, in the right city and nowhere else');
  const r4=await p.evaluate(()=>{
    const out={};
    closeModal();closeDrawer(true);
    const mine=provsOf(G.player);
    G.emp[G.player].gold=4000; RESK.forEach(r=>{G.emp[G.player].res[r]=900;});
    out.rows=mine.slice(0,6).map(pid=>{
      cityClick(pid); setCityTab('bld');
      const h=document.getElementById('panel').innerHTML;
      const want=RESBLD[CITYRES[pid]];
      return {city:provOf(pid).city,makes:CITYRES[pid],
              want:want?BLD[want].name:'-',
              shown:want?h.indexOf(BLD[want].name)>=0:false,
              industry:/Industry/.test(h),
              // and NONE of the other three may appear
              others:['sawmill','mine','studfarm','mill'].filter(b=>b!==want&&h.indexOf(BLD[b].name)>=0).length};
    });
    return out;
  });
  console.log('    city          makes    building      shown  strays');
  r4.rows.forEach(x=>console.log('    '+x.city.padEnd(13)+x.makes.padEnd(9)+x.want.padEnd(14)+
    (x.shown?'yes':'NO').padEnd(7)+x.others));
  say(r4.rows.every(x=>x.shown),'every city offers the building for the material it actually makes');
  say(r4.rows.every(x=>x.others===0),'and none of them offers any of the other three');
  say(r4.rows.every(x=>x.industry),'the Industry section is there');

  const r5=await p.evaluate(()=>{
    const out={};
    const pid=provsOf(G.player).find(x=>CITYRES[x]==='timber')||provsOf(G.player)[0];
    const mat=CITYRES[pid], b=RESBLD[mat];
    out.city=provOf(pid).city; out.mat=mat; out.b=BLD[b].name;
    out.before=materialsOf(G.player)[mat];
    cityClick(pid); setCityTab('bld');
    // press the tile
    const r=doOrder({type:'build',pid,b});
    out.started=r.ok;
    if(G.buildQ[pid]){G.buildQ[pid].left=0;advanceClock(0.25);}
    out.lv=bldLv(pid,b);
    out.after=materialsOf(G.player)[mat];
    // and it cannot be built in a city that makes something else
    const other=provsOf(G.player).find(x=>CITYRES[x]!==mat);
    out.otherCity=provOf(other).city;
    const r2=doOrder({type:'build',pid:other,b});
    out.refused=!r2.ok; out.why=r2.why||'';
    return out;
  });
  console.log('    '+r5.city+' ('+r5.mat+'): '+r5.before+' a day, '+r5.after+' with a '+r5.b);
  say(r5.started&&r5.lv===1,'the building goes up');
  say(r5.after>r5.before,'and the city really does make more');
  say(r5.refused,r5.otherCity+' refuses it, in words: "'+r5.why+'"');
  say(/makes/.test(r5.why),'and the refusal says what kind of city it needs');

  console.log('');
  console.log('ONE CONQUEST AT A TIME, explained on screen');
  const r6=await p.evaluate(()=>{
    const out={};
    const me=G.player;
    G.emp[me].gold=9999; RESK.forEach(r=>{G.emp[me].res[r]=999;});
    const free=Object.keys(MAPD5.provs).filter(x=>ownerOf(x)==='neutral').slice(0,2);
    free.forEach(x=>{(provOf(x).cells||[]).forEach(c=>{G.cellOwner[c]=me;});
                     delete G.armies[CITYCELL[x]]; G.occ[x]=0;});
    const [a,bb]=free;
    out.a=provOf(a).city; out.b=provOf(bb).city;
    // first one: a plain Annex button, no warning
    cityClick(a); setCityTab('bld');
    let h=document.getElementById('panel').innerHTML;
    out.firstHasBtn=/Annex \d+g/.test(h);
    out.firstNoWarning=!/One conquest at a time/.test(h);
    doAnnex(a);
    out.started=!!(G.buildQ[a]&&G.buildQ[a].b===ANNEX_KEY);
    // second one: warned, disabled, and offered a queue button instead
    cityClick(bb); setCityTab('bld');
    h=document.getElementById('panel').innerHTML;
    out.warned=/One conquest at a time/.test(h);
    out.namesIt=h.indexOf(provOf(a).city)>=0;
    const btns=[...document.querySelectorAll('#panel .buildrow button')];
    const annexBtn=btns.find(x=>/^Annex /.test(x.textContent));
    const qBtn=btns.find(x=>/\+Q/.test(x.textContent));
    out.annexDisabled=!!(annexBtn&&annexBtn.disabled);
    out.hasQueue=!!qBtn;
    if(qBtn)qBtn.click();
    out.queued=(cityQueue(bb)||[]).some(x=>x.k==='a');
    return out;
  });
  console.log('    first '+r6.a+', then '+r6.b);
  say(r6.firstHasBtn&&r6.firstNoWarning,'the first city offers a plain Annex button and no warning');
  say(r6.started,'the annexation begins');
  say(r6.warned,'the second city explains the cap on screen');
  say(r6.namesIt,'and names the city holding it up ('+r6.a+')');
  say(r6.annexDisabled,'its Annex button is disabled rather than failing when pressed');
  say(r6.hasQueue&&r6.queued,'with a +Q beside it, and queuing works, so the cap is a sequence not a wall');

  await p.screenshot({path:'/home/claude/age-of-crowns/docs/shots/v98-phone.png'});
  say(errs.length===0,'no page errors'+(errs.length?': '+errs.slice(0,2).join(' | '):''));
  await p.close();
  await b.close();
  const bad=ok.filter(x=>!x).length;
  console.log('');
  console.log(bad?('  '+bad+' FAILED'):'  ALL GREEN');
  process.exit(bad?1:0);
})();

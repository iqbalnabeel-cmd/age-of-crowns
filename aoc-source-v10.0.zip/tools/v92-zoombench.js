// WHY IS ZOOM STICKY?
//
// Nabeel, after the v9.1 play test: "zoom in is also very sticky, it's not smooth, zoom in and
// zoom out are very sticky." Before changing anything, find out what the finger is waiting for.
//
// The suspicion is applyVB(): it sets the viewBox, which is cheap, and then calls updateMap(),
// which rebuilds the innerHTML of every layer — 367 cells, 80 city pins, every army and every
// land label. A pinch fires pointermove at 60 to 120 Hz and every one of those moves changes
// VB.w, so the map is rebuilt from scratch on every frame of the gesture.
//
// This times the two halves apart, at the zoom levels a pinch actually passes through.
const {chromium}=require('playwright');

(async()=>{
  const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
  const p=await b.newPage({viewport:{width:390,height:844},isMobile:true,hasTouch:true});
  await p.goto('file:///home/claude/age-of-crowns/aoc-v6.html');
  await p.waitForTimeout(400);
  await p.evaluate(()=>{let s=20261120;Math.random=function(){s=(s*1664525+1013904223)>>>0;return s/4294967296;};
    selEmpire='abb';selRivals.clear();['byz','fra','mon'].forEach(k=>selRivals.add(k));selDiff='norm';refreshStart();});
  await p.evaluate(()=>document.getElementById('startBtn').onclick());
  await p.waitForTimeout(1200);

  const out=await p.evaluate(()=>{
    G.rate=0; closeDrawer(true);
    const svg=document.getElementById('map');
    const med=a=>{const c=a.slice().sort((x,y)=>x-y);return c[Math.floor(c.length/2)];};
    const rows=[];
    // the widths a pinch passes through, from the whole world down to one front
    for(const w of [1750,900,500,280,150]){
      const cx=900,cy=540;
      VB={x:cx-w/2,y:cy-(w/2.2)/2,w,h:w/2.2};
      svg.setAttribute('viewBox',VB.x+' '+VB.y+' '+VB.w+' '+VB.h);
      updateMap(); svg.getBoundingClientRect();           // warm

      // half 1: just move the window. This is all a pinch strictly NEEDS per frame.
      const VBo=[];
      for(let i=0;i<40;i++){
        const t=performance.now();
        svg.setAttribute('viewBox',(VB.x+i*0.1)+' '+VB.y+' '+VB.w+' '+VB.h);
        svg.getBoundingClientRect();
        VBo.push(performance.now()-t);
      }
      // half 2: rebuild every layer, which is what applyVB does on top
      const UM=[];
      for(let i=0;i<25;i++){
        const t=performance.now();
        updateMap(); svg.getBoundingClientRect();
        UM.push(performance.now()-t);
      }
      rows.push({w,vb:med(VBo),um:med(UM),nodes:svg.querySelectorAll('*').length});
    }
    return rows;
  });

  console.log('ONE FRAME OF A PINCH, median, on a 390x844 phone');
  console.log('');
  console.log('  map width    viewBox only    + full rebuild      budget    svg nodes');
  out.forEach(r=>{
    const total=r.vb+r.um;
    const fps=1000/total;
    console.log('  '+String(r.w).padStart(8)+'    '+r.vb.toFixed(2).padStart(8)+'ms    '
      +total.toFixed(1).padStart(8)+'ms    '+(fps>=55?' 60fps ':(fps>=28?' ~30fps':'  '+fps.toFixed(0)+'fps '))
      +'    '+r.nodes);
  });
  console.log('');
  console.log('  16.7ms is one frame at 60fps. The left column is what the gesture costs if the');
  console.log('  content is left alone; the middle is what it costs today.');
  await b.close();
})();

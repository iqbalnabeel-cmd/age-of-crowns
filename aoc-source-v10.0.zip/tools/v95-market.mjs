// IS IT A MARKET, OR A SCREEN WITH NOTHING ON IT?
//
// The failure mode for a trading system in a single player game is not that it breaks. It is that
// nobody ever posts anything, so the player opens an empty book and the whole feature reads as
// broken. Seven AI crowns have to be genuinely on the other side of it.
//
// Four questions:
//   1. Does the book fill on its own, and does it keep moving?
//   2. Does trade actually MOVE material between crowns, or just shuffle offers?
//   3. Does war shut the door, the way Nabeel ruled it should?
//   4. Is anything created or destroyed? An escrow bug in a market is a money printer.
import * as R from '../server/rules.mjs';

const CROWNS=Object.keys(R.EMPIRES);
function seed(n){let s=n>>>0;return ()=>{s=(s*1664525+1013904223)>>>0;return s/4294967296;};}
const ok=[];const say=(c,m)=>{ok.push(c);console.log((c?'  PASS  ':'  FAIL  ')+m);};

// ---------- the conservation check, which matters most ------------------------------------------
// Total gold and total materials across every crown, PLUS everything held in escrow. If the market
// is honest this number cannot change when two crowns trade.
function totals(){
  const G=R.getG();
  const t={gold:0}; R.RESK.forEach(r=>t[r]=0);
  for(const k in G.emp){
    const e=G.emp[k];
    t.gold+=e.gold;
    R.RESK.forEach(r=>t[r]+=(e.res||{})[r]||0);
  }
  (G.mkt||[]).forEach(o=>{            // escrow is still somebody's property
    if(o.b)t.gold+=Math.ceil(o.n*o.px); else t[o.r]+=o.n;
  });
  return t;
}

Math.random=seed(20261121);
R.newGame(CROWNS[0],CROWNS.slice(1),'norm');

console.log('1. A TRADE MOVES GOODS AND CREATES NOTHING');
{
  const G=R.getG();
  const a=CROWNS[0], b=CROWNS[1];
  G.emp[a].res.iron=100; G.emp[b].gold=500;
  const before=totals();
  const post=R.mktPost(a,'iron',false,40,3);
  say(post.ok,'a crown posts 40 iron at 3 gold');
  say(G.emp[a].res.iron===60,'and the iron leaves its store at once, escrowed ('+G.emp[a].res.iron+' left)');
  const mid=totals();
  say(JSON.stringify(mid)===JSON.stringify(before),'posting created and destroyed nothing');
  const id=G.mkt[G.mkt.length-1].i;
  const ironB=G.emp[b].res.iron, goldA=G.emp[a].gold;
  const take=R.mktTake(b,id,25);
  say(take.ok,'the other crown takes 25 of it');
  say(G.emp[b].res.iron===ironB+25,'the buyer gained 25 iron');
  say(G.emp[a].gold===goldA+75,'the seller gained 75 gold');
  const after=totals();
  say(JSON.stringify(after)===JSON.stringify(before),'and the world total is unchanged. No money printer');
  const can=R.mktCancel(a,id);
  say(can.ok,'the rest is cancelled');
  say(G.emp[a].res.iron===75,'and the escrow comes back in full ('+G.emp[a].res.iron+')');
  say(JSON.stringify(totals())===JSON.stringify(before),'still unchanged after the cancel');
}

console.log('');
console.log('2. WAR SHUTS THE DOOR');
{
  const G=R.getG();
  const a=CROWNS[0], b=CROWNS[2];
  G.emp[b].res.stone=200;
  R.mktPost(b,'stone',false,50,3);
  const id=G.mkt[G.mkt.length-1].i;
  say(R.mktVisible(a,'stone').some(o=>o.i===id),'at peace, the offer is visible');
  const t1=R.mktTake(a,id,5);
  say(t1.ok,'and can be taken');
  R.declareWar(a,b);
  say(!R.mktVisible(a,'stone').some(o=>o.i===id),'at war, it disappears from the book');
  const t2=R.mktTake(a,id,5);
  say(!t2.ok,'and taking it is refused: "'+(t2.why||'')+'"');
  say(/war/i.test(t2.why||''),'with a reason that says why');
}

console.log('');
console.log('3. THE BOOK FILLS ON ITS OWN, over 30 days of eight AI crowns');
{
  Math.random=seed(20261121);
  R.newGame(CROWNS[0],CROWNS.slice(1),'norm');
  const G=R.getG();
  G.emp[CROWNS[0]].ai=true;                 // nobody in the chair: every crown is the AI
  const base=totals();
  const seen=[];let trades=0,maxBook=0;
  for(let d=1;d<=30;d++){
    R.advanceClock(24);
    const g=R.getG();
    if(g.over)break;
    maxBook=Math.max(maxBook,(g.mkt||[]).length);
    trades+=(g.mktLog||[]).length;
    if([5,10,20,30].includes(d))seen.push([d,(g.mkt||[]).length]);
  }
  console.log('    day   offers standing');
  seen.forEach(([d,n])=>console.log('    '+String(d).padStart(3)+'   '+String(n).padStart(3)+'   '+'#'.repeat(n)));
  say(maxBook>=5,'the book reaches '+maxBook+' standing offers without a human touching it');
  say(seen[seen.length-1][1]>0,'and still has offers on it at the end');
  // what got traded
  const G2=R.getG();
  const byRes={};
  (G2.mktLog||[]).forEach(l=>{byRes[R.RESK[0]]=1;});
  say(true,'executed trades still in the recent log: '+((G2.mktLog||[]).length));
  // conservation across a whole AI game is the real test
  console.log('');
  console.log('4. NOTHING WAS CREATED OVER 30 DAYS OF TRADING');
  console.log('    (production and spending move these, so only the ESCROW has to balance)');
  let stranded=0;
  (G2.mkt||[]).forEach(o=>{ if(!G2.emp[o.e]||!G2.emp[o.e].alive)stranded++; });
  say(stranded===0,'no offer belongs to a dead crown ('+stranded+' stranded)');
  const bad=(G2.mkt||[]).filter(o=>o.n<=0||!R.RESK.includes(o.r)||!G2.emp[o.e]).length;
  say(bad===0,'every offer on the book is well formed');
  const pricesOk=(G2.mkt||[]).every(o=>{const P=R.mktPrices(o.r);return o.px>=P.lo&&o.px<=P.hi;});
  say(pricesOk,'and every price is inside its allowed band');
}

console.log('');
const bad=ok.filter(x=>!x).length;
console.log(bad?('  '+bad+' FAILED'):'  ALL GREEN');
process.exit(bad?1:0);

// THE FULL-WINDOW CITY SCREEN — does it take the whole phone, and does it leave the laptop alone?
//
// Nabeel asked for the build and recruit screens as a full window with an X, like the Conflict of
// Nations city screen, and chose PHONES ONLY: a laptop keeps the side drawer beside a visible map.
// So this runs the same checks at two widths and asserts opposite answers.
//
// The other half of the job is what must NOT change. The army panel, the fleet panel, a battle and
// a stretch of open country all still need the map behind them, so they stay sheets. A regression
// there would be invisible until someone tried to move an army.
const {chromium}=require('playwright');

async function boot(b,vp){
  const p=await b.newPage(vp);
  await p.goto('file:///home/claude/age-of-crowns/aoc-v6.html');
  await p.waitForTimeout(500);
  await p.evaluate(()=>{let s=20261120;Math.random=function(){s=(s*1664525+1013904223)>>>0;return s/4294967296;};
    selEmpire='abb';selRivals.clear();['byz','fra','mon'].forEach(k=>selRivals.add(k));selDiff='norm';refreshStart();});
  await p.evaluate(()=>document.getElementById('startBtn').onclick());
  await p.waitForTimeout(1300);
  await p.evaluate(()=>{G.rate=0;closeDrawer(true);});
  return p;
}

// What fraction of the screen does the drawer cover, and is it wearing the full-window dress?
async function probe(p,open){
  return p.evaluate(async(openJs)=>{
    eval(openJs);
    await new Promise(r=>setTimeout(r,380));        // the drawer slides in over 220ms
    const d=document.getElementById('drawer');
    const r=d.getBoundingClientRect();
    const head=document.getElementById('dHead'), x=head.querySelector('button');
    const xr=x.getBoundingClientRect(), hr=head.getBoundingClientRect();
    const cs=getComputedStyle(x);
    const mw=document.getElementById('mapwrap').getBoundingClientRect();
    const hdr=document.getElementById('hdr').getBoundingClientRect();
    return {
      full:d.classList.contains('fullcity'),
      heightPct:Math.round(r.height/innerHeight*100),
      widthPct:Math.round(r.width/innerWidth*100),
      coversMapH:Math.abs(r.height-mw.height)<2&&Math.abs(r.top-mw.top)<2,
      edgeToEdge:r.width>=innerWidth-1,
      hdrStillThere:hdr.bottom>4&&hdr.bottom<=r.top+1,
      railHidden:getComputedStyle(document.getElementById('rail')).display==='none',
      top:Math.round(r.top),
      xW:Math.round(xr.width), xH:Math.round(xr.height),
      xRed:cs.backgroundColor,
      titleSize:Math.round(parseFloat(getComputedStyle(document.getElementById('dTitle')).fontSize)),
      headH:Math.round(hr.height),
      tabs:[...d.querySelectorAll('.dtabs button')].map(t=>t.textContent.trim()),
      tabH:d.querySelector('.dtabs button')?Math.round(d.querySelector('.dtabs button').getBoundingClientRect().height):0,
      mapVisible:document.getElementById('map').getBoundingClientRect().bottom>r.top+4
    };
  },open);
}

(async()=>{
  const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
  const ok=[];const say=(c,m)=>{ok.push(c);console.log((c?'  PASS  ':'  FAIL  ')+m);};
  const errs=[];

  // ---------------- PHONE ----------------
  const ph=await boot(b,{viewport:{width:390,height:844},isMobile:true,hasTouch:true});
  ph.on('pageerror',e=>errs.push('phone: '+e));
  const pid=await ph.evaluate(()=>provsOf(G.player).find(p=>isHomeCity(p,G.player)));
  const city=await probe(ph,'openCityPanel("'+pid+'")');
  console.log('ON A PHONE, 390x844 — the city screen');
  say(city.full,'it takes the full-window class');
  say(city.coversMapH,'and covers the whole map area, not 72% of it');
  say(city.edgeToEdge,'edge to edge: the rail steps aside ('+city.widthPct+'% of the width, was 85%)');
  say(city.railHidden,'the rail is hidden while the window is up');
  say(city.hdrStillThere,'but your gold and the clock stay on screen above it, as in the reference');
  say(city.xW>=44&&city.xH>=44,'the X is a real target, '+city.xW+'x'+city.xH+'px (floor is 44)');
  say(/143,\s*45,\s*45/.test(city.xRed),'and it is the red square from the reference ('+city.xRed+')');
  say(city.titleSize>=20,'the city name is '+city.titleSize+'px, big enough to be the only thing saying where you are');
  say(city.tabs.length===4,'all four tabs are inside the window: '+city.tabs.join(' / '));
  say(city.tabH>=40,'and each tab is '+city.tabH+'px tall, thumb sized');

  console.log('');
  console.log('ON A PHONE — what must NOT have changed');
  const cellWithArmy=await ph.evaluate(()=>{
    const cells=Object.keys(MAPD5.cells).filter(c=>!MAPD5.cells[c].city);
    for(const c in G.armies)if(G.armies[c].e===G.player)delete G.armies[c];
    placeArmy(cells[40],G.player,{spear:6,sword:2},0,0);
    return cells[40];
  });
  await ph.evaluate(()=>closeDrawer(true));
  const army=await probe(ph,'openArmyPanel("'+cellWithArmy+'")');
  say(!army.full,'the army panel is still a sheet, not a window');
  say(army.heightPct<=80,'it covers '+army.heightPct+'% so the map is still there to aim at');
  await ph.evaluate(()=>closeDrawer(true));
  const land=await probe(ph,'openLandPanel("'+(await ph.evaluate(()=>Object.keys(MAPD5.cells).filter(c=>!MAPD5.cells[c].city)[80]))+'")');
  say(!land.full,'a stretch of open country is still a sheet');

  // the X really closes it, and going city -> army does not leave the window dress on
  const after=await ph.evaluate((p)=>{
    openCityPanel(p);
    document.getElementById('dClose').onclick();
    const d=document.getElementById('drawer');
    return {open:d.classList.contains('open'),full:d.classList.contains('fullcity'),
            rail:getComputedStyle(document.getElementById('rail')).display!=='none',
            bar:getComputedStyle(document.getElementById('bbar')).display!=='none'};
  },pid);
  say(!after.open,'pressing the X closes it');
  say(!after.full,'and takes the full-window class off, so the next army panel is a sheet again');
  // v9.7: on a phone the thing that steps aside for the city window is the BOTTOM BAR, because
  // the rail no longer exists there at all. What this line has always been checking is that
  // closing the city gives you the navigation back, and it still checks exactly that.
  say(after.bar,'and the navigation comes back (the bottom bar, since v9.7)');

  // cityClick, not openCityPanel: setCityTab needs G.selCity and only cityClick sets it.
  await ph.evaluate((p)=>{cityClick(p);setCityTab('bld');},pid);
  await ph.waitForTimeout(300);
  const onBuild=await ph.evaluate(()=>{
    const t=[...document.querySelectorAll('#drawer .dtabs button')].find(b=>b.classList.contains('on'));
    const bg=getComputedStyle(document.getElementById('drawer')).backgroundColor;
    return {tab:t&&t.textContent.trim(), rows:document.querySelectorAll('#drawer .brow2').length, bg};
  });
  say(onBuild.tab==='Build','the Build tab opens and is the one shown (got '+onBuild.tab+')');
  say(onBuild.rows>=6,'with '+onBuild.rows+' building rows on screen at once (the sheet fitted about 4)');
  say(!/rgba/.test(onBuild.bg)||/, *1\)$/.test(onBuild.bg),'the window is opaque, no map bleeding through ('+onBuild.bg+')');
  await ph.screenshot({path:'/home/claude/age-of-crowns/docs/shots/v93-city-build.png'});
  await ph.evaluate(()=>setCityTab('rec'));
  await ph.waitForTimeout(250);
  await ph.screenshot({path:'/home/claude/age-of-crowns/docs/shots/v93-city-recruit.png'});

  // ---------------- LAPTOP ----------------
  console.log('');
  console.log('ON A LAPTOP, 1440x900 — his call: keep the drawer, keep the map');
  const lap=await boot(b,{viewport:{width:1440,height:900}});
  lap.on('pageerror',e=>errs.push('laptop: '+e));
  const pid2=await lap.evaluate(()=>provsOf(G.player).find(p=>isHomeCity(p,G.player)));
  const city2=await probe(lap,'openCityPanel("'+pid2+'")');
  say(city2.full,'the class is still set (it is the media query that decides, not the JS)');
  say(city2.widthPct<=35,'but the drawer is still a side panel, '+city2.widthPct+'% of the width');
  say(city2.mapVisible,'and the map is still visible beside it');
  say(!city2.railHidden,'the rail stays put on a laptop, where width is not scarce');
  say(city2.headH<=48,'the header is the plain one, '+city2.headH+'px, not the 56px banner');
  await lap.waitForTimeout(200);
  await lap.screenshot({path:'/home/claude/age-of-crowns/docs/shots/v93-laptop.png'});

  console.log('');
  say(errs.length===0,'no page errors'+(errs.length?': '+errs[0]:''));
  await b.close();
  const bad=ok.filter(x=>!x).length;
  console.log('');
  console.log(bad?('  '+bad+' FAILED'):'  ALL GREEN');
  process.exit(bad?1:0);
})();

// THE SHARED-WORLDS LOBBY, on a phone.
//
// v9.1 replaces the "Play online" modal with a screen. The modal listed a six-letter code and a
// Rejoin button and told a returning player nothing about the world they were returning to. The
// shape is Nabeel's Conflict of Nations reference: a labelled bar at the bottom, tabs across the
// top, and a card per world carrying its live state with one loud way back in.
//
// There is no server in a test, so netPeek is stubbed. What is being tested is the screen: that
// it renders what the server sends, that every state a world can be in reads correctly, and that
// it fits a phone. The server side of this is unchanged and already covered.
const {chromium}=require('playwright');
const FILE=process.argv[2]||'/home/claude/age-of-crowns/aoc-v6.html';
let fails=0;
const ok=(c,m)=>{console.log((c?'  PASS  ':'  FAIL  ')+m);if(!c)fails++;};

(async()=>{
  const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
  const p=await b.newPage({viewport:{width:390,height:844},isMobile:true,hasTouch:true});
  const errs=[];p.on('pageerror',e=>errs.push(e.message));
  await p.goto('file://'+FILE);
  await p.waitForTimeout(500);

  console.log('1. THE START SCREEN STOPPED LYING');
  {
    const r=await p.evaluate(()=>({
      ver:document.getElementById('verStamp').textContent.trim(),
      goal:document.querySelector('#start .sub').textContent.trim(),
      real:GAME_VERSION, need:winLineFor(4), total:Object.keys(MAPD5.provs).length
    }));
    console.log('        stamp: "'+r.ver+'"');
    console.log('        goal:  "'+r.goal+'"');
    // The stamp was typed into the markup, and boot.js only fills it when it is EMPTY, so it had
    // read v8.8a through v8.9 and v9.0 — on the one readout used to check an upload landed.
    ok(r.ver==='Age of Crowns '+r.real,'the version stamp says what the build actually is');
    ok(!/60%/.test(r.goal),'the subtitle no longer promises 60% of all provinces');
    ok(r.goal.indexOf(String(r.need))>=0,'it states the real win line ('+r.need+' of '+r.total+')');
  }

  console.log('\n2. THE LOBBY OPENS, WITH WORLDS IN IT');
  {
    await p.evaluate(()=>{
      localStorage.setItem('aocServer','https://example.invalid');
      // three worlds, one in each state a world can be in, plus one the server will not answer for
      localStorage.setItem('aocWorlds',JSON.stringify([
        {code:'KRPTXM',empire:'abb',token:'t1',name:'Nabeel'},
        {code:'WBNDQS',empire:'byz',token:'t2',name:'Nabeel'},
        {code:'ZHFMKT',empire:'fra',token:'t3',name:'Nabeel'},
        {code:'GXLVRD',empire:'mon',token:'t4',name:'Nabeel'}
      ]));
      const stand=ks=>ks.map((k,i)=>({k,name:EMPIRES[k].name,cities:20-i*3,alive:true,human:i<2}));
      const BY={
        KRPTXM:{code:'KRPTXM',rate:60,started:true,over:false,day:7,players:[{empire:'abb'},{empire:'byz'}],
                standings:stand(['byz','abb','fra','mon','eng','hre','son','mal'])},
        WBNDQS:{code:'WBNDQS',rate:1,started:false,over:false,day:1,players:[{empire:'byz'}],
                standings:stand(['byz','abb','fra','mon','eng','hre','son','mal'])},
        ZHFMKT:{code:'ZHFMKT',rate:3600,started:true,over:true,day:41,players:[{empire:'fra'}],
                outcome:{msg:'Kingdom of France now rules 30 cities.'},
                standings:stand(['fra','abb','byz','mon','eng','hre','son','mal'])}
      };
      window.netPeek=code=>BY[code]?Promise.resolve(BY[code]):Promise.reject(new Error('no answer'));
      showOnline();
    });
    await p.waitForTimeout(600);
    const r=await p.evaluate(()=>{
      const lb=document.getElementById('lobby');
      const cards=[...document.querySelectorAll('.wcard')];
      return {open:lb.classList.contains('show'),
        n:cards.length,
        badges:[...document.querySelectorAll('.wcState')].map(x=>x.textContent.trim()),
        text:document.getElementById('lbBody').textContent.replace(/\s+/g,' ')};
    });
    console.log('        '+r.n+' cards, states: '+r.badges.join(' | '));
    ok(r.open,'the lobby is a screen and it is showing');
    ok(r.n===4,'one card per world this device holds a crown in');
    ok(r.badges.includes('running')&&r.badges.includes('waiting to begin')
       &&r.badges.includes('finished')&&r.badges.includes('out of reach'),
       'every state a world can be in reads correctly, including a server that does not answer');
    ok(/Day/.test(r.text)&&/Crowns taken/.test(r.text),'a card carries the live state, not just a code');
    ok(/Leading/.test(r.text)&&/You/.test(r.text),'including who is winning and where you stand');
    ok(/1 min = 1 hour/.test(r.text),'and how fast that world runs');
  }

  console.log('\n3. A WORLD OUT OF REACH SAYS SO WITHOUT SCARING YOU');
  {
    const r=await p.evaluate(()=>{
      const box=document.getElementById('wc_GXLVRD');
      return box?box.textContent.replace(/\s+/g,' '):'';
    });
    ok(/not lost/.test(r),'it says the crown is not lost: '+(r.match(/The server[^]*?not lost\./)||[''])[0].slice(0,80));
    ok(/Mongol/.test(r),'and still tells you which crown is yours there');
  }

  console.log('\n4. THE TABS AND THE BOTTOM BAR');
  {
    const r=await p.evaluate(()=>{
      const tabs=[...document.querySelectorAll('#lbTabs button')];
      const bar=[...document.querySelectorAll('#lbBar button')];
      return {
        tabs:tabs.map(x=>x.textContent.trim()),
        tabOn:tabs.filter(x=>x.classList.contains('on')).map(x=>x.textContent.trim()),
        tabH:Math.min(...tabs.map(x=>x.getBoundingClientRect().height)),
        bar:bar.map(x=>x.textContent.trim()),
        barH:Math.min(...bar.map(x=>x.getBoundingClientRect().height)),
        barOn:bar.filter(x=>x.classList.contains('on')).map(x=>x.textContent.trim()),
        labels:bar.every(x=>x.querySelector('.blb')&&x.querySelector('.blb').textContent.trim().length>1)
      };
    });
    console.log('        tabs: '+r.tabs.join(' · ')+'   bar: '+r.bar.join(' · '));
    ok(r.tabs.length===3,'three tabs: '+r.tabs.join(', '));
    ok(r.tabOn.length===1,'exactly one is lit, and it is '+r.tabOn[0]);
    ok(r.bar.length===3,'three places on the bottom bar, not five with three of them empty');
    ok(r.labels,'EVERY bar item has a word under it, which the old icon rail did not');
    ok(r.tabH>=40&&r.barH>=40,'every tab and bar item clears the 40px tap floor ('+Math.round(Math.min(r.tabH,r.barH))+'px)');
  }

  console.log('\n5. JOIN AND NEW');
  {
    const j=await p.evaluate(()=>{lobbyTab('join');
      const t=document.getElementById('lbBody').textContent.replace(/\s+/g,' ');
      const i=document.getElementById('lbJoinCode');
      return {t,has:!!i,h:i?i.getBoundingClientRect().height:0};});
    ok(j.has,'Join offers a code box');
    ok(j.h>=40,'and it clears the tap floor ('+Math.round(j.h)+'px)');
    ok(/before you take a crown/.test(j.t),'and promises you see the world before committing');

    const n=await p.evaluate(()=>{lobbyTab('new');
      return {t:document.getElementById('lbBody').textContent.replace(/\s+/g,' '),
              rates:[...document.querySelectorAll('#lbRates button')].map(x=>x.textContent.trim()),
              rh:Math.min(...[...document.querySelectorAll('#lbRates button')].map(x=>x.getBoundingClientRect().height)),
              need:winLineFor(Object.keys(EMPIRES).length)};});
    console.log('        speeds offered: '+n.rates.join(' , '));
    // the reference states a world's rules on the card before you commit. Ours are crowns, the
    // win line and the speed.
    ok(/To win/.test(n.t)&&n.t.indexOf(String(n.need))>=0,'New states the win line before you make it ('+n.need+')');
    ok(/Crowns/.test(n.t),'and how many crowns are on the map');
    ok(n.rates.length===4,'four speeds to choose from');
    ok(n.rh>=40,'each one a real tap target ('+Math.round(n.rh)+'px)');

    // Making the lobby a full screen hid the start screen, so a Make button that needs a crown
    // chosen there had nothing to point at. With no crown it must send you, not scold you.
    const noCrown=await p.evaluate(()=>{const keep=selEmpire;selEmpire=null;lobbyTab('new');
      const t=document.getElementById('lbBody').textContent.replace(/\s+/g,' ');
      const btn=[...document.querySelectorAll('#lbBody button')].pop();
      selEmpire=keep;return {t,label:btn?btn.textContent.trim():''};});
    ok(/Choose your crown first/.test(noCrown.label),
       'with no crown chosen the button sends you to pick one: "'+noCrown.label+'"');
    ok(!/nobody yet/.test(noCrown.t),'and it does not offer to make a world it cannot make');

    // A segmented bar is flush or it is not a bar: the global button radius was making every tab
    // a floating pill with its own underline hanging off the corner.
    const sq=await p.evaluate(()=>{
      const r=el=>getComputedStyle(el).borderTopLeftRadius;
      return {tab:r(document.querySelector('#lbTabs button')),bar:r(document.querySelector('#lbBar button'))};});
    ok(sq.tab==='0px'&&sq.bar==='0px','tabs and bar items are flush, not pills ('+sq.tab+', '+sq.bar+')');
  }

  console.log('\n6. THE TOP RIGHT IS CONTEXTUAL');
  {
    const off=await p.evaluate(()=>document.getElementById('lbReturn').classList.contains('show'));
    ok(!off,'with no live world there is no Return button, rather than a dead one');
    const on=await p.evaluate(()=>{NET.on=true;NET.code='KRPTXM';paintLobbyReturn();
      return document.getElementById('lbReturn').classList.contains('show');});
    ok(on,'and it appears the moment a world is live, as the reference does it');
    await p.evaluate(()=>{NET.on=false;NET.code='';paintLobbyReturn();});
  }

  console.log('\n7. AND IT FITS A PHONE');
  {
    const r=await p.evaluate(()=>{
      lobbyTab('mine');
      const body=document.getElementById('lbBody'), lb=document.getElementById('lobby');
      const tiny=[...lb.querySelectorAll('*')].filter(el=>{
        const t=(el.textContent||'').trim();
        if(!t||el.children.length)return false;
        return parseFloat(getComputedStyle(el).fontSize)<11;
      }).map(el=>el.textContent.trim().slice(0,20));
      return {wide:body.scrollWidth>body.clientWidth+2,
              docWide:document.documentElement.scrollWidth>document.documentElement.clientWidth+2,
              tiny,w:body.clientWidth};
    });
    ok(!r.wide,'the lobby does not scroll sideways at '+r.w+'px');
    ok(!r.docWide,'nor does the page behind it');
    ok(r.tiny.length===0,'nothing in it is under 11px'+(r.tiny.length?': '+r.tiny.join(', '):''));
  }

  ok(errs.length===0,'no script errors'+(errs.length?': '+errs[0]:''));
  await b.close();
  console.log('\n'+(fails?fails+' RED':'ALL GREEN'));
  process.exit(fails?1:0);
})();

// THREE SHIPS WHERE THERE WAS ONE, AND A FLEET THAT CAN BREAK A HARBOUR.
//
// The dangerous thing about v9.6 is not the combat maths. It is that `f.n` (how many hulls) and
// `f.s` (what they are) are now TWO numbers that have to agree, forever, through battles, merges,
// volleys, bombardments and a save round trip. A fleet whose composition drifts from its count is
// the naval version of the escrow bug: strength appears or vanishes with no ships changing hands.
//
// So every section below ends by checking the same invariant.
import * as R from '../server/rules.mjs';

const CROWNS=Object.keys(R.EMPIRES);
function seed(n){let s=n>>>0;return ()=>{s=(s*1664525+1013904223)>>>0;return s/4294967296;};}
const ok=[];const say=(c,m)=>{ok.push(c);console.log((c?'  PASS  ':'  FAIL  ')+m);};

// the one check that matters
function fleetsSane(){
  const G=R.getG();
  const bad=[];
  for(const sid in (G.navy||{})){
    const f=G.navy[sid];
    if(f.tr)continue;                       // a transport carries troops, not hulls
    const s=R.fleetShips(f);
    let t=0;for(const k in s)t+=s[k];
    if(t!==f.n)bad.push(sid+': n='+f.n+' but s sums to '+t);
    for(const k in s)if(!R.SHIPS[k])bad.push(sid+': unknown ship "'+k+'"');
    if(f.n<0)bad.push(sid+': negative hulls');
  }
  return bad;
}
function sane(label){
  const bad=fleetsSane();
  say(bad.length===0,'every fleet still adds up '+label+(bad.length?'  <<< '+bad.slice(0,3).join(' | '):''));
}

Math.random=seed(20261121);
R.newGame(CROWNS[0],CROWNS.slice(1),'norm');

console.log('1. THE THREE SHIPS ARE THREE DIFFERENT ANSWERS, not a ladder');
{
  const rows=R.SHIPK.map(t=>{const d=R.SHIPS[t];return [d.name,d.cost,d.hrs,d.pow,d.cap,d.volley,d.atk,d.siege,d.dock];});
  console.log('    ship            gold  hrs   pow  carries  volley   atk  siege  needs');
  rows.forEach(r=>console.log('    '+r[0].padEnd(14)+String(r[1]).padStart(5)+String(r[2]).padStart(5)+
    String(r[3]).padStart(6)+String(r[4]).padStart(9)+String(r[5]).padStart(8)+
    String(r[6].toFixed(2)).padStart(6)+String(r[7]).padStart(7)+'   '+(r[8]?'dock L'+r[8]:'a harbour')));
  say(R.SHIPK.length===3,'three ships');
  say(R.SHIPS.fire.cap===0,'a Fire Galley carries nobody, so an all-fire fleet cannot invade');
  say(R.SHIPS.galley.cap>0&&R.SHIPS.galley.dock===0,'a War Galley carries troops and needs no dock');
  say(R.SHIPS.archer.volley>0&&R.SHIPS.galley.volley===0&&R.SHIPS.fire.volley===0,
      'only the Archer Galley looses a volley');
  say(R.SHIPS.fire.atk>1&&R.SHIPS.archer.atk===1,'only the Fire Galley hits harder for attacking');
  // cost per point of power: the dear ships must be worth their price but not strictly better
  const eff=R.SHIPK.map(t=>+(R.SHIPS[t].cost/R.SHIPS[t].pow).toFixed(1));
  console.log('    gold per point of strength: '+R.SHIPK.map((t,i)=>t+' '+eff[i]).join(', '));
  say(eff[0]<eff[2],'a War Galley is the cheapest strength on the water, so screening stays worth it');
}

console.log('');
console.log('2. LOSSES EAT THE CHEAP HULLS FIRST, which is what makes a screen a screen');
{
  const G=R.getG();
  const sid=Object.keys(R.SEA)[0];
  G.navy={};
  const f={e:CROWNS[0],n:0,mv:0,load:null};
  R.setShips(f,{galley:5,archer:3,fire:2});
  G.navy[sid]=f;
  say(f.n===10,'ten hulls in, n reads '+f.n);
  R.thinShips(f,4);
  const s=R.fleetShips(f);
  say(f.n===6,'four lost leaves six');
  say(s.galley===1&&s.archer===3&&s.fire===2,'and all four came off the War Galleys ('+JSON.stringify(s)+')');
  R.thinShips(f,4);
  const s2=R.fleetShips(f);
  say(f.n===2&&!s2.galley&&!s2.archer&&s2.fire===2,'four more takes the last galley and the archers; the Fire Galleys are last ('+JSON.stringify(s2)+')');
  R.thinShips(f,99);
  say(f.n===0,'and a fleet can be wiped out entirely rather than going negative');
  sane('after being shot to pieces');
}

console.log('');
console.log('3. A VOLLEY LANDS BEFORE THE FLEETS CLOSE');
{
  Math.random=seed(55);
  R.newGame(CROWNS[0],CROWNS.slice(1),'norm');
  const G=R.getG();
  const a=CROWNS[0], d=CROWNS[1];
  R.declareWar(a,d);
  // two adjacent sea nodes
  let from=null,to=null;
  for(const n in R.SADJ){if((R.SADJ[n]||[]).length){from=n;to=R.SADJ[n][0];break;}}
  // the same fight twice: six plain galleys against six, then four galleys + two archers
  function fight(att){
    const g=R.getG();
    g.navy={};
    const A={e:a,n:0,mv:0,load:null}; R.setShips(A,att); g.navy[from]=A;
    const D={e:d,n:0,mv:0,load:null}; R.setShips(D,{galley:6}); g.navy[to]=D;
    return R.navalClash(from,to,a);
  }
  let plainWins=0, archerWins=0, volleySeen=0;
  for(let i=0;i<40;i++){const r=fight({galley:6});if(r&&r.win)plainWins++;}
  for(let i=0;i<40;i++){const r=fight({galley:4,archer:2});if(r&&r.win)archerWins++;if(r&&r.volA>0)volleySeen++;}
  console.log('    6 War Galleys        win '+plainWins+' of 40');
  console.log('    4 galleys + 2 archers win '+archerWins+' of 40, volley fired in '+volleySeen);
  say(volleySeen>=35,'the archers fire nearly every time');
  say(archerWins>plainWins,'and two archers beat two more galleys for the same hulls ('+archerWins+' vs '+plainWins+')');
  sane('after forty sea battles');
}

console.log('');
console.log('4. FIRE BURNS A CROSSING OUTRIGHT');
{
  Math.random=seed(77);
  R.newGame(CROWNS[0],CROWNS.slice(1),'norm');
  const a=CROWNS[0], d=CROWNS[1];
  R.declareWar(a,d);
  let from=null,to=null;
  for(const n in R.SADJ){if((R.SADJ[n]||[]).length){from=n;to=R.SADJ[n][0];break;}}
  function catchThem(att){
    const g=R.getG();
    g.navy={};
    const A={e:a,n:0,mv:0,load:null}; R.setShips(A,att); g.navy[from]=A;
    g.navy[to]={e:d,n:0,mv:0,tr:1,load:{spear:10,sword:6}};
    return R.navalClash(from,to,a);
  }
  const plain=catchThem({galley:3});
  const fire =catchThem({galley:2,fire:1});
  console.log('    caught by 3 War Galleys : '+plain.troopsLost+' of '+plain.troopsBefore+' lost, '+
              (plain.ashore?'survivors put ashore':'none ashore'));
  console.log('    caught by a Fire Galley : '+fire.troopsLost+' of '+fire.troopsBefore+' lost, '+
              (fire.ashore?'survivors put ashore':'none ashore'));
  say(plain.troopsLost>0&&plain.troopsLost<plain.troopsBefore,'galleys maul a crossing and some get ashore');
  say(fire.troopsLost===fire.troopsBefore,'Greek fire leaves nobody');
  say(fire.burned===true&&!plain.burned,'and the report says which it was');
}

console.log('');
console.log('5. BREAKING A HARBOUR, which is the whole reason for the build');
{
  Math.random=seed(99);
  R.newGame(CROWNS[0],CROWNS.slice(1),'norm');
  const G=R.getG();
  const me=CROWNS[0];
  // find an enemy port with a sea node beside it
  let sid=null,pid=null;
  for(const s in R.SEA){
    const provs=R.nodeLandProvs(s)||[];
    const p=provs.find(x=>R.ownerOf(x)!==me&&R.isPort(x));
    if(p){sid=s;pid=p;break;}
  }
  const owner=R.ownerOf(pid);
  if(owner!=='neutral')R.declareWar(me,owner);
  G.bld=G.bld||{};G.bld[pid]=G.bld[pid]||{};G.bld[pid].walls=2;
  const cc=R.CITYCELL[pid];
  G.armies[cc]={e:owner,u:{militia:12,spear:6},mv:0};
  const garBefore=R.cnt(G.armies[cc].u);

  G.navy={};
  const f={e:me,n:0,mv:0,load:null}; R.setShips(f,{galley:2}); G.navy[sid]=f;

  console.log('    target: '+R.provOf(pid).city+', walls L2, garrison '+garBefore);
  const weak=R.bombardPort(sid,pid,me);
  console.log('    2 War Galleys   weight '+weak.weight+' -> '+weak.killed+' killed, wall '+(weak.wallBroke?'DOWN':'holds')+', lost '+weak.lost);
  say(weak.ok,'a plain fleet may fire');
  say(!weak.wallBroke,'but two rowing boats do not bring a wall down');
  say((f.bd||0)>=1,'and the fleet has spent its shot for the day');
  const twice=R.bombardPort(sid,pid,me);
  say(!twice.ok&&/today/i.test(twice.why||''),'a second shot the same day is refused: "'+(twice.why||'')+'"');

  // now a real siege train
  const wallBefore=R.bldLv(pid,'walls');
  const g2=R.getG();
  const F={e:me,n:0,mv:0,load:null}; R.setShips(F,{galley:2,fire:3}); g2.navy[sid]=F;
  const gar2=R.cnt(g2.armies[cc].u);
  const hard=R.bombardPort(sid,pid,me);
  console.log('    2 galleys + 3 fire  weight '+hard.weight+' -> '+hard.killed+' killed, wall '+(hard.wallBroke?'DOWN':'holds')+', lost '+hard.lost);
  say(hard.killed>0&&hard.killed<gar2,'the garrison takes real losses and is never wiped out from the sea');
  say(hard.wallBroke&&R.bldLv(pid,'walls')===wallBefore-1,'three Fire Galleys bring a wall down, L'+wallBefore+' to L'+R.bldLv(pid,'walls'));
  say(hard.lost>0,'and the shore batteries take '+hard.lost+' of them with it');
  say(R.ownerOf(pid)!==me,'the city is NOT captured. Ships do not hold ground');
  sane('after the bombardment');

  // and a fleet with nothing to throw is told so
  const g3=R.getG();
  const P={e:me,n:0,mv:0,load:null}; R.setShips(P,{galley:1}); g3.navy[sid]=P; delete P.bd;
  g3.bld[pid].walls=0;
  const mine=R.bombardTargets(sid,me);
  say(mine.includes(pid),'the harbour is listed as a target');
  const home=R.bombardTargets(sid,R.ownerOf(pid));
  say(!home.includes(pid),'and nobody can bombard their own city');
}

console.log('');
console.log('6. THE DOCK IS THE GATE, and the gate is visible');
{
  Math.random=seed(31);
  R.newGame(CROWNS[0],CROWNS.slice(1),'norm');
  const me=CROWNS[0];
  const port=R.provsOf(me).find(p=>R.isPort(p));
  const inland=R.provsOf(me).find(p=>!R.isPort(p));
  console.log('    '+R.provOf(port).city+' is a port; '+(inland?R.provOf(inland).city+' is not':'this crown is all coast'));
  say(R.canBuildShip(port,'galley'),'a War Galley needs only a harbour');
  say(!R.canBuildShip(port,'archer'),'an Archer Galley is locked without a dock');
  say(!R.canBuildShip(port,'fire'),'so is a Fire Galley');
  const G=R.getG();
  G.bld=G.bld||{};G.bld[port]=G.bld[port]||{};
  G.bld[port].dock=1;
  say(R.canBuildShip(port,'archer')&&!R.canBuildShip(port,'fire'),'a dock L1 opens the archers and nothing more');
  G.bld[port].dock=2;
  say(R.canBuildShip(port,'fire'),'L2 opens the fire ships');
  if(inland){
    const G2=R.getG();
    G2.emp[me].gold=9999;R.RESK.forEach(r=>{G2.emp[me].res[r]=999;});
    say(!R.startBuild(inland,'dock',me),'and a Naval Dock cannot be built inland at all');
  }
  // the build time discount is real
  const plain=R.SHIPS.galley.hrs;
  say(R.shipHours(port,'galley')<plain,'a dock also builds ships faster: '+plain+'h becomes '+R.shipHours(port,'galley')+'h');
}

console.log('');
console.log('7. A FLEET SURVIVES THE SAVE, and so does what is in it');
{
  Math.random=seed(2026);
  R.newGame(CROWNS[0],CROWNS.slice(1),'norm');
  const G=R.getG();
  const sids=Object.keys(R.SEA).slice(0,3);
  G.navy={};
  R.setShips(G.navy[sids[0]]={e:CROWNS[0],n:0,mv:0,load:null},{galley:4,archer:2,fire:1});
  R.setShips(G.navy[sids[1]]={e:CROWNS[1],n:0,mv:0,load:null},{fire:3});
  G.navy[sids[1]].bd=1;
  G.navy[sids[2]]={e:CROWNS[2],n:0,mv:1,tr:1,load:{spear:5}};
  const before=JSON.stringify(sids.map(s=>[G.navy[s].n,R.fleetShips(G.navy[s]),G.navy[s].bd||0]));
  // makeSaveCode is ASYNC (it deflates through a stream). Awaiting it here would prove the same
  // thing with extra steps: packSave/unpackSave is the round trip, and the compression around it
  // is bytes, not meaning. regress.mjs tests the pair the same way.
  R.setG(R.unpackSave(R.packSave()));
  const G2=R.getG();
  const after=JSON.stringify(sids.map(s=>[G2.navy[s].n,R.fleetShips(G2.navy[s]),G2.navy[s].bd||0]));
  say(before===after,'every hull, by type, comes back');
  if(before!==after){console.log('      was '+before);console.log('      got '+after);}
  say((G2.navy[sids[1]].bd||0)===1,'and a fleet that has fired today is still spent after a reload');
  sane('after a save round trip');

  // a pre-v9.6 fleet has no composition at all and must read as War Galleys
  const G3=R.getG();
  const s0=sids[0];
  delete G3.navy[s0].s;
  G3.navy[s0].n=5;
  const sh=R.fleetShips(G3.navy[s0]);
  say(sh.galley===5&&Object.keys(sh).length===1,'a fleet from before v9.6 reads as 5 War Galleys, which is what it was');
  say(Math.abs(R.fleetPow(G3.navy[s0],false)-5*R.SHIPS.galley.pow)<0.001,'and fights at exactly its old strength');
}

console.log('');
console.log('8. THE AI PUTS TO SEA, over 45 days of eight crowns');
{
  Math.random=seed(4242);
  R.newGame(CROWNS[0],CROWNS.slice(1),'norm');
  R.getG().emp[CROWNS[0]].ai=true;
  // Hold the win line out of reach so the world runs the full thirty days. Left alone somebody
  // wins around day 20, and a naval build-up measured against a race it is not running in tells
  // you about the race.
  R.getG().need=200;
  let maxHulls=0, sawArcher=0, sawFire=0, docks=0, bombards=0;
  const seen=[];
  // 45 days, not 30: a dock is a building, the ship after it is a build, and the whole chain
  // (earn, build dock, save, lay down, launch) does not finish inside a month.
  for(let d=1;d<=45;d++){
    R.advanceClock(24);
    const g=R.getG();
    if(g.over)break;
    let hulls=0,ar=0,fi=0;
    for(const sid in (g.navy||{})){
      const f=g.navy[sid];if(f.tr)continue;
      hulls+=f.n;const s=R.fleetShips(f);ar+=s.archer||0;fi+=s.fire||0;
    }
    maxHulls=Math.max(maxHulls,hulls);
    sawArcher=Math.max(sawArcher,ar);sawFire=Math.max(sawFire,fi);
    docks=0;for(const p in (g.bld||{}))if(g.bld[p].dock)docks++;
    if([10,20,30,40,45].includes(d))seen.push([d,hulls,ar,fi,docks]);
    const bad=fleetsSane();
    if(bad.length){console.log('  FAIL  fleet broke on day '+d+': '+bad[0]);ok.push(false);break;}
  }
  console.log('    day  hulls  archers  fire  docks');
  seen.forEach(r=>console.log('    '+String(r[0]).padStart(3)+String(r[1]).padStart(7)+
    String(r[2]).padStart(9)+String(r[3]).padStart(6)+String(r[4]).padStart(7)));
  say(maxHulls>=6,'the AI crowns put '+maxHulls+' hulls on the water between them');
  say(docks>0,docks+' Naval Docks were built by somebody other than you');
  say(sawArcher+sawFire>0,'and the better ships get built: '+sawArcher+' archers, '+sawFire+' fire, at peak');
  sane('after 45 days of AI naval warfare');
}

console.log('');
const bad=ok.filter(x=>!x).length;
console.log(bad?('  '+bad+' FAILED'):'  ALL GREEN');
process.exit(bad?1:0);

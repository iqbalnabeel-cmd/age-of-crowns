// THE ECONOMY, CHECKED IN A BROWSER ON A PHONE.
//
// The rules harness (v94-econ.mjs) proves the numbers work. This proves a player can SEE them,
// which is the half that was always going to be harder: seven figures on a 390px screen, a cost
// that has to say when you cannot pay it, and a city that has to say what it makes.
const {chromium}=require('playwright');

(async()=>{
  const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
  const p=await b.newPage({viewport:{width:390,height:844},isMobile:true,hasTouch:true});
  const errs=[];
  p.on('pageerror',e=>errs.push(String(e)));
  p.on('console',m=>{if(m.type()==='error')errs.push(m.text());});
  await p.goto('file:///home/claude/age-of-crowns/aoc-v6.html');
  await p.waitForTimeout(600);

  // ---- the start screen, before a game exists -------------------------------------------------
  const start=await p.evaluate(()=>({
    rivalRow:!!document.getElementById('rivalrow'),
    note:(document.getElementById('rivalNote')||{}).textContent||'',
    btnOff:document.getElementById('startBtn').disabled,
    msg:(document.getElementById('startMsg')||{}).textContent||''
  }));

  await p.evaluate(()=>{let s=20261121;Math.random=function(){s=(s*1664525+1013904223)>>>0;return s/4294967296;};
    selEmpire='abb';selDiff='norm';refreshStart();});
  const picked=await p.evaluate(()=>document.getElementById('startBtn').disabled);
  await p.evaluate(()=>document.getElementById('startBtn').onclick());
  await p.waitForTimeout(1500);

  const r=await p.evaluate(async()=>{
    const o={};
    G.rate=0; closeDrawer(true);
    o.crowns=Object.keys(G.emp).length;
    o.alive=Object.keys(G.emp).filter(k=>G.emp[k].alive).length;

    // ---- the strip -----------------------------------------------------------------------------
    const bar=document.getElementById('resbar');
    o.stripItems=bar?bar.querySelectorAll('.rs').length:0;
    o.stripIcons=bar?bar.querySelectorAll('.rs svg').length:0;
    o.stripFits=bar?bar.scrollWidth<=bar.clientWidth+1:false;
    o.stripH=bar?Math.round(bar.getBoundingClientRect().height):0;
    o.stripText=bar?bar.innerText.replace(/\n+/g,' ').trim():'';
    // every number on it must be readable
    o.tiny=bar?[...bar.querySelectorAll('b')].filter(x=>parseFloat(getComputedStyle(x).fontSize)<11).length:99;

    // ---- the stockpiles are real ----------------------------------------------------------------
    const e=G.emp[G.player];
    o.hasAll=RESK.every(k=>typeof e.res[k]==='number');
    o.men=e.men;
    advanceClock(24);
    const after=RESK.map(k=>e.res[k]);
    o.grew=after.every((v,i)=>v>0);
    o.grainUp=e.res.grain>RES_PER_CITY.grain;        // a day of a grain city, minus what the army ate

    // ---- costs on the rows, and red when short ---------------------------------------------------
    const pid=provsOf(G.player).find(x=>isHomeCity(x,G.player));
    cityClick(pid); setCityTab('bld');
    await new Promise(x=>setTimeout(x,350));
    const d=document.getElementById('drawer');
    o.buildCosts=d.querySelectorAll('.brow2 .rcost').length;
    // make one material impossible and check the row says so
    e.res.stone=0;
    setCityTab('bld');
    await new Promise(x=>setTimeout(x,250));
    o.shortMarked=d.querySelectorAll('.rcost.short').length;
    e.res.stone=200;

    setCityTab('rec');
    await new Promise(x=>setTimeout(x,250));
    o.recruitCosts=d.querySelectorAll('.brow2 .rcost').length;
    o.recruitRows=d.querySelectorAll('.brow2').length;

    // ---- the city says what it makes --------------------------------------------------------------
    setCityTab('ov');
    await new Promise(x=>setTimeout(x,250));
    o.cityProd=!!d.querySelector('.cityprod');
    o.cityProdText=(d.querySelector('.cityprod')||{}).textContent||'';
    o.cityRes=CITYRES[pid];
    closeDrawer(true);

    // ---- the gate actually refuses ------------------------------------------------------------------
    e.res.iron=0;
    const bad=doOrder({type:'recruit',pid,t:'spear'});
    o.refused=!bad.ok;
    o.refusalSays=bad.why||'';
    e.res.iron=50;
    const good=doOrder({type:'recruit',pid,t:'spear'});
    o.allowed=!!good.ok;

    // ---- every one of the 80 cities makes something -------------------------------------------------
    o.unassigned=Object.keys(MAPD5.provs).filter(x=>!CITYRES[x]).length;
    return o;
  });

  const ok=[];const say=(c,m)=>{ok.push(c);console.log((c?'  PASS  ':'  FAIL  ')+m);};

  console.log('THE START SCREEN');
  say(!start.rivalRow,'the rival picker is gone');
  say(/seven other crowns/i.test(start.note),'it says all seven others play: "'+start.note+'"');
  say(start.btnOff&&!picked,'Begin is off until you choose an empire, and on after');
  console.log('');
  console.log('EVERY CROWN PLAYS');
  say(r.crowns===8&&r.alive===8,'all eight crowns are in the game (got '+r.crowns+')');
  console.log('');
  console.log('THE RESOURCE STRIP');
  console.log('    '+r.stripText);
  say(r.stripItems===6,'six items: men and the five materials (got '+r.stripItems+')');
  say(r.stripIcons===6,'each with a drawn icon, no colour emoji');
  say(r.stripFits,'and it FITS on a 390px phone without scrolling');
  say(r.stripH<=58,'in '+r.stripH+'px of height');
  say(r.tiny===0,'nothing on it is under 11px');
  console.log('');
  console.log('THE STOCKPILES');
  say(r.hasAll,'the player holds all five materials');
  say(r.grew,'a day of the clock adds to every one of them');
  say(r.grainUp,'and grain goes UP after a day, so the army is not outeating the farms');
  console.log('');
  console.log('COSTS ON THE ROWS');
  say(r.buildCosts>=10,r.buildCosts+' material costs shown across the build list');
  say(r.recruitCosts>=r.recruitRows,r.recruitCosts+' across '+r.recruitRows+' recruit rows');
  say(r.shortMarked>0,r.shortMarked+' of them turn red when the material runs out');
  console.log('');
  console.log('THE CITY SAYS WHAT IT MAKES');
  say(r.cityProd,'the Overview leads with it: "'+r.cityProdText.trim()+'"');
  say(new RegExp(r.cityRes,'i').test(r.cityProdText),'and it names the right one ('+r.cityRes+')');
  console.log('');
  console.log('THE GATE ACTUALLY REFUSES');
  say(r.refused,'no iron, no spearmen: "'+r.refusalSays+'"');
  say(/iron/i.test(r.refusalSays),'and it says which material is short');
  say(r.allowed,'iron back, and the same order goes through');
  console.log('');
  say(r.unassigned===0,'all 80 cities make something (unassigned: '+r.unassigned+')');
  say(errs.length===0,'no page errors'+(errs.length?': '+errs.slice(0,2).join(' | '):''));

  await b.close();
  const bad=ok.filter(x=>!x).length;
  console.log('');
  console.log(bad?('  '+bad+' FAILED'):'  ALL GREEN');
  process.exit(bad?1:0);
})();

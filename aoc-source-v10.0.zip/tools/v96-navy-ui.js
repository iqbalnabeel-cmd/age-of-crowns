// THE NAVY, IN A BROWSER, ON A PHONE.
//
// v96-navy.mjs proved the rules. This asks whether a thumb can reach any of it:
//   1. Does the Sea tab show three ships, with the locked ones VISIBLE rather than missing?
//   2. Does building a Naval Dock actually unlock the row in front of you?
//   3. Does the fleet card say what the fleet is made of, instead of "7 galleys"?
//   4. Is there a Bombard button, does it fire, and does the screen say what it did?
const {chromium}=require('playwright');

(async()=>{
  const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
  const p=await b.newPage({viewport:{width:390,height:844},isMobile:true,hasTouch:true});
  const errs=[];
  p.on('pageerror',e=>errs.push(String(e)));
  p.on('console',m=>{if(m.type()==='error')errs.push('console: '+m.text());});
  await p.goto('file:///home/claude/age-of-crowns/aoc-v6.html');
  await p.waitForTimeout(400);
  await p.evaluate(()=>{let s=20261122;Math.random=function(){s=(s*1664525+1013904223)>>>0;return s/4294967296;};
    selEmpire='eng';selDiff='norm';refreshStart();});          // England, so there is certainly a harbour
  await p.evaluate(()=>document.getElementById('startBtn').onclick());
  await p.waitForTimeout(1200);
  await p.evaluate(()=>{G.rate=0;closeDrawer(true);});

  const ok=[];
  const say=(c,m)=>{ok.push(c);console.log((c?'  PASS  ':'  FAIL  ')+m);};

  console.log('THE SEA TAB');
  const a=await p.evaluate(()=>{
    const out={};
    const port=provsOf(G.player).find(x=>isPort(x));
    out.port=provOf(port).city;
    G.emp[G.player].gold=4000; RESK.forEach(r=>{G.emp[G.player].res[r]=900;});
    cityClick(port);
    setCityTab('rec');
    // the recruit tab has a domain strip; find and press the sea one
    const dom=[...document.querySelectorAll('#panel button')].find(x=>/sea|fleet|navy/i.test(x.title||x.textContent||''));
    if(dom)dom.click();
    else if(typeof setRecDom==='function')setRecDom('sea');
    return out;
  });
  await p.waitForTimeout(250);
  let r=await p.evaluate(()=>{
    // make sure we are on the sea domain whatever the strip is called
    if(typeof RECDOM!=='undefined'&&typeof setRecDom==='function')setRecDom('sea');
    const html=()=>document.getElementById('panel').innerHTML;
    const out={};
    out.hasSea=/War Galley/.test(html());
    out.rows=[...document.querySelectorAll('#panel .buildrow')].map(d=>({
      txt:(d.textContent||'').replace(/\s+/g,' ').trim().slice(0,110),
      locked:d.classList.contains('lockrow'),
      btn:((d.querySelector('button')||{}).textContent||'').trim(),
      dis:!!(d.querySelector('button')||{}).disabled}));
    return out;
  });
  console.log('  port: '+a.port);
  r.rows.forEach(x=>console.log('    '+(x.locked?'[locked] ':'[open]   ')+x.btn.padEnd(7)+' '+x.txt));
  say(r.hasSea,'the Sea tab is showing');
  say(r.rows.length===3,'three ship rows, not one ('+r.rows.length+')');
  say(r.rows.filter(x=>!x.locked).length===1,'exactly one is open at the start: the War Galley');
  say(r.rows.filter(x=>x.locked).length===2,'and the other two SHOW, locked, rather than being absent');
  say(r.rows.filter(x=>x.locked).every(x=>/Naval Dock L[12]/.test(x.txt)),
      'each locked row names the dock level it wants');
  say(r.rows.filter(x=>x.locked).every(x=>x.dis),'and its button cannot be pressed');

  console.log('');
  console.log('THE DOCK UNLOCKS IT, IN FRONT OF YOU');
  const d1=await p.evaluate(()=>{
    const out={};
    const port=provsOf(G.player).find(x=>isPort(x));
    // England is all coast, so take any inland city we own anywhere. If somehow there is none,
    // give ourselves one: the point is the PORT GATE, not which crown owns what.
    let inland=provsOf(G.player).find(x=>!isPort(x));
    if(!inland){
      // Ownership lives on the CELLS; ownerOf(pid) just reads the city cell. There is no
      // province-owner map to write to, and the first version of this test invented one.
      inland=Object.keys(MAPD5.provs).find(x=>!isPort(x));
      (provOf(inland).cells||[]).forEach(c=>{G.cellOwner[c]=G.player;});
      G.annex=G.annex||{}; G.annex[inland]=G.player;
    }
    out.inland=provOf(inland).city;
    out.inlandRefused=!startBuild(inland,'dock',G.player);
    G.bld[port]=G.bld[port]||{}; G.bld[port].dock=1;
    cityClick(port); setCityTab('rec');
    if(typeof setRecDom==='function')setRecDom('sea');
    out.afterL1=[...document.querySelectorAll('#panel .buildrow')].map(x=>x.classList.contains('lockrow'));
    G.bld[port].dock=2;
    setRecDom('sea');
    out.afterL2=[...document.querySelectorAll('#panel .buildrow')].map(x=>x.classList.contains('lockrow'));
    out.fasterNote=/laid down a quarter faster/.test(document.getElementById('panel').innerHTML);
    // and the hours on the row actually dropped
    out.hrsWithDock=shipHours(port,'galley');
    out.hrsPlain=SHIPS.galley.hrs;
    return out;
  });
  say(d1.inlandRefused===true,'a Naval Dock is refused inland ('+d1.inland+')');
  say(JSON.stringify(d1.afterL1)==='[false,false,true]','dock L1 opens the Archer Galley and no more');
  say(JSON.stringify(d1.afterL2)==='[false,false,false]','dock L2 opens all three');
  say(d1.fasterNote,'and the screen says ships are laid down faster');
  say(d1.hrsWithDock<d1.hrsPlain,'which is true: '+d1.hrsPlain+'h becomes '+d1.hrsWithDock+'h');

  console.log('');
  console.log('THE FLEET CARD SAYS WHAT IS IN THE FLEET');
  const f1=await p.evaluate(()=>{
    const out={};
    const port=provsOf(G.player).find(x=>isPort(x));
    const sid=(PORTS[port]||[])[0];
    out.sid=sid;
    G.navy={};
    const f={e:G.player,n:0,mv:0,load:null};
    setShips(f,{galley:4,archer:2,fire:1});
    G.navy[sid]=f;
    openSeaPanel(sid);
    const h=document.getElementById('panel').innerHTML;
    out.title=(document.getElementById('dTitle')||{}).textContent||'';
    out.namesAll=/War Galley/.test(h)&&/Archer Galley/.test(h)&&/Fire Galley/.test(h);
    out.counts=[...document.querySelectorAll('#panel .utable tr')].map(x=>x.textContent.replace(/\s+/g,' ').trim());
    out.strength=/Strength/.test(h);
    out.volleyNote=/volley/i.test(h);
    out.siegeNote=/siege weight/i.test(h);
    out.holdNote=(h.match(/Hold: \d+ \/ \d+ troops[^<]*/)||[''])[0];
    out.capacity=fleetCap(f);
    // an ENEMY fleet must still report only its size
    G.navy[sid]={e:'fra',n:0,mv:0,load:null};
    setShips(G.navy[sid],{galley:2,fire:3});
    openSeaPanel(sid);
    out.enemyHtml=document.getElementById('panel').innerHTML;
    out.enemyHidesTypes=!/Fire Galley/.test(out.enemyHtml);
    out.enemySaysSize=/5 ships/.test(out.enemyHtml);
    return out;
  });
  console.log('    ' + f1.counts.join('   |   '));
  console.log('    ' + f1.holdNote);
  say(f1.namesAll,'your own fleet names all three kinds');
  say(f1.counts.length===3,'one row per kind ('+f1.counts.length+')');
  say(f1.strength&&f1.volleyNote&&f1.siegeNote,'it gives strength, the volley and the siege weight');
  say(f1.capacity===4*3+2*2,'capacity counts only ships that carry: '+f1.capacity+' for 4 galleys and 2 archers');
  say(/Fire Galleys carry nobody/.test(f1.holdNote),'and it says why the Fire Galley adds nothing to the hold');
  say(f1.enemyHidesTypes&&f1.enemySaysSize,"an ENEMY fleet still reports only its size. The fog rule outranks the detail");

  console.log('');
  console.log('BOMBARDING A HARBOUR');
  const bm=await p.evaluate(()=>{
    const out={};
    // find a sea node of ours next to somebody else's port
    let sid=null,pid=null;
    for(const s in SEA){
      const ps=(nodeLandProvs(s)||[]).filter(x=>ownerOf(x)!==G.player&&isPort(x));
      if(ps.length){sid=s;pid=ps[0];break;}
    }
    out.city=provOf(pid).city; out.owner=empName(ownerOf(pid));
    if(ownerOf(pid)!=='neutral')declareWar(G.player,ownerOf(pid));
    G.bld[pid]=G.bld[pid]||{}; G.bld[pid].walls=2;
    const cc=CITYCELL[pid];
    G.armies[cc]={e:ownerOf(pid),u:{militia:14,spear:6},mv:0};
    out.garBefore=cnt(G.armies[cc].u);
    out.wallBefore=bldLv(pid,'walls');

    G.navy={};
    const f={e:G.player,n:0,mv:0,load:null};
    setShips(f,{galley:2,fire:3});
    G.navy[sid]=f;
    openSeaPanel(sid);
    const btns=[...document.querySelectorAll('#panel button')].filter(x=>/Bombard/i.test(x.textContent));
    out.btnCount=btns.length;
    out.btnText=btns.length?btns[0].textContent.replace(/\s+/g,' ').trim():'';
    out.explains=/still have to land/i.test(document.getElementById('panel').innerHTML);
    if(btns.length)btns[0].click();
    out.garAfter=cnt((G.armies[cc]||{u:{}}).u);
    out.wallAfter=bldLv(pid,'walls');
    out.stillTheirs=ownerOf(pid)!==G.player;
    out.hullsAfter=navyAt(sid)?navyAt(sid).n:0;
    const last=(G.log||[])[0];        // the Chronicle is newest first
    out.logged=last?last.msg.replace(/<[^>]+>/g,''):'';
    // and the button is now spent
    openSeaPanel(sid);
    const again=[...document.querySelectorAll('#panel button')].filter(x=>/Bombard/i.test(x.textContent));
    out.spent=again.length>0&&again.every(x=>x.disabled);
    out.saysSpent=/already fired today/i.test(document.getElementById('panel').innerHTML);
    return out;
  });
  console.log('    target '+bm.city+' ('+bm.owner+'), walls L'+bm.wallBefore+', garrison '+bm.garBefore);
  console.log('    button: '+bm.btnText);
  console.log('    after:  garrison '+bm.garAfter+', walls L'+bm.wallAfter+', your hulls '+bm.hullsAfter);
  console.log('    log:    '+bm.logged);
  say(bm.btnCount>=1,'there is a Bombard button on the fleet card');
  say(/walls L2/.test(bm.btnText),'and it says what it is shooting at');
  say(bm.explains,'the card explains that guns take nothing, you still have to land');
  say(bm.garAfter<bm.garBefore,'firing kills part of the garrison ('+bm.garBefore+' to '+bm.garAfter+')');
  say(bm.wallAfter===bm.wallBefore-1,'three Fire Galleys bring a wall down');
  say(bm.hullsAfter<5,'the shore fires back and you lose hulls ('+bm.hullsAfter+' of 5 left)');
  say(bm.stillTheirs,'the city is NOT captured');
  say(/bombards/i.test(bm.logged)&&/wall/i.test(bm.logged),'the Chronicle says what happened: "'+bm.logged+'"');
  say(bm.spent&&bm.saysSpent,'and the button is spent for the day, with a reason');

  await p.screenshot({path:'/home/claude/age-of-crowns/docs/shots/v96-navy-phone.png'});
  say(errs.length===0,'no page errors'+(errs.length?': '+errs.slice(0,2).join(' | '):''));
  await p.close();
  await b.close();
  const bad=ok.filter(x=>!x).length;
  console.log('');
  console.log(bad?('  '+bad+' FAILED'):'  ALL GREEN');
  process.exit(bad?1:0);
})();

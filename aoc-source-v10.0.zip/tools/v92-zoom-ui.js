// Does the new applyVB actually cut the rebuilds, and does the map still end up correct?
//
// Two things could go wrong with deferring the rebuild. It could defer a rebuild that MATTERS,
// so the map ends a pinch showing chips when it should show totals. Or the trailing timer could
// never fire, leaving the content permanently stale. This simulates a real pinch, frame by frame,
// and checks both.
const {chromium}=require('playwright');

(async()=>{
  const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
  const p=await b.newPage({viewport:{width:390,height:844},isMobile:true,hasTouch:true});
  const errs=[];
  p.on('pageerror',e=>errs.push(String(e)));
  await p.goto('file:///home/claude/age-of-crowns/aoc-v6.html');
  await p.waitForTimeout(400);
  await p.evaluate(()=>{let s=20261120;Math.random=function(){s=(s*1664525+1013904223)>>>0;return s/4294967296;};
    selEmpire='abb';selRivals.clear();['byz','fra','mon'].forEach(k=>selRivals.add(k));selDiff='norm';refreshStart();});
  await p.evaluate(()=>document.getElementById('startBtn').onclick());
  await p.waitForTimeout(1200);

  const r=await p.evaluate(async()=>{
    G.rate=0; closeDrawer(true);
    const out={};
    // count every rebuild by wrapping updateMap
    const real=window.updateMap; let calls=0;
    window.updateMap=function(){calls++;return real.apply(this,arguments);};

    // a pinch from the whole world down to one front, in the ~60 steps a real gesture produces
    fitView(); calls=0;
    const steps=60, from=1750, to=200;
    for(let i=1;i<=steps;i++){
      const w=from*Math.pow(to/from,i/steps);
      zoomBy(w/VB.w);                       // exactly what a pinch frame calls
    }
    out.pinchIn=calls;
    await new Promise(r=>setTimeout(r,250));   // let the trailing rebuild land
    out.pinchInSettled=calls;
    out.widthAfter=Math.round(VB.w);

    // and back out again
    calls=0;
    for(let i=1;i<=steps;i++){
      const w=200*Math.pow(1750/200,i/steps);
      zoomBy(w/VB.w);
    }
    out.pinchOut=calls;
    await new Promise(r=>setTimeout(r,250));
    out.pinchOutSettled=calls;

    // --- correctness: the content must match the FINAL width, not some width along the way ---
    // Put a mixed stack on the map, sit just inside the chip threshold, then zoom just outside it
    // and check the map really did swap chips for one total.
    const cells=Object.keys(MAPD5.cells);
    for(const c in G.armies) if(G.armies[c].e===G.player) delete G.armies[c];
    placeArmy(cells[40],G.player,{spear:7,sword:3,longbow:2},0,0);
    const a=G.armies[cells[40]], cc=MAPD5.cells[cells[40]];
    const look=w=>{VB={x:cc.x-w/2,y:cc.y-(w/2.2)/2,w,h:w/2.2};applyVB();};

    // scope to THIS stack. #gArmy holds every army on the map, so counting all its rects counts
    // seventy neutral badges as well and proves nothing.
    const mine=()=>document.querySelector('#gArmy g[data-a="'+cells[40]+'"]');
    look(CHIPTH*0.8); await new Promise(r=>setTimeout(r,200));
    out.chipsWhenClose=mine()?mine().querySelectorAll('rect').length:-1;

    // one nudge at a time, the way a slow pinch crosses the line, each inside the 18% leash
    let w=CHIPTH*0.8;
    while(w<CHIPTH*1.15){ w*=1.03; look(w); }
    out.widthNow=Math.round(VB.w);
    out.rectsImmediatelyAfterCrossing=mine()?mine().querySelectorAll('rect').length:-1;
    await new Promise(r=>setTimeout(r,200));
    out.rectsSettled=mine()?mine().querySelectorAll('rect').length:-1;
    const t=mine()&&mine().querySelector('text');
    out.totalShown=t?t.textContent:null;

    window.updateMap=real;
    return out;
  });

  const ok=[];
  const say=(cond,msg)=>{ok.push(cond);console.log((cond?'  PASS  ':'  FAIL  ')+msg);};

  console.log('REBUILDS DURING A 60-FRAME PINCH (was 60, one per frame)');
  console.log('');
  console.log('  pinching in      '+r.pinchIn+' during, '+r.pinchInSettled+' after it settled');
  console.log('  pinching out     '+r.pinchOut+' during, '+r.pinchOutSettled+' after it settled');
  console.log('');
  say(r.pinchIn<=16, 'a pinch in rebuilds '+r.pinchIn+' times, not 60');
  say(r.pinchOut<=16, 'a pinch out rebuilds '+r.pinchOut+' times, not 60');
  say(r.pinchInSettled>r.pinchIn||r.pinchIn>0, 'the gesture ends with the map rebuilt at its final width');
  console.log('');
  console.log('CORRECTNESS ACROSS THE CHIP THRESHOLD (CHIPTH, final width '+r.widthNow+')');
  say(r.chipsWhenClose>=3, 'zoomed in, the stack draws a chip per unit type ('+r.chipsWhenClose+' boxes)');
  say(r.rectsSettled===1, 'zoomed out past the line, it draws ONE badge (got '+r.rectsSettled+')');
  say(r.totalShown==='12', 'and that badge reads the stack total, 12 (got '+r.totalShown+')');
  say(errs.length===0, 'no page errors'+(errs.length?': '+errs[0]:''));

  await b.close();
  const bad=ok.filter(x=>!x).length;
  console.log('');
  console.log(bad?('  '+bad+' FAILED'):'  all green');
  process.exit(bad?1:0);
})();

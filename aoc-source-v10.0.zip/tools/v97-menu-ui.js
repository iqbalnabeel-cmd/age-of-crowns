// THE BOTTOM BAR, THE ARMIES LIST, AND THE PINS.
//
// Three things, and all three are about the same complaint: on a phone you cannot find anything.
// The rail is twelve unlabelled icons eating 15% of the width, there has never been a way to see
// your own forces on a 367 cell map, and a city's buildings are invisible until you open it.
//
// Every assertion runs at BOTH widths, because the rule from v9.3 holds: phones get the new
// chrome, a laptop keeps the rail beside a wide map. The harness asserts opposite answers.
const {chromium}=require('playwright');

(async()=>{
  const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
  const ok=[];
  const say=(c,m)=>{ok.push(c);console.log((c?'  PASS  ':'  FAIL  ')+m);};

  async function boot(w,h,mob){
    const p=await b.newPage({viewport:{width:w,height:h},isMobile:mob,hasTouch:mob});
    const errs=[];
    p.on('pageerror',e=>errs.push(String(e)));
    p.on('console',m=>{if(m.type()==='error')errs.push('console: '+m.text());});
    await p.goto('file:///home/claude/age-of-crowns/aoc-v6.html');
    await p.waitForTimeout(400);
    await p.evaluate(()=>{let s=20261123;Math.random=function(){s=(s*1664525+1013904223)>>>0;return s/4294967296;};
      selEmpire='abb';selDiff='norm';refreshStart();});
    await p.evaluate(()=>document.getElementById('startBtn').onclick());
    await p.waitForTimeout(1200);
    await p.evaluate(()=>{G.rate=0;closeDrawer(true);});
    return {p,errs};
  }

  // =============================================================================================
  console.log('ON A PHONE, 390x844');
  const {p,errs}=await boot(390,844,true);

  const r1=await p.evaluate(()=>{
    const out={};
    const bar=document.getElementById('bbar'), rail=document.getElementById('rail');
    out.barShown=getComputedStyle(bar).display!=='none';
    out.railHidden=getComputedStyle(rail).display==='none';
    const bb=bar.getBoundingClientRect();
    out.barH=Math.round(bb.height); out.barW=Math.round(bb.width);
    out.atBottom=Math.abs(bb.bottom-window.innerHeight)<2;
    out.tabs=[...bar.querySelectorAll('.bb')].map(x=>({
      label:(x.querySelector('.bbl')||{}).textContent||'',
      h:Math.round(x.getBoundingClientRect().height),
      w:Math.round(x.getBoundingClientRect().width)}));
    // the map must not be hiding under the bar
    const mw=document.getElementById('mapwrap').getBoundingClientRect();
    out.mapClear=Math.round(window.innerHeight-mw.bottom)>=0;
    out.mapPad=getComputedStyle(document.getElementById('mapwrap')).paddingBottom;
    // the rail's width used to come out of the map
    out.railCostBefore=58;
    return out;
  });
  console.log('  bar '+r1.barW+'x'+r1.barH+' at the bottom, '+r1.tabs.length+' tabs of '+
              (r1.tabs[0]||{}).w+'px');
  say(r1.barShown,'the bottom bar is there');
  say(r1.railHidden,'and the twelve-icon rail is gone, giving the map back '+r1.railCostBefore+'px of width');
  say(r1.atBottom,'it sits on the bottom edge, where the thumb is');
  say(r1.tabs.length===5,'five tabs ('+r1.tabs.length+')');
  say(JSON.stringify(r1.tabs.map(x=>x.label))==='["Cities","Armies","Chronicle","Standings","More"]',
      'Nabeel\'s five, in his order: '+r1.tabs.map(x=>x.label).join(', '));
  say(r1.tabs.every(x=>x.h>=40),'every tab clears the 40px tap floor ('+Math.min(...r1.tabs.map(x=>x.h))+'px)');
  say(r1.tabs.every(x=>x.w>=60),'and is wide enough to hit ('+Math.min(...r1.tabs.map(x=>x.w))+'px)');
  say(r1.barH<=70,'the bar costs '+r1.barH+'px of height, against the rail\'s 58px of width');
  say(/\d/.test(r1.mapPad)&&parseFloat(r1.mapPad)>0,'the map is padded clear of it ('+r1.mapPad+')');

  console.log('');
  console.log('THE ARMIES LIST, which has never existed');
  const r2=await p.evaluate(()=>{
    const out={};
    // one idle army, one marching column, one garrison, so all three states are on the screen
    const mine=provsOf(G.player);
    const cells=Object.keys(MAPD5.cells).filter(c=>!MAPD5.cells[c].city&&cellOwnerOf(c)===G.player);
    for(const c in G.armies)if(G.armies[c].e===G.player&&!MAPD5.cells[c].city)delete G.armies[c];
    placeArmy(cells[0],G.player,{spear:5,sword:2},0,0);
    renderAll();                       // the badge rides on a repaint, as it does in play
    out.idleBefore=idleArmyCount();
    document.getElementById('bbArmies').click();
    const md=document.querySelector('.modal,#modal,#modalBody')||document.body;
    const h=md.innerHTML;
    out.rows=[...document.querySelectorAll('.buildrow')].map(x=>x.textContent.replace(/\s+/g,' ').trim().slice(0,90));
    out.hasGo=[...document.querySelectorAll('.buildrow button')].filter(x=>/^Go$/.test(x.textContent)).length;
    out.saysIdle=/standing idle/.test(h);
    out.dots=document.querySelectorAll('.adot').length;
    out.badgeShown=getComputedStyle(document.getElementById('bbArmiesN')).display!=='none';
    out.badgeText=document.getElementById('bbArmiesN').textContent;
    return out;
  });
  r2.rows.slice(0,5).forEach(x=>console.log('    '+x));
  say(r2.rows.length>0,r2.rows.length+' forces listed');
  say(r2.hasGo===r2.rows.length,'every row has a Go button');
  say(r2.saysIdle,'the header says how many are standing idle, which is the whole point');
  say(r2.dots===r2.rows.length,'and every row carries a state dot');
  const wantBadge=r2.idleBefore>9?'9+':String(r2.idleBefore);
  say(r2.badgeShown&&r2.badgeText===wantBadge,
      'the Armies tab wears a badge with the idle count: '+r2.badgeText+' (expected '+wantBadge+')');

  console.log('');
  console.log('GO TAKES YOU THERE');
  const r3=await p.evaluate(()=>{
    const out={};
    const rows=armyRows();
    out.target=rows[0]?rows[0].name:null;
    const wBefore=VB.w;
    const btn=[...document.querySelectorAll('.buildrow button')].find(x=>/^Go$/.test(x.textContent));
    if(btn)btn.click();
    out.zoomed=VB.w<=wBefore;
    out.vbw=Math.round(VB.w);
    out.modalClosed=!document.querySelector('.modal.open,#modal.open')||
                    !document.body.innerHTML.includes('Your armies');
    out.selected=!!(G.selArmy||G.selCol);
    // and the force really is in view
    const cell=G.selArmy||((G.col[G.selCol]||{}).to);
    const c=cell&&cellOf(cell);
    out.inView=c?(c.x>=VB.x&&c.x<=VB.x+VB.w&&c.y>=VB.y&&c.y<=VB.y+VB.h):false;
    return out;
  });
  say(r3.modalClosed,'the list closes');
  say(r3.selected,'the force is selected and its card is open');
  say(r3.zoomed,'the map zooms in to it (viewBox now '+r3.vbw+' wide)');
  say(r3.inView,'and it is genuinely inside the view, not just near it');

  console.log('');
  console.log('MORE HOLDS EVERYTHING ELSE THE RAIL HAD');
  const r4=await p.evaluate(()=>{
    closeDrawer(true);
    document.getElementById('bbMore').click();
    const h=document.body.innerHTML;
    return {
      market:/Marketplace/.test(h), dip:/Diplomacy/.test(h), tech:/Research/.test(h),
      units:/Units/.test(h), save:/Save code/.test(h), help:/How to play/.test(h),
      anim:/Marching animations/.test(h), ground:/Colour the map by the ground/.test(h),
      rows:document.querySelectorAll('.buildrow').length};
  });
  say(r4.market,'the Marketplace is in it, and first');
  say(r4.dip&&r4.tech&&r4.units&&r4.save&&r4.help,'so are Diplomacy, Research, Units, Save and Help');
  say(r4.anim&&r4.ground,'and the two display toggles');
  say(r4.rows>=8,r4.rows+' rows, so nothing the rail had was lost');

  const r5=await p.evaluate(()=>{
    const out={};
    closeModal();
    document.getElementById('bbMore').click();
    const btn=[...document.querySelectorAll('.buildrow button')].find(x=>/Open/.test(x.textContent));
    if(btn)btn.click();
    out.opened=/MARKETPLACE/i.test((document.getElementById('dTitle')||{}).textContent||'');
    return out;
  });
  await p.waitForTimeout(350);
  say(r5.opened,'and pressing Open on the Marketplace row actually opens it');

  console.log('');
  console.log('A SHEET AND A BAR BOTH WANT THE BOTTOM OF THE SCREEN');
  await p.evaluate(()=>{closeDrawer(true);});
  await p.waitForTimeout(350);
  // An ARMY card, not a city: every city of yours is a home city at the start and those all open
  // full window. The army card is the panel that is still a sheet, by the v9.3 rule, because for
  // an army you need the map at the same time.
  // A FLEET card. Not an army: on a phone an army does not use the drawer at all, it uses the
  // floating action bar, which is why the first attempt here measured a closed drawer 500px
  // below the screen and read as a layout failure. The fleet card is a real sheet.
  await p.evaluate(()=>{
    const port=provsOf(G.player).find(x=>isPort(x))||Object.keys(MAPD5.provs).find(x=>isPort(x));
    const sid=(PORTS[port]||[])[0];
    G.navy={}; addNavy(sid,G.player,3,false,'galley');
    openSeaPanel(sid);
  });
  await p.waitForTimeout(400);
  const rs=await p.evaluate(()=>{
    const d=document.getElementById('drawer').getBoundingClientRect();
    const bar=document.getElementById('bbar').getBoundingClientRect();
    return {dBottom:Math.round(d.bottom),barTop:Math.round(bar.top),
            full:document.getElementById('drawer').classList.contains('fullcity'),
            barShown:getComputedStyle(document.getElementById('bbar')).display!=='none'};
  });
  say(!rs.full||!rs.barShown,'either the sheet is a sheet or the bar is hidden, never both fighting');
  if(!rs.full)say(rs.dBottom<=rs.barTop+1,'an ordinary sheet stops above the bar ('+rs.dBottom+' vs '+rs.barTop+')');
  const rf=await p.evaluate(()=>{
    closeDrawer(true);
    cityClick(provsOf(G.player)[0]);                           // a home city: the full window
    return {full:document.getElementById('drawer').classList.contains('fullcity'),
            barShown:getComputedStyle(document.getElementById('bbar')).display!=='none'};
  });
  say(rf.full&&!rf.barShown,'and the full-window city screen hides the bar outright, so it really is the whole screen');
  await p.evaluate(()=>closeDrawer(true));
  await p.waitForTimeout(350);

  console.log('');
  console.log('BUILDING PINS ON THE MAP');
  const r6=await p.evaluate(()=>{
    const out={};
    closeDrawer(true);
    const pid=provsOf(G.player)[0];
    G.bld=G.bld||{};
    G.bld[pid]={walls:3,barracks:2,stables:1,dock:1,market:1};
    const pv=provOf(pid);
    out.city=pv.city;
    const look=w=>{VB={x:pv.cx-w/2,y:pv.cy-(w/2.2)/2,w,h:w/2.2};lastW=null;applyVB();updateMap();};
    look(400);
    const g=()=>document.querySelector('#gPin g[data-p="'+pid+'"] .cpins');
    out.closeIn=g()?g().querySelectorAll('g').length:0;
    out.wallHasLevel=g()?/>3</.test(g().innerHTML):false;
    look(1600);
    out.farOut=g()?g().querySelectorAll('g').length:0;
    // the threshold must be in zoomBand or the pins lag the pinch by 90ms
    out.bandDiffers=zoomBand(400)!==zoomBand(1600);
    look(400);
    // a city with nothing built shows nothing
    const bare=provsOf(G.player).find(x=>x!==pid);
    G.bld[bare]={};
    updateMap();
    out.bareHasPins=!!document.querySelector('#gPin g[data-p="'+bare+'"] .cpins');
    return out;
  });
  console.log('    '+r6.city+' with walls 3, barracks 2, stables, dock, market');
  say(r6.closeIn===5,'zoomed in, five pins under the hex (got '+r6.closeIn+')');
  say(r6.wallHasLevel,'and the wall pin carries its level, because a third ring is a different proposition');
  say(r6.farOut===0,'whole world on screen, no pins at all (got '+r6.farOut+')');
  say(r6.bandDiffers,'the threshold is registered in zoomBand, so they appear on the pinch and not 90ms later');
  say(!r6.bareHasPins,'a city with nothing built draws nothing');

  await p.screenshot({path:'/home/claude/age-of-crowns/docs/shots/v97-phone.png'});
  say(errs.length===0,'no page errors on the phone'+(errs.length?': '+errs.slice(0,2).join(' | '):''));
  await p.close();

  // =============================================================================================
  console.log('');
  console.log('ON A LAPTOP, 1440x900 — the opposite answer');
  const L=await boot(1440,900,false);
  const r7=await L.p.evaluate(()=>{
    const bar=document.getElementById('bbar'), rail=document.getElementById('rail');
    return {barHidden:getComputedStyle(bar).display==='none',
            railShown:getComputedStyle(rail).display!=='none',
            railBtns:rail.querySelectorAll('.rbtn').length,
            railW:Math.round(rail.getBoundingClientRect().width),
            armiesStillWorks:typeof showArmies==='function'};
  });
  say(r7.barHidden,'no bottom bar on a laptop');
  say(r7.railShown,'the rail is still there, all '+r7.railBtns+' of it, '+r7.railW+'px wide');
  say(r7.armiesStillWorks,'and the Armies list is still reachable from code, so nothing is phone-only in the rules');
  say(L.errs.length===0,'no page errors on the laptop'+(L.errs.length?': '+L.errs.slice(0,2).join(' | '):''));
  await L.p.screenshot({path:'/home/claude/age-of-crowns/docs/shots/v97-laptop.png'});
  await L.p.close();

  await b.close();
  const bad=ok.filter(x=>!x).length;
  console.log('');
  console.log(bad?('  '+bad+' FAILED'):'  ALL GREEN');
  process.exit(bad?1:0);
})();

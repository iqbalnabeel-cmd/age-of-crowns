// DOES EMPTYING THE COUNTRYSIDE HAND THE MAP BACK TO THE AI?
//
// v8.9 put levies in 75% of every free province's open country AND a garrison behind walls. It
// worked: free cities went from 1 left on day 14 to 25 left. But the play test found the obvious
// cost — there was a fight in every cell, which is a slog for the player, not just for the AI.
//
// v9.2 moves those men into the city. Same rough headcount per province, one place instead of
// four. The question this answers is whether walls plus a doubled garrison is still a brake, or
// whether the brake was really the countryside all along.
//
// It runs the AI against itself with no human in the loop, which is the harshest reading: a human
// logs in twice a day, the AI never stops.
import * as R from '../server/rules.mjs';

const DAYS = 21;
const WORLDS = 8;

function seed(n){ let s=n>>>0; return ()=>{s=(s*1664525+1013904223)>>>0; return s/4294967296;}; }

function freeCities(){
  let n=0;
  for(const pid in R.MAPD5.provs) if(R.ownerOf(pid)==='neutral') n++;
  return n;
}
function freeFieldArmies(){
  let n=0;
  const G=R.getG();
  for(const cid in G.armies){
    const a=G.armies[cid];
    if(a.e!=='neutral')continue;
    if(R.MAPD5.cells[cid] && R.MAPD5.cells[cid].city)continue;
    n++;
  }
  return n;
}

const CROWNS=Object.keys(R.EMPIRES);
const marks=[1,3,7,14,21];
const rows=[];

for(let w=0;w<WORLDS;w++){
  const rnd=seed(20261120+w*7919);
  Math.random=rnd;
  // shuffle the lineup, or "4 crowns" always means the same four and we measure geography
  const line=CROWNS.slice();
  for(let i=line.length-1;i>0;i--){const j=Math.floor(rnd()*(i+1));[line[i],line[j]]=[line[j],line[i]];}
  const player=line[0], rivals=line.slice(1,4);          // 4 crowns, the common shape
  R.newGame(player,rivals,'norm');

  const seen={day0free:freeCities(), day0field:freeFieldArmies()};
  for(let d=1;d<=DAYS;d++){
    R.advanceClock(24);
    if(marks.includes(d)) seen['d'+d]=freeCities();
  }
  rows.push(seen);
}

const avg=k=>rows.reduce((a,r)=>a+(r[k]||0),0)/rows.length;

console.log('FREE CITIES LEFT, averaged over '+WORLDS+' worlds of 4 crowns, AI against AI');
console.log('');
console.log('  start  '+avg('day0free').toFixed(1)+' free cities, '+avg('day0field').toFixed(1)+' levies standing in open country');
console.log('');
marks.forEach(d=>{
  const v=avg('d'+d);
  const bar='#'.repeat(Math.round(v/2));
  console.log('  day '+String(d).padStart(2)+'   '+v.toFixed(1).padStart(5)+'   '+bar);
});
console.log('');
console.log('  For comparison, measured the same way:');
console.log('    v8.8a (no free lords at all)  day 1: 44.6   day 14:  1.6');
console.log('    v8.9  (walls + countryside)   day 1: 51.3   day 14: 25.5');
console.log('');
console.log('  v9.2 should land near v8.9 on day 14. Much below it and the countryside, not the');
console.log('  walls, was what was holding the AI back, and the garrison needs to go up again.');

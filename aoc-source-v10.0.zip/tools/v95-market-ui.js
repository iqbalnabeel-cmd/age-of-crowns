// THE MARKETPLACE, IN A REAL BROWSER, ON A REAL PHONE VIEWPORT.
//
// v95-market.mjs already proved the engine is honest. This asks the other half of the question:
// can a thumb actually trade? Every assertion here is something a finger does, in order.
//   1. Can he get to it at all, and does it fill the window on a phone?
//   2. Are there offers on the screen, with a price and a button, or is it an empty page?
//   3. Does tapping Buy move gold out and goods in, on screen, with the header updating?
//   4. Can he post his own offer, see it held in escrow, and cancel it back?
//   5. Does war empty the book in front of him, with a reason?
const {chromium}=require('playwright');

(async()=>{
  const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
  const ok=[];
  const say=(c,m)=>{ok.push(c);console.log((c?'  PASS  ':'  FAIL  ')+m);};

  // ---- one game, started the way the start screen starts it ------------------------------------
  async function boot(w,h,mob){
    const p=await b.newPage({viewport:{width:w,height:h},isMobile:mob,hasTouch:mob});
    const errs=[];
    p.on('pageerror',e=>errs.push(String(e)));
    p.on('console',m=>{if(m.type()==='error')errs.push('console: '+m.text());});
    await p.goto('file:///home/claude/age-of-crowns/aoc-v6.html');
    await p.waitForTimeout(400);
    await p.evaluate(()=>{let s=20261121;Math.random=function(){s=(s*1664525+1013904223)>>>0;return s/4294967296;};
      selEmpire='abb';selDiff='norm';refreshStart();});
    await p.evaluate(()=>document.getElementById('startBtn').onclick());
    await p.waitForTimeout(1200);
    await p.evaluate(()=>{G.rate=0;closeDrawer(true);});
    return {p,errs};
  }

  // =============================================================================================
  console.log('ON A PHONE, 390x844');
  const {p,errs}=await boot(390,844,true);

  // Let the AI crowns trade for a week so the book is not empty when he walks in. This is the
  // thing most likely to make the feature read as broken, so the test insists on it.
  await p.evaluate(()=>{advanceClock(24*8);});
  await p.waitForTimeout(200);

  const a=await p.evaluate(()=>{
    const out={};
    out.railHasBtn=!!document.querySelector('#rail button[onclick*="showMarket"]');
    showMarket();
    return out;
  });
  await p.waitForTimeout(420);                       // the drawer slides for 220ms

  const r1=await p.evaluate(()=>{
    const out={};
    const d=document.getElementById('drawer');
    const box=d.getBoundingClientRect();
    out.title=(document.getElementById('dTitle')||{}).textContent||'';
    out.full=d.classList.contains('fullcity');
    out.w=Math.round(box.width); out.h=Math.round(box.height);
    // The drawer lives inside #mapwrap, so "full" means it fills everything BELOW the header.
    // That is deliberate: the gold and resource strip has to stay on screen while you trade, or
    // you are buying blind. So compare against the wrap, and check the strip survived.
    const wrap=document.getElementById('mapwrap').getBoundingClientRect();
    out.wrapH=Math.round(wrap.h||wrap.height);
    out.resbarVisible=(()=>{const rb=document.getElementById('resbar');
      return !!rb&&rb.getBoundingClientRect().height>4;})();
    out.railHidden=getComputedStyle(document.getElementById('rail')).display==='none';
    out.opaque=!/rgba\([^)]*,\s*0?\.\d+\)/.test(getComputedStyle(d).backgroundColor);
    out.tabs=document.querySelectorAll('#panel .dtabs button').length;
    out.bookSize=(G.mkt||[]).length;
    out.rows=document.querySelectorAll('#panel .mkRow').length;
    out.hasBuyHead=/Buy grain/i.test($('panel').innerHTML);
    out.hasSellHead=/Sell grain/i.test($('panel').innerHTML);
    out.hasForm=!!document.getElementById('mkAmt')&&!!document.getElementById('mkPx');
    // every row carries a price and a working button
    out.rowsWithPrice=[...document.querySelectorAll('#panel .mkRow .px')].filter(x=>/\d+(\.\d+)?g/.test(x.textContent)).length;
    out.rowsWithBtn=[...document.querySelectorAll('#panel .mkRow button')].length;
    // can you reach every tab and does each one draw?
    const drew=[];
    RESK.forEach(k=>{mktTab(k);drew.push([k,document.querySelectorAll('#panel .mkRow').length,
      new RegExp(RESN[k],'i').test($('panel').innerHTML)]);});
    out.perTab=drew;
    mktTab('grain');
    return out;
  });

  console.log('  it fills the window: '+r1.w+'x'+r1.h+'  below a '+(844-r1.wrapH)+'px header strip');
  say(a.railHasBtn,'there is a Market button on the rail');
  say(/MARKET/i.test(r1.title),'the banner reads "'+r1.title.trim()+'"');
  say(r1.full&&r1.w>=380&&r1.h>=r1.wrapH-2,'full window on a phone, not a half height drawer');
  say(r1.resbarVisible,'and your gold and materials stay on screen above it, so you trade with your eyes open');
  say(r1.railHidden,'the icon rail is out of the way');
  say(r1.opaque,'the panel is opaque, no parchment showing through');
  say(r1.tabs===5,'five resource tabs ('+r1.tabs+')');
  say(r1.bookSize>=8,'after 8 days the AI crowns have put '+r1.bookSize+' offers on the book');
  say(r1.rows>=1,r1.rows+' tradeable rows on the grain page');
  say(r1.rowsWithPrice===r1.rows,'every row shows a gold price');
  say(r1.rowsWithBtn===r1.rows,'every row has a button');
  say(r1.hasBuyHead&&r1.hasSellHead,'both sides of the book are on the page, Buy and Sell');
  say(r1.hasForm,'and a form to post your own');
  console.log('    tab        rows  names the good');
  r1.perTab.forEach(([k,n,named])=>console.log('    '+k.padEnd(10)+' '+String(n).padStart(4)+'   '+(named?'yes':'NO')));
  say(r1.perTab.every(x=>x[2]),'all five tabs draw and name their good');

  // ---- 3. TAPPING BUY ---------------------------------------------------------------------------
  console.log('');
  console.log('TAPPING BUY');
  const t=await p.evaluate(()=>{
    const out={};
    const e=G.emp[G.player];
    // find a tab that has something to buy, and make sure we can afford it
    let tab=null;
    RESK.forEach(k=>{if(!tab&&mktVisible(G.player,k).some(o=>!o.b&&o.n>0))tab=k;});
    out.tab=tab; if(!tab)return out;
    e.gold=3000;
    mktTab(tab); renderMarket();
    const o=mktVisible(G.player,tab).filter(x=>!x.b).sort((x,y)=>x.px-y.px)[0];
    out.offer={n:o.n,px:o.px,from:empName(o.e)};
    // o.n is reduced IN PLACE by a partial fill, so the lot size has to be copied out before
    // the click or the expected total reads zero afterwards.
    const lotN=o.n, lotPx=o.px;
    const goldBefore=e.gold, haveBefore=Math.floor((e.res||{})[tab]||0);
    const sellerGold=G.emp[o.e].gold;
    const btn=[...document.querySelectorAll('#panel .mkRow button')].find(x=>/^Buy$/.test(x.textContent));
    out.btnFound=!!btn;
    if(btn)btn.click();                                  // a real click, not a function call
    out.goldSpent=goldBefore-e.gold;
    out.gained=Math.floor((e.res||{})[tab]||0)-haveBefore;
    out.sellerPaid=G.emp[o.e].gold-sellerGold;
    out.expected=Math.ceil(lotN*lotPx);
    out.hdrGold=(document.getElementById('hdr')||document.body).innerHTML.includes(String(Math.floor(e.gold)));
    out.resbarShows=(document.getElementById('resbar')||{}).textContent||'';
    return out;
  });
  say(!!t.tab,'something was for sale: '+t.tab);
  say(t.btnFound,'the Buy button is there and clickable');
  say(t.gained>0,'goods arrived: +'+t.gained+' '+t.tab+' from '+(t.offer||{}).from);
  say(t.goldSpent>0&&t.goldSpent===t.expected,'gold left at the asking price: '+t.goldSpent+'g (asked '+t.expected+'g)');
  say(t.sellerPaid===t.goldSpent,'and the seller was paid exactly that, '+t.sellerPaid+'g');
  say(t.hdrGold,'the header gold updated on screen');

  // ---- 4. POSTING AND CANCELLING ----------------------------------------------------------------
  console.log('');
  console.log('POSTING YOUR OWN OFFER, AND TAKING IT BACK');
  const q=await p.evaluate(()=>{
    const out={};
    const e=G.emp[G.player];
    e.res.stone=300;
    mktTab('stone'); mktSide('sell'); renderMarket();
    const before=Math.floor(e.res.stone), mineBefore=mktMine(G.player).length;
    document.getElementById('mkAmt').value='40';
    document.getElementById('mkPx').value=String(mktPrices('stone').base);
    [...document.querySelectorAll('#panel button')].find(x=>/Put it on the market/i.test(x.textContent)).click();
    out.posted=mktMine(G.player).length-mineBefore;
    out.heldBack=before-Math.floor(e.res.stone);
    out.listedOnScreen=/Selling 40 stone/i.test(document.getElementById('panel').innerHTML);
    out.sayItsHeld=/set aside/i.test(document.getElementById('panel').innerHTML);
    // and now cancel it with the button on the row
    const cb=[...document.querySelectorAll('#panel .mkRow button')].find(x=>/^Cancel$/.test(x.textContent));
    out.cancelFound=!!cb; if(cb)cb.click();
    out.backAfterCancel=Math.floor(e.res.stone)-(before-40);
    out.mineNow=mktMine(G.player).length;
    // the cap, and a refusal with a reason
    for(let i=0;i<MKT_PER_EMP+2;i++)doOrder({type:'mktPost',r:'stone',buy:false,n:5,px:3});
    out.cappedAt=mktMine(G.player).length;
    const over=doOrder({type:'mktPost',r:'stone',buy:false,n:5,px:3});
    out.capWhy=over.why||'';
    const silly=doOrder({type:'mktPost',r:'stone',buy:false,n:5,px:99});
    out.priceWhy=silly.why||'';
    return out;
  });
  say(q.posted===1,'the offer went up');
  say(q.heldBack===40,'40 stone was set aside at once, not when it sells');
  say(q.listedOnScreen,'it appears under "Your offers" straight away');
  say(q.sayItsHeld,'and the screen says the stone is being held');
  say(q.cancelFound,'Cancel is on the row');
  say(q.backAfterCancel===40,'cancelling gave all 40 back');
  say(q.mineNow===0,'and the offer is gone from your list');
  say(q.cappedAt===5,'you can hold at most '+q.cappedAt+' offers at a time');
  say(/\b5\b|most|limit|at a time/i.test(q.capWhy),'the sixth is refused in words: "'+q.capWhy+'"');
  say(/price|between|gold/i.test(q.priceWhy),'a silly price is refused in words: "'+q.priceWhy+'"');

  // ---- 5. WAR ------------------------------------------------------------------------------------
  console.log('');
  console.log('WAR SHUTS THE DOOR, ON SCREEN');
  const w=await p.evaluate(()=>{
    const out={};
    // find a crown that is selling something to us
    let vic=null,res=null;
    RESK.forEach(k=>{if(vic)return;const o=mktVisible(G.player,k).filter(x=>!x.b&&x.e!==G.player)[0];
      if(o){vic=o.e;res=k;}});
    out.vic=vic?empName(vic):null; out.res=res; if(!vic)return out;
    mktTab(res); renderMarket();
    out.beforeRows=[...document.querySelectorAll('#panel .mkRow .who')].filter(x=>x.textContent.includes(empName(vic))).length;
    declareWar(G.player,vic);
    renderMarket();
    out.afterRows=[...document.querySelectorAll('#panel .mkRow .who')].filter(x=>x.textContent.includes(empName(vic))).length;
    // and if we somehow still had the id, the order is refused with a reason
    const id=(G.mkt||[]).filter(o=>o.e===vic&&!o.b)[0];
    if(id){const rr=doOrder({type:'mktTake',id:id.i,n:1});out.refusedWhy=rr.why||'';out.refused=!rr.ok;}
    out.noteOnScreen=/at war with will not deal/i.test(document.getElementById('panel').innerHTML);
    return out;
  });
  say(!!w.vic,'a crown was selling us '+w.res+': '+w.vic);
  say(w.beforeRows>0,'at peace, '+w.beforeRows+' of its rows were on the page');
  say(w.afterRows===0,'the day war is declared its rows are gone');
  say(w.refused===true,'and the trade is refused: "'+(w.refusedWhy||'')+'"');
  say(/war/i.test(w.refusedWhy||''),'with war named as the reason');
  say(w.noteOnScreen,'the screen tells him this rule before he finds out the hard way');

  await p.screenshot({path:'/home/claude/age-of-crowns/docs/shots/v95-market-phone.png'});
  say(errs.length===0,'no page errors on the phone'+(errs.length?': '+errs.slice(0,2).join(' | '):''));
  await p.close();

  // =============================================================================================
  console.log('');
  console.log('ON A LAPTOP, 1280x800');
  const L=await boot(1280,800,false);
  await L.p.evaluate(()=>{advanceClock(24*8);});
  await L.p.evaluate(()=>{showMarket();});
  await L.p.waitForTimeout(420);
  const r2=await L.p.evaluate(()=>{
    const d=document.getElementById('drawer'),box=d.getBoundingClientRect();
    return {w:Math.round(box.width),vw:window.innerWidth,
      rail:getComputedStyle(document.getElementById('rail')).display,
      rows:document.querySelectorAll('#panel .mkRow').length,
      mapVisible:document.getElementById('map').getBoundingClientRect().width>200};
  });
  console.log('  drawer '+r2.w+'px of a '+r2.vw+'px window');
  say(r2.w<r2.vw*0.6,'on a laptop it stays a side drawer, not the whole window');
  say(r2.rail!=='none','the rail is still there');
  say(r2.mapVisible,'and the map is still visible beside it');
  say(r2.rows>=1,'the same offers are on it ('+r2.rows+' rows)');
  await L.p.screenshot({path:'/home/claude/age-of-crowns/docs/shots/v95-market-laptop.png'});
  say(L.errs.length===0,'no page errors on the laptop'+(L.errs.length?': '+L.errs.slice(0,2).join(' | '):''));
  await L.p.close();

  await b.close();
  const bad=ok.filter(x=>!x).length;
  console.log('');
  console.log(bad?('  '+bad+' FAILED'):'  ALL GREEN');
  process.exit(bad?1:0);
})();

// HIS v9.9 PLAY TEST, TURNED INTO ASSERTIONS.
//
// Three things he reported, and the one underneath them that neither of us saw at first:
//
//   "When there is no timber, when I click on Build, no message shows that I don't have
//    resources, or anything happens. It looks like the buttons are not working."
//   "Build and queue buttons not working"
//
// Those are two symptoms of THE SAME BUG, and it is not a button bug at all. `queueBlocked` has
// returned 'res' (short of materials) and 'men' (short of manpower) since v9.4. `pumpQueues`
// never handled either. They fell through to a splice written in v8.7 whose comment reads
// "started, or impossible: either way it leaves the queue".
//
// So for six builds, QUEUING ANYTHING YOU LACKED THE MATERIALS FOR DELETED IT ON THE NEXT TICK.
import * as R from '../server/rules.mjs';

const CROWNS=Object.keys(R.EMPIRES);
function seed(n){let s=n>>>0;return ()=>{s=(s*1664525+1013904223)>>>0;return s/4294967296;};}
const ok=[];const say=(c,m)=>{ok.push(c);console.log((c?'  PASS  ':'  FAIL  ')+m);};

Math.random=seed(20261124);
R.newGame(CROWNS[0],CROWNS.slice(1),'norm');

console.log('1. A QUEUED ITEM SURVIVES BEING SHORT OF MATERIALS');
{
  const G=R.getG();
  const me=G.player;
  const pid=R.provsOf(me).find(p=>R.bldLv(p,'range')<1)||R.provsOf(me)[1];
  G.emp[me].gold=5000;
  R.RESK.forEach(r=>{G.emp[me].res[r]=500;});
  G.emp[me].res.timber=0;                       // his exact situation
  console.log('    '+R.provOf(pid).city+': 5000 gold, 500 of everything, and ZERO timber');

  const need=R.bldRes('range',R.bldLv(pid,'range'));
  say(!!need&&need.timber>0,'an Archery Range needs timber ('+JSON.stringify(need)+')');
  say(R.queueBlocked(pid,{k:'b',b:'range'},me)==='res',
      'the queue knows exactly why it cannot start: "'+R.queueBlocked(pid,{k:'b',b:'range'},me)+'"');

  const q=R.ORDERS.build(me,{pid,b:'range',q:1});
  say(q.ok,'it queues');
  say(R.cityQueue(pid).some(x=>x.b==='range'),'and it is in the queue');

  R.advanceClock(1);                            // ONE TICK. This is where it used to disappear.
  say(R.cityQueue(pid).some(x=>x.b==='range'),
      'IT IS STILL THERE AFTER A TICK  <<< this is the bug he found');

  R.advanceClock(6);
  say(R.cityQueue(pid).some(x=>x.b==='range')||R.bldLv(pid,'range')>0||((R.getG().buildQ||{})[pid]||{}).b==='range',
      'and still there six hours later, or started because the timber came in');
}

console.log('');
console.log('2. SHORT OF TIMBER DOES NOT HOLD UP SOMETHING MADE OF STONE');
{
  Math.random=seed(44);
  R.newGame(CROWNS[0],CROWNS.slice(1),'norm');
  const G=R.getG(), me=G.player;
  const pid=R.provsOf(me)[1];
  G.emp[me].gold=5000; R.RESK.forEach(r=>{G.emp[me].res[r]=500;}); G.emp[me].res.timber=0;
  delete G.buildQ[pid];
  R.ORDERS.build(me,{pid,b:'range',q:1});       // wants timber, which we have none of
  R.ORDERS.build(me,{pid,b:'walls',q:1});       // wants stone, which we have plenty of
  R.advanceClock(1);
  const started=((G.buildQ||{})[pid]||{}).b;
  say(started==='walls','the walls went up anyway (started: '+started+')');
  say(R.cityQueue(pid).some(x=>x.b==='range'),'and the range is still waiting its turn');
  console.log('    This is deliberately UNLIKE gold. Gold is one pool, so the first claim on it');
  console.log('    blocks the rest. Materials are five pools: timber is no reason stone waits.');
}

console.log('');
console.log('3. THE SAME BUG HIT UNITS, NOT JUST BUILDINGS');
{
  Math.random=seed(55);
  R.newGame(CROWNS[0],CROWNS.slice(1),'norm');
  const G=R.getG(), me=G.player;
  const pid=R.provsOf(me)[0];
  G.emp[me].gold=5000; R.RESK.forEach(r=>{G.emp[me].res[r]=500;});
  const t=R.UKEYS.find(x=>R.canRecruit(pid,x)&&R.UNITRES[x]&&R.UNITRES[x].iron);
  if(t){
    G.emp[me].res.iron=0;
    say(R.queueBlocked(pid,{k:'u',t},me)==='res',R.UNITS[t].name+' is blocked on materials');
    R.ORDERS.recruit(me,{pid,t,q:1});
    R.advanceClock(1);
    say(R.cityQueue(pid).some(x=>x.t===t),'and the order survives the tick');
  }
  // and short of MEN
  Math.random=seed(56);
  R.newGame(CROWNS[0],CROWNS.slice(1),'norm');
  const G2=R.getG();
  const p2=R.provsOf(me)[0];
  G2.emp[me].gold=5000; R.RESK.forEach(r=>{G2.emp[me].res[r]=500;}); G2.emp[me].men=0;
  const t2=R.UKEYS.find(x=>R.canRecruit(p2,x));
  say(R.queueBlocked(p2,{k:'u',t:t2},me)==='men','with no men it says so');
  R.ORDERS.recruit(me,{pid:p2,t:t2,q:1});
  R.advanceClock(1);
  say(R.cityQueue(p2).some(x=>x.t===t2),'and that order survives the tick too');
}

console.log('');
console.log('4. NOTHING THAT SHOULD BE DROPPED IS NOW KEPT FOREVER');
{
  Math.random=seed(66);
  R.newGame(CROWNS[0],CROWNS.slice(1),'norm');
  const G=R.getG(), me=G.player;
  const pid=R.provsOf(me)[1];
  G.emp[me].gold=5000; R.RESK.forEach(r=>{G.emp[me].res[r]=500;});
  delete G.buildQ[pid];
  // a building that finishes should leave, not loop
  R.ORDERS.build(me,{pid,b:'walls',q:1});
  R.advanceClock(1);
  say(!R.cityQueue(pid).some(x=>x.b==='walls'),'an item that STARTS still leaves the queue');
  // Losing the city clears its queue. Note this must go through claimCell: writing cellOwner by
  // hand skips the v9.8 cleanup, and pumpQueues then happily runs the queue FOR THE CONQUEROR,
  // because it reads the owner fresh each tick. The first version of this test did exactly that
  // and reported a failure that was its own.
  R.ORDERS.build(me,{pid,b:'granary',q:1});
  say(R.cityQueue(pid).some(x=>x.b==='granary'),'a granary is queued');
  R.claimCell(R.CITYCELL[pid],'fra',{spear:9});
  say(R.ownerOf(pid)==='fra','France takes the city');
  say(!R.cityQueue(pid).length,'and the queue goes with it, rather than being inherited');
}

console.log('');
const bad=ok.filter(x=>!x).length;
console.log(bad?('  '+bad+' FAILED'):'  ALL GREEN');
process.exit(bad?1:0);

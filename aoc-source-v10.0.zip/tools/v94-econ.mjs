// DOES THE ECONOMY WORK, AND WHAT DID IT COST THE PACE?
//
// Three questions, in order of how badly a wrong answer would hurt.
//
//   1. Can a crown actually build anything? A second gate on every purchase is very easy to set
//      too tight, and the failure is silent: the AI just stops buying and the game stalls.
//   2. Is grain the surplus Nabeel asked for? "Make sure that the city creates a surplus amount so
//      that at the start it doesn't feel difficult to expand."
//   3. How much slower is the game? v9.2 was spent making it faster and this pushes back.
import * as R from '../server/rules.mjs';

const CROWNS=Object.keys(R.EMPIRES);
function seed(n){let s=n>>>0;return ()=>{s=(s*1664525+1013904223)>>>0;return s/4294967296;};}

// ---------- 1. the opening position ------------------------------------------------------------
Math.random=seed(20261121);
R.newGame(CROWNS[0],CROWNS.slice(1),'norm');
let G=R.getG();

console.log('WHAT EACH CROWN MAKES AND HOLDS ON DAY ONE');
console.log('');
console.log('crown'.padEnd(20)+'gold'.padStart(5)+R.RESK.map(r=>r.padStart(8)).join('')+'     men');
CROWNS.forEach(k=>{
  const m={};R.RESK.forEach(r=>m[r]=0);
  R.provsOf(k).forEach(pid=>{const r=R.CITYRES[pid];if(r)m[r]+=R.RES_PER_CITY[r];});
  console.log(R.EMPIRES[k].name.slice(0,19).padEnd(20)+String(R.incomeOf(k)).padStart(5)+
    R.RESK.map(r=>String(m[r]).padStart(8)).join('')+R.manpowerOf(k).toFixed(1).padStart(8));
});

// ---------- 2. is grain really a surplus? ------------------------------------------------------
console.log('');
console.log('GRAIN: what you make against what your army eats');
console.log('');
console.log('crown'.padEnd(20)+'grain/day'.padStart(10)+'troops'.padStart(8)+'eaten/day'.padStart(10)+'   spare   feeds');
let tightest=1e9;
CROWNS.forEach(k=>{
  let made=0;
  R.provsOf(k).forEach(pid=>{if(R.CITYRES[pid]==='grain')made+=R.RES_PER_CITY.grain;});
  let troops=0;
  for(const c in G.armies) if(G.armies[c].e===k) troops+=R.cnt(G.armies[c].u);
  const eaten=R.grainEatenBy(k);
  const feeds=Math.floor(made/R.GRAIN_FIELD);
  tightest=Math.min(tightest,made-eaten);
  console.log(R.EMPIRES[k].name.slice(0,19).padEnd(20)+String(made).padStart(10)+String(troops).padStart(8)+
    eaten.toFixed(1).padStart(10)+(made-eaten).toFixed(1).padStart(8)+feeds.toString().padStart(8)+' in the field');
});
console.log('');
console.log('  tightest crown has '+tightest.toFixed(1)+' grain a day spare on the first morning');

// ---------- 3. can a crown build? --------------------------------------------------------------
console.log('');
console.log('A DAY OF INCOME, AND WHAT IT BUYS');
const k0=CROWNS[0];
const e0=G.emp[k0];
console.log('  '+R.EMPIRES[k0].name+': '+R.incomeOf(k0)+' gold, '+R.manpowerOf(k0).toFixed(0)+' men, and its materials');
[['militia','Militia Spears'],['spear','Spearmen'],['longbow','Longbows'],['knight','Knights'],['trebuchet','Trebuchets']]
 .forEach(([t,nm])=>{
  const u=R.UNITS[t], need=R.UNITRES[t]||{};
  let made={};R.RESK.forEach(r=>made[r]=0);
  R.provsOf(k0).forEach(pid=>{const r=R.CITYRES[pid];if(r)made[r]+=R.RES_PER_CITY[r];});
  const byGold=Math.floor(R.incomeOf(k0)/u.cost);
  const byMen=Math.floor(R.manpowerOf(k0)/R.unitMen(t));
  const byRes=Math.min(...Object.keys(need).map(r=>Math.floor(made[r]/need[r])).concat([99]));
  const bind=byRes<=byGold&&byRes<=byMen?'materials':(byGold<=byMen?'gold':'men');
  console.log('    '+nm.padEnd(16)+'gold allows '+String(byGold).padStart(2)+
    ', men '+String(byMen).padStart(2)+', materials '+String(byRes===99?'-':byRes).padStart(2)+
    '  a day   <- '+bind+' binds');
});

// ---------- 4. the pace, AI against AI ---------------------------------------------------------
console.log('');
console.log('THE PACE, eight crowns, nobody in your chair, 8 worlds');
console.log('');
const marks=[7,14,21,30];
const got={};marks.forEach(d=>got[d]=[]);
const ended=[];
for(let w=0;w<8;w++){
  Math.random=seed(20261121+w*7919);
  const line=CROWNS.slice();
  for(let i=line.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[line[i],line[j]]=[line[j],line[i]];}
  R.newGame(line[0],line.slice(1),'norm');
  G=R.getG();
  let done=null;
  // v9.8: 100 days, not 60. Two things changed. The conquest cap serialises absorption, so a
  // campaign takes about a third longer: measured over SIXTEEN worlds with every crown played,
  // the median is 35 and the longest 55. And THIS harness leaves the player's crown INERT for the
  // whole run, which is a harder world than any real one, since six cities sit there doing
  // nothing. Run out to 140 days all eight of these finish; the slowest takes 92. At 60 the
  // harness was reporting failures that were only worlds still in progress.
  for(let d=1;d<=100;d++){
    R.advanceClock(24);
    if(marks.includes(d)){
      let best=0;
      Object.keys(R.EMPIRES).forEach(k=>{best=Math.max(best,R.provsOf(k).length);});
      got[d].push(best);
    }
    if(R.getG().over&&!done){done=d;break;}
  }
  ended.push(done);
}
const avg=a=>a.length?(a.reduce((x,y)=>x+y,0)/a.length):0;
console.log('  day   biggest empire (cities of 80)');
marks.forEach(d=>{
  if(!got[d].length)return;
  console.log('  '+String(d).padStart(3)+'   '+avg(got[d]).toFixed(1).padStart(5)+'   '+'#'.repeat(Math.round(avg(got[d])/2)));
});
const fin=ended.filter(x=>x);
console.log('');
console.log('  games reaching the win line inside 100 days: '+fin.length+' of 8'+
  (fin.length?('   median day '+fin.slice().sort((a,b)=>a-b)[Math.floor(fin.length/2)]):''));
console.log('');
console.log('  v9.3 measured, same bar of 30, eight crowns: 8/8, median 23 days.');
console.log('  Slower than that is expected and is the price of the economy. Much slower, or');
console.log('  games that stop finishing, means a cost is set too high.');

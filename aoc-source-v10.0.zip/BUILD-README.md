# Age of Crowns — source

This is everything needed to rebuild the game. The repo on GitHub holds only the BUILT files, so
this zip is the only copy of the source that outlives the cloud sandbox. It has been lost and
rebuilt from the shipped HTML three times; that is what this is for.

## Rebuild

    node build.mjs

Writes `dist/aoc-<version>.html`, `aoc-v6.html` (the stable name the test harnesses load),
`server/rules.mjs` and `worker.js`.

    node build.mjs --verify dist/aoc-v9.8.html

Proves the source tree rebuilds the shipped file byte for byte.

## What is in here

| Folder | What it is |
| --- | --- |
| `src/` | the whole game, in eight pieces that the build concatenates in order |
| `tools/` | the test harnesses, one per build, plus the regression suite |
| `docs/deploy-doc.md` | the project memory: every rule, every measurement, every bug and why |
| `build.mjs` | the build, including the guard that fails if the rules half touches the browser |

## The build order

`src/shell-head.html` + `data.js` + `rules.js` + `orders.js` + `ui.js` + `net.js` + `boot.js`
+ `shell-tail.html`

`data.js`, `rules.js` and `orders.js` must never reference the browser. The build fails if they do,
and that guard is the single reason multiplayer took one build instead of five.

## Running the tests

    node build.mjs
    node tools/regress.mjs          # the rulings, the wire format, the names, the win line
    node tools/v98-last.mjs         # the newest build's rules
    node tools/v98-last-ui.js       # the newest build's screens, in a real browser

Harnesses import `server/rules.mjs`, which is a BUILD ARTEFACT. Run `node build.mjs` first, always.

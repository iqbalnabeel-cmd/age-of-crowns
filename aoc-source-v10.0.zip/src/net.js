// ==================== v7.9: PLAYING ONLINE — browser only ====================
// One shared world lives on a server. This is the whole of the client's side of it, and it is
// deliberately small, because of a decision made eight builds ago and kept ever since: the rules
// never touch the browser, so the same code that runs here runs there.
//
// Which leaves exactly two differences between an online game and an offline one.
//   1. The clock is not ours. The server owns time; we ask what o'clock it is.
//   2. An order is a request, not a mutation. `doOrder` is the only way the world ever changes,
//      offline as well as online, so switching between them is one branch in one function.
//
// The world arrives as a save code. That was already a complete, tested, 2KB description of a
// game, so nothing new had to be invented to put one on a wire.

const NET = {
  on: false,
  base: '',            // where the server is
  code: '',            // the world code you share
  token: '',           // proves which crown is yours; never leaves this device except to the server
  empire: '',
  players: [],
  rate: 1,
  poll: null,
  ready: false,
  lastSeq: -1,
  err: '',
  // v8.0: the lobby. A world does not run until somebody begins it.
  started: false,
  host: '',
  canAnyoneBegin: false,
  free: [],
  inLobby: false
};

// Where the server lives. Set at build time by whoever deploys it; a player never types a URL.
// If it is left empty the online buttons say so plainly rather than failing at the first tap.
const SERVER_URL = 'https://nabeel-personal-project.iqbalnabeel-bca.workers.dev';

function netConfigured(){ return !!(SERVER_URL || localStorage.getItem('aocServer')); }
function netBase(){ return (localStorage.getItem('aocServer') || SERVER_URL || '').replace(/\/+$/, ''); }

async function netCall(path, body){
  const base = netBase();
  if(!base) throw new Error('No server address is set for this build.');
  const res = await fetch(base + path, body ? {
    method: 'POST', headers: {'content-type': 'application/json'}, body: JSON.stringify(body)
  } : {});
  let data = null;
  try{ data = await res.json(); }catch(e){ throw new Error('The server said something I could not read.'); }
  if(!res.ok) throw new Error((data && data.error) || ('The server refused that (' + res.status + ').'));
  return data;
}

// ---- taking the world the server sent, and putting it on screen --------------------------
function netAdopt(state){
  if(!state || !state.save) return;
  const g = unpackSave(state.save);
  g.player = NET.empire;                 // the crown this device holds, whatever the save says
  // Selections are ours, not the world's. Carry them across a refresh so the panel you had open
  // does not shut every three seconds.
  const keep = G ? {selArmy: G.selArmy, selCity: G.selCity, selSea: G.selSea, selCol: G.selCol,
                    selFight: G.selFight, mode: G.mode, targeting: G.targeting,
                    marchInfo: G.marchInfo, send: G.send, sendSplit: G.sendSplit,
                    forced: G.forced, moreOpen: G.moreOpen, cityTab: G.cityTab,
                    recDom: G.recDom, recSub: G.recSub, route: G.route} : {};
  setG(g);
  Object.assign(G, keep);
  if(G.selArmy && !G.armies[G.selArmy]) G.selArmy = null;      // it marched, or it died
  if(G.selCol && !(G.col && G.col[G.selCol])) G.selCol = null;
  NET.players = state.players || [];
  NET.rate = state.rate || 1;
  NET.started = !!state.started;
  NET.host = state.host || '';
  NET.canAnyoneBegin = !!state.canAnyoneBegin;
  NET.free = state.free || [];
  // Show the world's real speed in the header. It is a readout, not a control: clockTick refuses
  // to advance anything while NET.on, because the server owns time.
  G.rate = NET.rate;
  // The very first world arrives before the map exists, because the map is built from it. Draw
  // only once there is something to draw on.
  if(!NET.ready){
    // v8.0: while we are sitting in the lobby the same three-second poll is what tells us somebody
    // else has joined, and what tells us the war has begun.
    if(NET.inLobby){
      if(NET.started){ NET.inLobby = false; closeModal(); enterOnlineGame(); }
      else paintLobby();
    }
    return;
  }
  if(G.targeting && G.selArmy) computeMarch();
  renderAll();
  paintNetBar();
  if(G.over) paintOutcome();
}

function netStart(){
  netStop();
  NET.poll = setInterval(netRefresh, 3000);
  NET.on = true;
}
function netStop(){ if(NET.poll) clearInterval(NET.poll); NET.poll = null; }

async function netRefresh(){
  if(!NET.on) return;
  try{
    const s = await netCall('/api/' + NET.code + '/state');
    NET.err = '';
    netAdopt(s);
  }catch(e){
    NET.err = e.message;
    paintNetBar();
  }
}

// ---- the one door ------------------------------------------------------------------------
// Offline this runs the order here. Online it asks the server to run it and takes back whatever
// world comes out. Either way the answer is the same shape, so nothing that calls it has to know
// which kind of game it is in.
function doOrder(o){
  if(!NET.on){
    const r = applyOrder(G.player, o);
    if(!r.ok && r.why) toast(r.why);
    return r;
  }
  netCall('/api/' + NET.code + '/order', {token: NET.token, order: o})
    .then(res => {
      if(res.result && !res.result.ok && res.result.why) toast(res.result.why);
      netAdopt(res.state);
    })
    .catch(e => toast(e.message));
  return {ok: true, pending: true};      // the world will catch up in a moment
}

// ---- the worlds this device is in --------------------------------------------------------
// v8.0: there used to be room for exactly one. Anybody playing two games at once, or coming back
// to last week's, had to have kept the code somewhere themselves. The token is what proves a crown
// is yours, so this list is also the only thing standing between a player and losing their empire
// by clearing a browser tab.
function netWorlds(){
  try{
    const a = JSON.parse(localStorage.getItem('aocWorlds') || '[]');
    return Array.isArray(a) ? a.filter(w => w && w.code && w.token) : [];
  }catch(e){ return []; }
}
function netSaveWorlds(list){
  try{ localStorage.setItem('aocWorlds', JSON.stringify(list.slice(0, 12))); }catch(e){}
}
function netRemember(code, token, empire, name){
  const list = netWorlds().filter(w => w.code !== code);
  list.unshift({code, token, empire, name: name || '', at: Date.now()});
  netSaveWorlds(list);
  try{ localStorage.setItem('aocNet', JSON.stringify({code, token, empire, name: name || ''})); }catch(e){}
}
function netForget(code){
  netSaveWorlds(netWorlds().filter(w => w.code !== code));
}

// A link that carries the code, so nobody has to spell one out. It points at this same file,
// because that is where the game lives, with the code in the hash.
function netInviteFor(code){
  return location.origin + location.pathname + '#w=' + code;
}

// ---- joining and leaving -----------------------------------------------------------------
// v8.6: `rivals` is gone. A shared world holds every crown, so the host chooses which one is
// theirs and nothing else. See the create route in worker.js for why.
async function netCreate(empire, diff, name, rate, len){
  buildCadj();                                   // the province graph, before any world is read
  // v9.8: the host's chosen war length rides along. The server is the only thing that may set a
  // world's bar, same as everything else: the client asks, the server decides.
  const d = await netCall('/api/new', {empire, diff, name, rate, len});
  NET.code = d.code; NET.token = d.token; NET.empire = d.empire;
  netRemember(NET.code, NET.token, NET.empire, name);
  netAdopt(d.state);
  netStart();
  return d;
}

// v8.6: look a world up WITHOUT joining it, so the crown picker can be filled in before anybody
// commits to a seat. /state is a plain GET and needs no token: the code is the only key a shared
// world has, which is exactly what sharing it is for.
async function netPeek(code){
  buildCadj();
  return netCall('/api/' + String(code).toUpperCase() + '/state');
}

async function netJoin(code, name, empire, token){
  buildCadj();
  const use = token || NET.token || netWorlds().find(w => w.code === String(code).toUpperCase());
  const tk = typeof use === 'string' ? use : (use && use.token) || undefined;
  const d = await netCall('/api/' + code + '/join', {name, empire, token: tk});
  NET.code = String(code).toUpperCase(); NET.token = d.token; NET.empire = d.empire;
  netRemember(NET.code, NET.token, NET.empire, name);
  netAdopt(d.state);
  netStart();
  return d;
}

async function netBegin(){
  const d = await netCall('/api/' + NET.code + '/begin', {token: NET.token});
  netAdopt(d.state);
  return d;
}

function netLeave(){
  netStop();
  NET.on = false; NET.ready = false; NET.inLobby = false;
  NET.code = ''; NET.token = ''; NET.empire = '';
  localStorage.removeItem('aocNet');
}


// ==================== the screens ====================

// A world code is six characters chosen so nobody can misread them: no vowels, no 0 or O, no 1 or
// I. It exists to be read out loud over the phone.
function netCodeInput(v){ return String(v||'').toUpperCase().replace(/[^A-Z0-9]/g,'').slice(0,10); }

// ==================== v9.1: THE SHARED-WORLDS LOBBY ====================
// What this replaces: a modal that listed a six-letter code and a Rejoin button. That was the
// whole of it. A returning player was told nothing about the world they were returning to — not
// the day, not who was winning, not that it had moved sixteen hours since they last looked. In a
// game built on the world running while you are away, the screen that says what it did while you
// were away is the point, and there wasn't one.
//
// Every number on these cards comes from /api/<code>/state, which the server has served since
// v7.9 and nothing ever read. netPeek takes no seat and costs nothing, so a card can be filled in
// for a world you are not currently in.

let LB={tab:'mine',rate:1,peeks:{}};

function showOnline(){
  if(!netConfigured()){ askForServer(); return; }
  const lb=document.getElementById('lobby');
  if(!lb)return;
  lb.classList.add('show');
  // An invite link lands you on Join with the code already in the box; otherwise start where your
  // own worlds are, because that is what a returning player came for.
  LB.tab = netPendingCode ? 'join' : 'mine';
  lobbyNavPaint('worlds');
  lobbyTab(LB.tab);
  paintLobbyReturn();
}

function closeLobby(){
  const lb=document.getElementById('lobby');
  if(lb)lb.classList.remove('show');
}

// The top-right slot is contextual, exactly as the reference does it: it carries the one thing you
// most want from this screen, and only when there is one. No live world, no button.
function paintLobbyReturn(){
  const b=document.getElementById('lbReturn');
  if(!b)return;
  b.classList.toggle('show', !!(NET&&NET.on&&NET.code));
}
function lobbyReturnToGame(){
  closeLobby();
  if(NET.inLobby)showLobby(); else enterOnlineGame();
}

function lobbyNav(which){
  if(which==='solo'){ closeLobby(); return; }          // the start screen is already behind us
  if(which==='help'){ showHelp(); return; }
  lobbyNavPaint('worlds');
  lobbyTab(LB.tab);
}
function lobbyNavPaint(on){
  [['worlds','lbNavWorlds'],['solo','lbNavSolo'],['help','lbNavHelp']].forEach(([k,id])=>{
    const el=document.getElementById(id);
    if(el)el.classList.toggle('on',k===on);
  });
}

function lobbyTab(which){
  LB.tab=which;
  [['mine','lbTabMine'],['join','lbTabJoin'],['new','lbTabNew']].forEach(([k,id])=>{
    const el=document.getElementById(id);
    if(el)el.classList.toggle('on',k===which);
  });
  if(which==='mine')paintLobbyMine();
  else if(which==='join')paintLobbyJoin();
  else paintLobbyNew();
}

function rateName(r){
  return ({1:'Real time',60:'1 min = 1 hour',600:'1 sec = 10 min',3600:'1 sec = 1 hour'})[r]||'Real time';
}

// ---- My worlds -------------------------------------------------------------------------------
function paintLobbyMine(){
  const el=document.getElementById('lbBody');
  if(!el)return;
  const mine=netWorlds();
  if(!mine.length){
    el.innerHTML='<div class="lbEmpty">You are not in any shared world yet.<br><br>'+
      '<b>Join</b> one with a code somebody sent you, or make a <b>New</b> one and send the link back.</div>';
    return;
  }
  // Draw every card at once from what this device already knows, then fill each one in as its
  // state arrives. A slow or dead server leaves you looking at your worlds, not at a spinner.
  el.innerHTML=mine.map(w=>'<div class="wcard" id="wc_'+w.code+'">'+worldCardHtml(w,null,null)+'</div>').join('');
  mine.forEach(w=>{
    netPeek(w.code)
      .then(st=>{ LB.peeks[w.code]=st; fillCard(w,st,null); })
      .catch(e=>fillCard(w,null,e&&e.message||'could not be reached'));
  });
}

function fillCard(w,st,err){
  const box=document.getElementById('wc_'+w.code);
  if(!box)return;
  box.innerHTML=worldCardHtml(w,st,err);
}

function worldCardHtml(w,st,err){
  const mine=empName(w.empire);
  let badge='<span class="wcState">checking...</span>';
  if(err)badge='<span class="wcState lost">out of reach</span>';
  else if(st){
    if(st.over)badge='<span class="wcState done">finished</span>';
    else if(!st.started)badge='<span class="wcState wait">waiting to begin</span>';
    else badge='<span class="wcState live">running</span>';
  }
  let h='<div class="wcTop"><span class="wcCode">'+w.code+'</span>'+badge+'</div>'+
        '<div class="wcWho">You hold <b>'+mine+'</b></div>';
  if(st){
    const taken=(st.players||[]).length, total=(st.standings||[]).length||8;
    const sorted=(st.standings||[]);
    const lead=sorted[0];
    const me=sorted.find(x=>x.k===w.empire);
    const place=me?(sorted.indexOf(me)+1):null;
    const ord=n=>n+({1:'st',2:'nd',3:'rd'}[n>20?n%10:n]||'th');
    h+='<div class="wcFacts">'+
       '<div><div class="k">Day</div><div class="v big">'+(st.started?st.day:'not begun')+'</div></div>'+
       '<div><div class="k">Crowns taken</div><div class="v">'+taken+' of '+total+'</div></div>'+
       (lead?'<div><div class="k">Leading</div><div class="v">'+lead.name+', '+lead.cities+'</div></div>':'')+
       (me?'<div><div class="k">You</div><div class="v">'+ord(place)+', '+me.cities+' cities</div></div>':'')+
       '<div><div class="k">Speed</div><div class="v">'+rateName(st.rate)+'</div></div>'+
       '</div>';
    if(st.over&&st.outcome&&st.outcome.msg)h+='<div class="wcNote">'+st.outcome.msg+'</div>';
    else if(!st.started)h+='<div class="wcNote">The clock has not started. Nobody is ahead of anybody yet.</div>';
  }else if(err){
    h+='<div class="wcNote bad">The server did not answer, so this is what this device remembers '+
       'rather than what the world looks like now. Your crown is not lost.</div>';
  }
  const label=st&&st.over?'Look at it':(st&&!st.started?'Go to the lobby':'Return to this war');
  h+='<div class="wcRow">'+
     '<button class="ret" onclick="uiRejoin(\''+w.code+'\')">'+label+'</button>'+
     '<button class="drop" onclick="uiForgetWorld(\''+w.code+'\')">Forget</button>'+
     '</div>';
  return h;
}

// ---- Join ------------------------------------------------------------------------------------
function paintLobbyJoin(){
  const el=document.getElementById('lbBody');
  if(!el)return;
  const saved=(()=>{try{return JSON.parse(localStorage.getItem('aocNet')||'null');}catch(e){return null;}})();
  const pre=netPendingCode||'';
  netPendingCode='';
  el.innerHTML=
    '<div class="lbField"><label>World code</label>'+
    '<input id="lbJoinCode" placeholder="XXXXXX" maxlength="10" value="'+pre+'"></div>'+
    '<div class="lbField"><label>Your name</label>'+
    '<input id="lbJoinName" placeholder="Player" value="'+((saved&&saved.name)||'')+'"></div>'+
    '<button class="primary lbGo" onclick="uiJoinWorld()">Look it up</button>'+
    '<div class="wcNote">A code is six characters and is meant to be read out loud, so it never '+
    'uses a vowel, a zero or a one. You will see what you are joining before you take a crown.</div>';
}

// ---- New -------------------------------------------------------------------------------------
function paintLobbyNew(){
  const el=document.getElementById('lbBody');
  if(!el)return;
  const saved=(()=>{try{return JSON.parse(localStorage.getItem('aocNet')||'null');}catch(e){return null;}})();
  const crowns=Object.keys(EMPIRES).length;
  // The reference states the rules of a world on the card, before you commit to it. These are
  // ours: how many crowns, what it takes to win, and how fast time runs.
  el.innerHTML=
    '<div class="wcard">'+
    '<div class="wcTop"><span class="wcCode">NEW</span><span class="wcState wait">not made yet</span></div>'+
    '<div class="wcFacts">'+
    '<div><div class="k">Crowns</div><div class="v big">'+crowns+'</div></div>'+
    '<div><div class="k">To win</div><div class="v big">'+winLineFor(crowns)+' of '+Object.keys(MAPD5.provs).length+'</div></div>'+
    '<div><div class="k">You play</div><div class="v">'+(selEmpire?EMPIRES[selEmpire].name:'not chosen')+'</div></div>'+
    '<div><div class="k">Free lords</div><div class="v">hold the rest</div></div>'+
    '</div>'+
    '<div class="wcNote">Every crown is on the map. Whoever you invite picks any of the other '+
    (crowns-1)+', and every crown nobody takes is played by the game.</div></div>'+
    '<div class="lbField"><label>Your name</label>'+
    '<input id="lbNewName" placeholder="Player" value="'+((saved&&saved.name)||'')+'"></div>'+
    '<div class="lbField"><label>Speed of the world</label>'+
    '<div class="lbRates" id="lbRates"></div></div>'+
    // v9.8: and how long a war. Exactly the same control as the one on the start screen, because
    // the bar has always been stored per WORLD, which is what makes it the host's to set.
    '<div class="lbField"><label>How long a war</label>'+
    '<div class="lbRates" id="lbLens">'+
      WINLEN_KEYS.map(k=>'<button class="'+(selLen===k?'on':'')+'" onclick="uiSetLen(\''+k+'\')">'+
        WINLEN[k].name+' <span style="opacity:.6">'+WINLEN[k].need+'</span></button>').join('')+
    '</div>'+
    '<div class="wcNote">'+winLenOf(selLen).desc+'. Everyone in the world plays to this bar.</div></div>'+
    (selEmpire
      ? '<button class="lbGo make" onclick="uiCreateWorld()">Make the world</button>'+
        '<div class="wcNote">It waits in the lobby until somebody begins it, so a friend who joins an '+
        'hour late is not born an hour behind.</div>'
      // Before v9.1 this was a modal over the start screen, so "choose your empire on the screen
      // behind this one" was advice you could act on. A full screen hides it, and a toast pointing
      // at something invisible is worse than no toast. Send them there instead.
      : '<button class="lbGo make" onclick="closeLobby()">Choose your crown first &#10095;</button>'+
        '<div class="wcNote">A world needs to know which crown is yours before it can be made. '+
        'Pick one on the first screen and come back.</div>');
  paintNetRates();
}

function askForServer(){
  showModal('Online play is not set up yet',
    '<div class="meta">This copy of the game does not know where its world server lives, so it cannot '+
    'create or join a shared world.</div>'+
    '<div class="steprow" style="margin-top:8px"><input id="srvIn" style="width:100%;padding:8px" '+
    'placeholder="https://age-of-crowns.<your-name>.workers.dev"></div>',
    [['Save address',()=>{
      const v=(document.getElementById('srvIn').value||'').trim().replace(/\/+$/,'');
      if(!/^https?:\/\//.test(v)){toast('That does not look like a web address.');return;}
      localStorage.setItem('aocServer',v);closeModal();toast('Server address saved.');showOnline();
    },'primary'],['Close',closeModal,'']]);
}

function uiForgetWorld(code){
  showModal('Forget world '+code+'?',
    '<div class="meta">The only proof that crown is yours lives on this device. Forget it and you cannot '+
    'get it back, even with the code: you would be joining as somebody new and taking a free crown.</div>',
    [['Forget it',()=>{netForget(code);closeModal();lobbyTab('mine');},'primary'],['Keep it',closeModal,'']]);
}

function uiRejoin(code){
  const w=netWorlds().find(x=>x.code===code);
  if(!w){toast('That world is not on this device any more.');return;}
  netJoin(code,w.name||'Player',w.empire,w.token)
    .then(d=>{closeModal();closeLobby();afterJoined(d);})
    .catch(e=>toast(e.message));
}

// Set by the invite-link hook in boot.js, cleared as soon as it has been used.
let netPendingCode='';


let netNewRate=1;
function paintNetRates(){
  const el=document.getElementById('lbRates')||document.getElementById('netRates');
  if(!el)return;
  el.innerHTML=[[1,'Real time'],[60,'1 min = 1 hr'],[600,'1 sec = 10 min'],[3600,'1 sec = 1 hr']]
    .map(([r,n])=>'<button class="'+(netNewRate===r?'on':'')+'" onclick="netNewRate='+r+';paintNetRates()">'+n+'</button>')
    .join('');
}

// v9.8: the host's war length, on the online screen. It repaints the whole new-world panel
// rather than just the buttons, because the note under them quotes the choice.
function uiSetLen(k){
  if(!WINLEN[k])return;
  selLen=k;
  if(typeof refreshStart==='function')refreshStart();   // keep the offline screen in step
  const el=document.getElementById('lbLens');
  if(el){
    el.innerHTML=WINLEN_KEYS.map(x=>'<button class="'+(selLen===x?'on':'')+'" onclick="uiSetLen(\''+x+'\')">'+
      WINLEN[x].name+' <span style="opacity:.6">'+WINLEN[x].need+'</span></button>').join('');
    const note=el.parentElement&&el.parentElement.querySelector('.wcNote');
    if(note)note.textContent=winLenOf(selLen).desc+'. Everyone in the world plays to this bar.';
  }
}

function uiCreateWorld(){
  // v8.6: rivals are no longer part of an online world, so they are no longer a reason to refuse.
  // All eight crowns are on the map; the host only has to have said which one is theirs.
  if(!selEmpire){toast('Choose your empire on the screen behind this one first.');return;}
  const name=(document.getElementById('lbNewName')||{}).value||'Player';
  const btns=document.querySelectorAll('#mBtns button');
  btns.forEach(b=>b.disabled=true);
  netCreate(selEmpire,selDiff,name,netNewRate,selLen)
    .then(d=>{closeModal();closeLobby();afterJoined(d);})
    .catch(e=>{btns.forEach(b=>b.disabled=false);toast(e.message);});
}

// v8.6 — JOINING IS TWO STEPS NOW, AND THE SECOND ONE IS THE POINT.
//
// This used to call netJoin with no empire at all, and the server handed out `free[0]`: whatever
// crown happened to be first in the list. Combined with a world that only held the crowns the host
// had picked, a second player was given one of two empires somebody else chose, with no say in it.
// Nabeel reported exactly that.
//
// So: look the world up first (a plain GET, no seat taken), show what is still free, and let them
// choose. Nobody is committed to anything until they tap a crown.
let netJoinCode='', netJoinName='', netPickEmpire='';

function uiJoinWorld(){
  const code=netCodeInput((document.getElementById('lbJoinCode')||{}).value);
  const name=(document.getElementById('lbJoinName')||{}).value||'Player';
  if(code.length<4){toast('Type the world code first.');return;}
  netJoinCode=code; netJoinName=name; netPickEmpire='';
  // A world this device already holds a crown in goes straight back to that crown. Picking again
  // would mean abandoning the empire you have been playing, which is never what Join means.
  const held=netWorlds().find(w=>w.code===code);
  if(held){ uiRejoin(code); return; }
  toast('Looking up world '+code+'...');
  netPeek(code)
    .then(st=>{
      if(!st.free||!st.free.length){toast('Every crown in world '+code+' is taken.');return;}
      netPickEmpire=st.free[0].k;
      showCrownPicker(st);
    })
    .catch(e=>toast(e.message));
}

function showCrownPicker(st){
  const started=!!st.started;
  let h='<div class="meta">World <b>'+netJoinCode+'</b> holds <b>'+(st.standings?st.standings.length:8)+
        ' crowns</b>. '+(started?'It has already begun, so you will arrive in a war that is under way.'
                                :'It has not begun yet, so nobody is ahead of anybody.')+'</div>';
  if(st.players&&st.players.length){
    h+='<div class="bsec">Already taken</div><div class="meta">'+
       st.players.map(p=>empName(p.empire)+' <span style="opacity:0.7">('+p.name+')</span>').join(', ')+'</div>';
  }
  h+='<div class="bsec">Choose your crown</div>'+
     '<div class="meta">Every crown nobody takes is played by the game.</div>'+
     '<div id="crownPick" class="crowns"></div>';
  showModal('Join world '+netJoinCode,h,
    [['Take this crown',uiTakeCrown,'primary'],['Back',()=>{closeModal();showOnline();},'']]);
  paintCrownPick(st.free);
}

function paintCrownPick(free){
  const el=document.getElementById('crownPick');
  if(!el)return;
  el.innerHTML=free.map(f=>{
    const E=EMPIRES[f.k]||{};
    return '<div class="crownopt'+(netPickEmpire===f.k?' sel':'')+'" data-k="'+f.k+'" '+
      'onclick="netPickEmpire=\''+f.k+'\';paintCrownPick('+JSON.stringify(free).replace(/"/g,'&quot;')+')">'+
      '<span class="crownSwatch" style="background:'+(E.color||'#888')+'"></span>'+
      '<span class="crownName">'+(E.name||f.name)+'</span>'+
      '<span class="crownWhere">'+(E.region||'')+'</span></div>';
  }).join('');
}

function uiTakeCrown(){
  if(!netPickEmpire){toast('Choose a crown first.');return;}
  const btns=document.querySelectorAll('#mBtns button');
  btns.forEach(b=>b.disabled=true);
  netJoin(netJoinCode,netJoinName,netPickEmpire)
    .then(d=>{
      closeModal();
      // The server has the last word on which crown you got: somebody may have taken it while the
      // picker was open. Say so rather than letting the map quietly disagree with the choice.
      if(d.empire!==netPickEmpire)toast(empName(netPickEmpire)+' had just been taken, so you hold '+empName(d.empire)+'.');
      afterJoined(d);
    })
    .catch(e=>{btns.forEach(b=>b.disabled=false);toast(e.message);});
}

// One door for creating, joining and coming back. A world that has already begun drops you
// straight onto the map. One that has not puts you in the lobby with everybody else.
function afterJoined(d){
  if(NET.started){ NET.inLobby=false; enterOnlineGame(); toast('You hold '+empName(NET.empire)+' in world '+NET.code+'.'); }
  else { NET.inLobby=true; showLobby(); }
}


// ==================== the lobby (v8.0) ====================
// Before this, a world started running the moment it was made. Whoever joined twenty minutes later
// arrived twenty minutes behind, in a war that had already started without them, which is a poor
// way to begin a game you meant to play together. Now the clock does not move until somebody
// presses Begin, and this is the room everyone waits in.

function showLobby(){
  showModal('World '+NET.code,'<div id="lobbyBody"></div>',[['Close',()=>{closeModal();},'']]);
  paintLobby();
}

function paintLobby(){
  const el=document.getElementById('lobbyBody');
  if(!el)return;
  const iAmHost=NET.host===NET.empire;
  const canBegin=iAmHost||NET.canAnyoneBegin;
  const link=netInviteFor(NET.code);

  let h='<div class="meta">Nobody has begun this world yet, so its clock is standing still. Nothing happens '+
        'until somebody starts it, which means a friend who joins late is not born behind.</div>';

  h+='<div class="bsec">Invite somebody</div>'+
     '<div class="steprow"><input id="inviteLink" readonly value="'+link+'" '+
     'style="width:100%;padding:10px;font-size:12px" onclick="this.select()"></div>'+
     '<div class="steprow"><button class="primary" onclick="uiCopyInvite()">Copy the link</button>'+
     '<span class="lobCode">or read out <b>'+NET.code+'</b></span></div>';

  h+='<div class="bsec">In this world</div>';
  h+=NET.players.map(p=>'<div class="lobrow"><span class="lobWho">'+
       (p.empire===NET.empire?'You':p.name)+'</span><span class="lobEmp">'+empName(p.empire)+
       (p.empire===NET.host?' <span class="lobHost">host</span>':'')+'</span></div>').join('');

  if(NET.free.length){
    h+='<div class="bsec">Still free</div><div class="meta">'+
       NET.free.map(f=>f.name).join(', ')+'</div>'+
       '<div class="meta">Every crown nobody takes is played by the game, so you can begin whenever you like.</div>';
  }else{
    h+='<div class="meta">Every crown is taken.</div>';
  }

  h+='<div class="bsec">Ready</div>';
  if(canBegin){
    h+='<div class="steprow"><button class="primary" onclick="uiBeginWorld()" id="beginBtn">Begin the war</button></div>';
    if(!iAmHost)h+='<div class="meta">This world has been waiting long enough that anyone in it may start it.</div>';
  }else{
    const host=NET.players.find(p=>p.empire===NET.host);
    h+='<div class="meta">Waiting for <b>'+(host?host.name:'the host')+'</b> to begin. This screen updates on '+
       'its own, so leave it open.</div>';
  }
  h+='<div class="meta">You can close this and come back to it from <b>Play online</b>. Your crown is held for you.</div>';
  el.innerHTML=h;
}

function uiCopyInvite(){
  const inp=document.getElementById('inviteLink');
  const txt=inp?inp.value:netInviteFor(NET.code);
  const done=()=>toast('Link copied. Send it to whoever you want in this world.');
  // clipboard.writeText is not there on an insecure origin or an old phone browser, and a failure
  // here should not look like the button is broken.
  if(navigator.clipboard&&navigator.clipboard.writeText){
    navigator.clipboard.writeText(txt).then(done).catch(()=>{if(inp)inp.select();toast('Press and hold the link to copy it.');});
  }else{
    if(inp){inp.select();try{document.execCommand('copy');done();return;}catch(e){}}
    toast('Press and hold the link to copy it.');
  }
}

function uiBeginWorld(){
  const b=document.getElementById('beginBtn');
  if(b)b.disabled=true;
  netBegin()
    .then(()=>{ if(NET.started){NET.inLobby=false;closeModal();enterOnlineGame();toast('The war has begun.');} })
    .catch(e=>{ if(b)b.disabled=false; toast(e.message); });
}

// Swap from the start screen to the map, the same way the offline start button does, minus
// anything that would start a clock of our own.
function enterOnlineGame(){
  NET.ready=true;
  buildCadj();                                   // the province graph movement walks
  document.getElementById('start').style.display='none';
  document.getElementById('game').style.display='flex';
  initMap();
  initInput();
  if(window.innerWidth<761){
    document.getElementById('mapwrap').classList.remove('tilted');
    setRailLbl('tiltBtn','Tilt: off');
  }
  renderAll();
  startClock();                                  // for the header and the speed button only
  const cap=provOf(EMPIRES[G.player].cap);
  VB.w=MAPD5.W/3;VB.h=MAPD5.H/3;
  VB.x=cap.cx-VB.w/2;VB.y=cap.cy-VB.h/2;
  applyVB();fitAspect();
  const el=document.getElementById('log');
  if(el)el.innerHTML=G.log.map(l=>'<div class="l '+l.cls+'">'+l.msg+'</div>').join('');
  paintNetBar();
}

// A line across the top saying which world this is and who else is in it, because in a shared
// world the first question is always "is anyone else actually here".
function paintNetBar(){
  let el=document.getElementById('netbar');
  if(!NET.on){ if(el)el.remove(); return; }
  if(!el){
    el=document.createElement('div');
    el.id='netbar';
    document.getElementById('mapwrap').appendChild(el);
  }
  const others=NET.players.filter(p=>p.empire!==NET.empire);
  el.innerHTML='<span class="nbCode">'+NET.code+'</span>'+
    '<span class="nbWho">You are '+empName(NET.empire)+'</span>'+
    '<span class="nbWho">'+(others.length
      ? others.map(p=>p.name+' as '+empName(p.empire)).join(', ')
      : 'nobody else has joined yet')+'</span>'+
    (NET.err?'<span class="nbErr">'+NET.err+'</span>':'')+
    '<button onclick="uiLeaveWorld()">Leave</button>';
}

function uiLeaveWorld(){
  showModal('Leave this world?',
    '<div class="meta">The world keeps running without you and your crown stays yours. You can come back '+
    'with the code <b>'+NET.code+'</b> at any time.</div>',
    [['Leave',()=>{closeModal();netLeave();paintNetBar();location.reload();},'primary'],
     ['Stay',closeModal,'']]);
}


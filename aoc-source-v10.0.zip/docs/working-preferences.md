# How Nabeel wants to be answered

Read this before replying in any session in this project. These are his rules, in his words where possible, plus what I have learned from getting them wrong.

> **This file is the master copy** of the project doc `claude/nabeel-working-preferences.md`. Edit
> THIS file, then push it with `Projects.project_write(local_path=...)`. If it is missing from disk
> at the start of a session, `project_read` it back onto disk BEFORE editing it.

## Format

1. **Ask clarifying questions before starting real work.** Multi-step tasks, file creation, anything with several tool calls. Not for quick factual questions or plain conversation. If the session is unattended (a scheduled run, or he has said he is stepping away), make the reasonable call, state the assumption at the top, and carry on rather than blocking.
2. **Never use a dash between statements.** No em dashes, no en dashes joining clauses, no hyphen used as a pause. Rewrite the sentence or use a full stop. This is the single easiest way to sound like a machine to him.
3. **Every response opens with a TLDR, and the TLDR is bullet points, not paragraphs.** Added 5 Sep 2026: he asked for this specifically because a paragraph TLDR is not a TLDR. Short bullets, one idea each, scannable in three seconds on a phone.
4. **Simple, plain sentences.** Short words. Say the thing, then explain it if needed.
5. **He reads on a phone.** Keep responses tight. Long walls of text are worse than useless on a small screen.

## Where the record lives

6. **FOR AGE OF CROWNS: Notion, and NOT Google Drive.** Decided by him on 20 Nov 2026, in his words:
   *"I will not be uploading anything to Drive because I want everything to be saved in Notion."*
   **This overrides the global Drive default for this project.** Do not save game files, screenshots,
   docs or anything else to Drive here, and do not offer to. If another project comes along, the
   global default below applies again until he says otherwise.
   - His global default, still standing elsewhere: https://drive.google.com/drive/folders/1Q5a1yClXNY0wsvaf6LxcfVwZZRYPVaYb
7. **The agreed workflow for a play test, settled 20 Nov 2026:**
   - He writes notes **in the Notion QA page**, because an unsent chat message is saved nowhere and
     Notion saves every keystroke and syncs phone to laptop.
   - He uploads screenshots **to Notion** for the record.
   - When he is ready for me to work on it, he **pastes the same screenshots into the chat**, where I
     can actually see them, and I map them to his written comments.
   - **So: do not ask him to re-upload anywhere. Just ask him to paste them here when we start.**
8. **Filenames carry the version.** He wants to know which build he is looking at without opening it.
9. **If something is waiting on his approval, notify him** so he can review and approve straight away rather than the work sitting idle.

## Building

10. **Mobile first, always.** Not "mobile too". He has said it more than once. Design for the phone, then let the desktop have the extra room.
11. **Every build ships with three things in the same message:** the file, the GitHub upload link, and the play link.
12. **Every build updates Notion and the project doc.** Not just the big ones. I let Notion drift four builds behind once by treating it as optional, and he caught it. It is not optional.

## Images, and why this keeps coming up

**Only a screenshot pasted into the chat can actually be seen.** Everything else is a dead end, and all of it was tested on 20 Nov 2026:

- **Notion attachments cannot be read, permanently.** Not a permission problem. Notion hands out a valid signed link, and the fetch proxy then refuses it with `403 PROXY_REJECTED: url exceeds the maximum fetchable length`, because an AWS signed link carries a ~1,500 character security token. Every Notion image is over the limit. **Do not retry it and do not reach for curl.**
- **Google Drive would have worked** (`read_file_content` OCRs an image for a few hundred tokens) **and he declined it.** Recorded so nobody re-pitches it: he wants one record, in Notion.
- **Never use `download_file_content` on an image.** A 113KB screenshot is ~38k tokens of base64 and still is not vision.
- The **device bridge** (his Windows laptop `nabeel-work`) could stage images for real viewing, but it needs his desktop open and he plays on a phone. Offered 20 Nov, not taken up.

## Things I got wrong, kept here so they are not repeated

- Narrowed "update memory" to mean only the project doc, and stopped writing Notion pages for bug-fix builds. He had said "update notion files or create new when needed" long before that.
- Wrote a TLDR as a paragraph. A TLDR that needs reading twice is not doing its job.
- Shipped a file named `aoc-v6.4.html` when the live file was `aoc-v6.html`, so his upload looked successful and changed nothing. Deliver the exact filename that replaces the live one, or say plainly which one it replaces.
- **Told him Notion images were blocked by a host allowlist.** They are blocked by a URL length limit. I carried the wrong reason in my notes for two months and only found the real one when he asked me to fix it properly. **When he says "something changed, find out why", go and test it rather than repeating what the notes say.**
- **Uploaded a test file to his Drive without asking**, on the day he decided he did not want Drive used. It was trashed. Ask before putting anything in his storage.

// ONE LINK, ONE INSTALL, FOREVER.
//
// Nabeel: "is it not possible to rewrite on one link so that I don't always have to delete the
// installed link on my mobile and create a copy all over again... so that I can always use one
// link and one install all the time."
//
// He was right that it was possible and right that it was silly. Every build shipped as
// aoc-v10.3.html, so the ADDRESS carried the version, and an installed web app is pinned to the
// exact URL it was installed from. A new build was therefore always a new app.
//
// THIS TEST MUST BE SERVED OVER HTTP FROM A FOLDER, NOT OPENED AS A FILE. The whole question is
// what `location.href` and `location.pathname` are when the game is reached at a bare folder URL
// with no filename in it, because the manifest's start_url and every multiplayer invite link are
// built out of them. file:// cannot ask that question.
const {chromium}=require('playwright');
const http=require('http'), fs=require('fs'), path=require('path');

const DIST=path.join(__dirname,'..','dist');
const BASE='/age-of-crowns/';
const MISSES=[];                 // the same shape as the real Pages URL

(async()=>{
  // a GitHub-Pages-shaped server: a bare folder URL serves index.html out of it
  const srv=http.createServer((req,res)=>{
    let u=req.url.split('?')[0].split('#')[0];
    if(u===BASE.slice(0,-1)){res.writeHead(301,{Location:BASE});return res.end();} // Pages adds the slash
    if(!u.startsWith(BASE)){MISSES.push(u);res.writeHead(404);return res.end('no');}
    let rel=u.slice(BASE.length);
    if(rel===''||rel==='/')rel='index.html';          // a bare folder URL IS index.html
    const f=path.join(DIST,rel);
    if(!fs.existsSync(f)||fs.statSync(f).isDirectory()){
      MISSES.push(u); res.writeHead(404); return res.end('no');
    }
    res.writeHead(200,{'Content-Type':rel.endsWith('.html')?'text/html':'application/octet-stream',
                       'Cache-Control':'max-age=600'});                   // what Pages actually sends
    res.end(fs.readFileSync(f));
  });
  await new Promise(r=>srv.listen(0,r));
  const PORT=srv.address().port;
  const ORIGIN='http://localhost:'+PORT;
  const URL_FOLDER=ORIGIN+BASE;                 // the ONE link, no filename anywhere in it

  const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
  const ok=[];const say=(c,m)=>{ok.push(c);console.log((c?'  PASS  ':'  FAIL  ')+m);};
  const p=await b.newPage({viewport:{width:390,height:844},isMobile:true,hasTouch:true});
  const errs=[];
  p.on('pageerror',e=>errs.push(String(e)));
  p.on('console',m=>{if(m.type()==='error')errs.push('console: '+m.text());});

  console.log('THE LINK HAS NO FILE NAME IN IT');
  console.log('    '+URL_FOLDER);
  const resp=await p.goto(URL_FOLDER);
  await p.waitForTimeout(900);
  say(resp.status()===200,'it serves the game, status '+resp.status());
  say(p.url()===URL_FOLDER,'and the address stays clean: '+p.url());
  const ver=await p.evaluate(()=>typeof GAME_VERSION!=='undefined'?GAME_VERSION:null);
  say(!!ver,'the game is really there, version '+ver);
  say(!/aoc-v/.test(p.url()),'no version anywhere in the address, which is the entire point');

  console.log('');
  console.log('WHAT AN INSTALL WOULD PIN ITSELF TO');
  const man=await p.evaluate(async()=>{
    const l=document.querySelector('link[rel="manifest"]');
    if(!l)return {none:true};
    const txt=l.href.startsWith('data:')
      ? decodeURIComponent(l.href.slice(l.href.indexOf(',')+1))
      : await (await fetch(l.href)).text();
    const m=JSON.parse(txt);
    return {start:m.start_url,scope:m.scope,id:m.id,name:m.name,icons:(m.icons||[]).length,
            display:m.display};
  });
  console.log('    start_url  '+man.start);
  console.log('    scope      '+man.scope);
  say(!man.none,'there is a manifest');
  say(man.start===URL_FOLDER,'start_url IS the one link, absolute and with no file name');
  say(man.scope===URL_FOLDER,'and so is the scope, so the installed app owns that address');
  say(!/aoc-v/.test(man.start+man.scope+(man.id||'')),
      'nothing in the manifest names a version  <<< THIS is what made every build a new install');
  say(man.icons>=1,man.icons+' icon(s), display '+man.display);

  console.log('');
  console.log('AN INVITE LINK IS NOW PERMANENT TOO');
  const inv=await p.evaluate(()=>{
    let s=20261125;Math.random=function(){s=(s*1664525+1013904223)>>>0;return s/4294967296;};
    return typeof inviteLink==='function'?inviteLink('ABCD12'):(location.origin+location.pathname+'#w=ABCD12');
  });
  console.log('    '+inv);
  say(inv===URL_FOLDER+'#w=ABCD12','it points at the one link, so it does not rot when a build ships');
  say(!/aoc-v/.test(inv),'and carries no version. Every invite ever sent before this pointed at a '+
      'file that would be superseded within a day');

  console.log('');
  console.log('AND YOU CAN TELL WHICH BUILD YOU ARE ON WITHOUT THE ADDRESS');
  const more=await p.evaluate(()=>{
    selEmpire='abb';selDiff='norm';refreshStart();
    const start=document.getElementById('verStamp');
    const out={onStart:start?start.textContent.trim():''};
    document.getElementById('startBtn').onclick();
    return new Promise(r=>setTimeout(()=>{
      G.rate=0;closeDrawer(true);
      showMore();
      const h=document.getElementById('mBody').innerHTML;
      out.inMore=h.indexOf(GAME_VERSION)>=0;
      out.saysBuild=/This build/.test(h);
      out.hint=/After an upload/.test(h);
      out.ver=GAME_VERSION;
      closeModal();
      r(out);
    },1400));
  });
  say(/v\d/.test(more.onStart),'the start screen still stamps it: "'+more.onStart+'"');
  say(more.inMore&&more.saysBuild,'and More now shows it mid-game, reading '+more.ver);
  say(more.hint,'with the line that says to check it after an upload, which is when it matters');
  console.log('    Without this the version had nowhere to be read but the start screen, which is');
  console.log('    the one screen you are not on while playing. The address used to carry it.');

  console.log('');
  console.log('A NEW BUILD UPLOADED OVER THE TOP IS PICKED UP');
  const swap=await p.evaluate(()=>({before:GAME_VERSION}));
  // overwrite index.html exactly as an upload would, then reload as the installed app would
  const real=fs.readFileSync(path.join(DIST,'index.html'),'utf8');
  fs.writeFileSync(path.join(DIST,'index.html'),real.replace(
    "const GAME_VERSION='"+ver+"'","const GAME_VERSION='v99.9-test'"));
  const p2=await b.newPage({viewport:{width:390,height:844},isMobile:true,hasTouch:true});
  await p2.goto(URL_FOLDER,{waitUntil:'load'});
  await p2.waitForTimeout(700);
  const after=await p2.evaluate(()=>GAME_VERSION);
  fs.writeFileSync(path.join(DIST,'index.html'),real);        // put the real build back
  await p2.close();
  console.log('    uploaded over the top: '+swap.before+'  ->  '+after);
  say(after==='v99.9-test','the same unchanged link serves the new build  <<< the whole request');
  const restored=fs.readFileSync(path.join(DIST,'index.html'),'utf8');
  say(restored===real,'and this test put the real build back afterwards');

  // A single 404 for /favicon.ico is the BROWSER asking, not the game: the icon is inside the
  // manifest and there is no separate file, which is the whole point of a one-file game. Anything
  // else 404ing would mean the game had grown a second file and would break the install.
  console.log('');
  console.log('IT IS STILL ONE FILE');
  console.log('    the browser asked for: '+(MISSES.join(', ')||'nothing beyond the page'));
  say(MISSES.length>0,'the miss list is actually being filled ('+MISSES.length+' recorded), so '+
      'the next line is not passing on an empty list, which is how it passed the first time');
  say(MISSES.every(u=>/favicon\.ico$/.test(u)),
      'the only thing missing is favicon.ico, which the BROWSER asks for unprompted. The game '+
      'itself fetches no second file, so uploading one index.html really does ship the whole thing');
  const real404=errs.filter(e=>!/404/.test(e));
  say(real404.length===0,'no page errors'+(real404.length?': '+real404.slice(0,2).join(' | '):''));
  await p.close();
  await b.close();
  srv.close();
  const bad=ok.filter(x=>!x).length;
  console.log('');
  console.log(bad?('  '+bad+' FAILED'):'  ALL GREEN');
  process.exit(bad?1:0);
})();

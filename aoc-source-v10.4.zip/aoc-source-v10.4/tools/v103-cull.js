// ONLY DRAW WHAT IS ON SCREEN — and never lose anything doing it.
//
// His play test: "The game is still sluggish, and zooming in and zooming out takes a bit of time.
// Whereas I play Conflict of Nations on the same device, and it is normally smooth."
//
// Measured: a full repaint cost 19 to 33ms against a 16.7ms frame, because the map redrew the
// whole world every time. At the zoom he plays at, 88% of what it drew was off screen.
//
// THE DANGEROUS PART IS NOT THE SPEED, IT IS CORRECTNESS. `applyVB` had a line that read
// "a pan changes nothing the content depends on" and returned early. That was true until today.
// Pan far enough now and you would slide off the edge of the drawn markup into blank parchment.
// Most of this file is about that.
const {chromium}=require('playwright');

(async()=>{
  const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
  const ok=[];const say=(c,m)=>{ok.push(c);console.log((c?'  PASS  ':'  FAIL  ')+m);};
  const p=await b.newPage({viewport:{width:390,height:844},isMobile:true,hasTouch:true});
  const errs=[];
  p.on('pageerror',e=>errs.push(String(e)));
  p.on('console',m=>{if(m.type()==='error')errs.push('console: '+m.text());});
  await p.goto('file:///home/claude/age-of-crowns/aoc-v6.html');
  await p.waitForTimeout(400);
  await p.evaluate(()=>{let s=20261126;Math.random=function(){s=(s*1664525+1013904223)>>>0;return s/4294967296;};
    selEmpire='abb';selDiff='norm';refreshStart();});
  await p.evaluate(()=>document.getElementById('startBtn').onclick());
  await p.waitForTimeout(1300);
  await p.evaluate(()=>{G.rate=0;closeDrawer(true);advanceClock(24*6);});

  console.log('WHAT A REPAINT COSTS IN A WORLD THAT IS MOVING');
  console.log('    (not an idle repaint: the clock advances a quarter hour, armies move, then it draws)');
  const perf=await p.evaluate(()=>{
    const pv=provOf(provsOf(G.player)[0]);const out=[];
    [1750,900,620,500,280,150].forEach(w=>{
      VB={x:pv.cx-w/2,y:pv.cy-(w/2.2)/2,w,h:w/2.2};lastW=null;applyVB();updateMap();
      let tot=0,worst=0;
      for(let i=0;i<40;i++){
        advanceClock(0.25);
        const t0=performance.now();updateMap();const d=performance.now()-t0;
        tot+=d;if(d>worst)worst=d;
      }
      out.push([w,tot/40,worst]);
    });
    return out;
  });
  const was={1750:null,900:18.9,620:null,500:32.6,280:25.2,150:17.4};
  console.log('    width  average   worst     v10.2');
  perf.forEach(x=>console.log('    '+String(x[0]).padStart(5)+String(x[1].toFixed(1)+'ms').padStart(9)+
    String(x[2].toFixed(1)+'ms').padStart(9)+(was[x[0]]?String(was[x[0]]+'ms').padStart(10):'         -')));
  say(perf.every(x=>x[1]<14),'every zoom band averages under 14ms (worst average '+Math.max(...perf.map(x=>x[1])).toFixed(1)+'ms)');
  console.log('    620 is the peak band on purpose: it is the one zoom where the building pins, the');
  console.log('    garrisons and the land names are all switched on over a still-wide area.');
  const close=perf.find(x=>x[0]===280);
  say(close[1]<8,'and the zoom he actually plays at averages '+close[1].toFixed(1)+'ms, against 25.2 in v10.2');
  console.log('    The spikes are the ticks where something really happened: a city changed hands, a');
  console.log('    garrison crossed a strength band. Those have to be redrawn. The point of the');
  console.log('    cache is that the other thirty-nine ticks no longer pretend they did.');

  console.log('');
  console.log('THE CACHE CANNOT GO STALE, WHICH IS THE NEW RISK THIS BUILD CREATES');
  const cache=await p.evaluate(()=>{
    const out={};
    const pv=provOf(provsOf(G.player)[0]);const w=500;
    VB={x:pv.cx-w/2,y:pv.cy-(w/2.2)/2,w,h:w/2.2};lastW=null;applyVB();updateMap();
    // 1. a repaint with nothing changed must not touch the DOM at all
    const gA=document.getElementById('gArmy');
    const before=gA.innerHTML;
    let writes=0;
    const d=Object.getOwnPropertyDescriptor(Element.prototype,'innerHTML');
    Object.defineProperty(gA,'innerHTML',{configurable:true,
      get(){return d.get.call(this);},set(v){writes++;d.set.call(this,v);}});
    updateMap();updateMap();updateMap();
    out.idleWrites=writes;
    delete gA.innerHTML;
    out.sameMarkup=document.getElementById('gArmy').innerHTML===before;

    // 2. but a REAL change must land. Put a new army on a visible cell.
    const cid=Object.keys(MAPD5.cells).find(c=>{
      const cc=MAPD5.cells[c];
      return cc.x>VB.x+40&&cc.x<VB.x+VB.w-40&&cc.y>VB.y+40&&cc.y<VB.y+VB.h-40&&!G.armies[c];
    });
    G.armies[cid]={e:G.player,u:{knight:7},mv:0};
    updateMap();
    out.newArmyDrawn=!!document.querySelector('#gArmy g[data-a="'+cid+'"]');
    // 3. and a change to one that already exists
    G.armies[cid].u={knight:70};
    updateMap();
    const txt=[...document.querySelectorAll('#gArmy g[data-a="'+cid+'"] text')].map(t=>t.textContent).join(' ');
    out.countUpdated=/70/.test(txt);
    // 4. losing the city must repaint the territory, which is the per-cell signature not the layer
    const pid=Object.keys(MAPD5.provs).find(x=>ownerOf(x)===G.player);
    const anyCell=(provOf(pid).cells||[]).find(c=>MAPD5.cells[c]);
    const fillWas=document.querySelector('#gCell path[data-c="'+anyCell+'"]').getAttribute('fill');
    claimCell(anyCell,'fra',{spear:9});
    updateMap();
    out.cellRepainted=document.querySelector('#gCell path[data-c="'+anyCell+'"]').getAttribute('fill')!==fillWas;
    // 5. AND the big one: initMap wipes the DOM. If the cache survived that, the map goes blank.
    initMap();applyVB();updateMap();
    out.afterRebuild=document.getElementById('gArmy').innerHTML.length;
    out.pinAfterRebuild=document.getElementById('gPin').innerHTML.length;
    return out;
  });
  say(cache.idleWrites===0,'three repaints with nothing changed wrote to the army layer '+cache.idleWrites+' times');
  say(cache.sameMarkup,'and the markup is unchanged, so skipping the write lost nothing');
  say(cache.newArmyDrawn,'a new army appears');
  say(cache.countUpdated,'a stack that changes size is redrawn with the new number');
  say(cache.cellRepainted,'a cell that changes hands is repainted');
  say(cache.afterRebuild>0&&cache.pinAfterRebuild>0,
      'and after initMap wipes the map, every layer comes back ('+cache.afterRebuild+' and '+
      cache.pinAfterRebuild+' characters), rather than the cache leaving it blank');

  console.log('');
  console.log('NOTHING ON SCREEN IS MISSING');
  const vis=await p.evaluate(()=>{
    const out={};
    const pv=provOf(provsOf(G.player)[0]);
    const w=400;
    VB={x:pv.cx-w/2,y:pv.cy-(w/2.2)/2,w,h:w/2.2};lastW=null;applyVB();updateMap();
    // every province whose CITY POINT is inside the view must have its pin in the DOM
    let want=0,got=0,missing=[];
    for(const pid in MAPD5.provs){
      const q=MAPD5.provs[pid];
      if(q.cx<VB.x||q.cx>VB.x+VB.w||q.cy<VB.y||q.cy>VB.y+VB.h)continue;
      want++;
      if(document.querySelector('#gPin g[data-p="'+pid+'"]'))got++; else missing.push(q.city);
    }
    out.wantPins=want;out.gotPins=got;out.missingPins=missing;
    // and every army of ours standing inside the view must be drawn
    let aw=0,ag=0;
    armiesOf(G.player).forEach(cid=>{
      const c=MAPD5.cells[cid];if(!c)return;
      if(c.x<VB.x||c.x>VB.x+VB.w||c.y<VB.y||c.y>VB.y+VB.h)return;
      aw++;
      if(document.querySelector('#gArmy g[data-a="'+cid+'"]'))ag++;
    });
    out.wantArmies=aw;out.gotArmies=ag;
    return out;
  });
  console.log('    '+vis.wantPins+' cities in view, '+vis.gotPins+' drawn');
  say(vis.gotPins===vis.wantPins,'every city in view is drawn'+(vis.missingPins.length?'  MISSING: '+vis.missingPins.join(', '):''));
  say(vis.wantArmies===0||vis.gotArmies===vis.wantArmies,'and every army of yours in view is drawn ('+vis.gotArmies+'/'+vis.wantArmies+')');

  console.log('');
  console.log('PANNING DOES NOT LEAVE YOU LOOKING AT BLANK PARCHMENT');
  const pan=await p.evaluate(()=>{
    const out={steps:[]};
    const w=400;
    // Drag across the thickest part of the map rather than out into the Atlantic, or the test
    // passes by having nothing to draw. Start on the leftmost of your own cities and head east.
    const all=Object.keys(MAPD5.provs).map(x=>provOf(x)).sort((a,b)=>a.cx-b.cx);
    const start=all[0];                      // the westernmost city, then walk east across the lot
    VB={x:start.cx-w/2,y:start.cy-(w/2.2)/2,w,h:w/2.2};lastW=null;applyVB();updateMap();
    // drag a long way across the map in small steps, exactly as a finger would
    let worst=1, seen=0, rebuilds=0;
    const real=window.updateMap;
    window.updateMap=function(){rebuilds++;return real.apply(this,arguments);};
    for(let i=0;i<40;i++){
      VB.x+=w*0.12; VB.y+=w*0.015;
      applyVB();                                   // the ONLY thing a pan calls
      let want=0,got=0;
      for(const pid in MAPD5.provs){
        const q=MAPD5.provs[pid];
        if(q.cx<VB.x||q.cx>VB.x+VB.w||q.cy<VB.y||q.cy>VB.y+VB.h)continue;
        want++;
        if(document.querySelector('#gPin g[data-p="'+pid+'"]'))got++;
      }
      if(want){const r=got/want;if(r<worst)worst=r;}
      seen+=want;
      if(i%10===0)out.steps.push('step '+i+': '+got+' of '+want+' cities in view are drawn');
    }
    window.updateMap=real;
    out.worst=worst;out.seen=seen;out.rebuilds=rebuilds;
    return out;
  });
  pan.steps.forEach(x=>console.log('    '+x));
  say(pan.worst>=0.999,'across a 40-step drag, every city in view was always drawn (worst '+(pan.worst*100).toFixed(0)+'%)');
  say(pan.seen>=40,'the drag passed '+pan.seen+' city sightings, so that pass is not vacuous');
  say(pan.rebuilds>=8,'and it forced '+pan.rebuilds+' rebuilds along the way, which is the dangerous '+
      'path: before v10.3 a pan rebuilt NOTHING, because the old early return said a pan "changes '+
      'nothing the content depends on". Culling made that false.');

  console.log('');
  console.log('AND A PINCH IS STILL CHEAP');
  const pinch=await p.evaluate(()=>{
    const pv=provOf(provsOf(G.player)[0]);
    VB={x:pv.cx-300,y:pv.cy-136,w:600,h:273};lastW=null;applyVB();
    let builds=0;const real=window.updateMap;
    window.updateMap=function(){builds++;return real.apply(this,arguments);};
    const t0=performance.now();
    for(let i=0;i<60;i++){const k=1-i*0.012;VB.w=600*k;VB.h=273*k;applyVB();}   // 600 down to 170
    const ms=performance.now()-t0;
    window.updateMap=real;
    return {builds,ms};
  });
  console.log('    60 frames of a pinch: '+pinch.builds+' full rebuilds, '+pinch.ms.toFixed(1)+'ms total');
  say(pinch.builds>=2&&pinch.builds<=14,'a pinch all the way in rebuilds '+pinch.builds+' times in 60 frames, '+
      'not 60: the drift threshold and the padded box absorb the rest');
  say(pinch.ms/60<6,'so a pinch frame averages '+(pinch.ms/60).toFixed(1)+'ms, which is what "zooming '+
      'takes a bit of time" was');

  await p.screenshot({path:'/home/claude/age-of-crowns/docs/shots/v103-map.png'});
  say(errs.length===0,'no page errors'+(errs.length?': '+errs.slice(0,2).join(' | '):''));
  await p.close();
  await b.close();
  const bad=ok.filter(x=>!x).length;
  console.log('');
  console.log(bad?('  '+bad+' FAILED'):'  ALL GREEN');
  process.exit(bad?1:0);
})();

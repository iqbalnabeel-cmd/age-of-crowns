// EVERY v9.2 CHANGE, CHECKED IN A REAL BROWSER ON A PHONE VIEWPORT.
//
// One run per item on Nabeel's v9.1 play-test page, so each line here traces back to something
// he wrote down.
const {chromium}=require('playwright');

(async()=>{
  const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
  const p=await b.newPage({viewport:{width:390,height:844},isMobile:true,hasTouch:true});
  const errs=[];
  p.on('pageerror',e=>errs.push(String(e)));
  p.on('console',m=>{if(m.type()==='error')errs.push('console: '+m.text());});
  await p.goto('file:///home/claude/age-of-crowns/aoc-v6.html');
  await p.waitForTimeout(500);
  await p.evaluate(()=>{let s=20261120;Math.random=function(){s=(s*1664525+1013904223)>>>0;return s/4294967296;};
    selEmpire='abb';selRivals.clear();['byz','fra','mon'].forEach(k=>selRivals.add(k));selDiff='norm';refreshStart();});
  await p.evaluate(()=>document.getElementById('startBtn').onclick());
  await p.waitForTimeout(1500);
  await p.waitForTimeout(2500);                       // let the idle install setup run

  const r=await p.evaluate(()=>{
    const out={};
    G.rate=0; closeDrawer(true);

    // --- BUG 1: the cities list said "1.0004166666666667t" ----------------------------------
    const pid=Object.keys(MAPD5.provs).find(x=>ownerOf(x)===G.player&&isHomeCity(x,G.player));
    // v9.4: a home city already HAS a Barracks L1, so this asks for L2, which costs 20 timber
    // against a starting 10. startBuild rightly refused, no queue existed, and the check for
    // "does the timer read in hours" had nothing to read. Hand over the materials: this test is
    // about a LABEL, not about whether the economy binds.
    RESK.forEach(r=>{G.emp[G.player].res[r]=999;});
    startBuild(pid,'barracks',G.player);
    advanceClock(0.25);                               // put the queue on a ragged fraction of a day
    showCityList();
    // showCityList opens a modal, not the drawer. Read the modal's markup, not #panel.
    const mb=document.querySelector('#modal, .modal, #modalBody') ||
             [...document.querySelectorAll('div')].find(d=>/cities .*homeland cities can build/.test(d.innerHTML||''));
    out.cityRow=mb?(mb.innerHTML||''):'';
    out.rawFloat=/\d\.\d{6,}/.test(out.cityRow);
    closeDrawer(true);

    // --- PACE: units in hours, buildings in hours, a cell in 1.5h ---------------------------
    out.trainT1=trainHours(UKEYS.find(t=>UNITS[t].tier===1));
    out.trainT2=trainHours(UKEYS.find(t=>UNITS[t].tier===2));
    out.trainT3=trainHours(UKEYS.find(t=>UNITS[t].tier===3));
    out.bldL1=bldHours('barracks',0); out.bldWall3=bldHours('walls',2);
    out.road=ROAD_HOURS; out.march=MARCH_HOURS;
    // how long does a foot army take to cross the whole world now?
    const cells=Object.keys(MAPD5.cells).filter(c=>!MAPD5.cells[c].city);
    out.worldDays=+( (29*MARCH_HOURS)/24 ).toFixed(2);

    // --- FEEL 4: no pause after a fight, no penalty for having marched ----------------------
    out.cooldown=ACT_COOLDOWN;
    for(const c in G.armies)if(G.armies[c].e===G.player)delete G.armies[c];
    placeArmy(cells[40],G.player,{spear:6,sword:2},0,1);     // w=1: "arrived on the march"
    const a=G.armies[cells[40]];
    out.readyAfterMarch=isReady(a);
    coolDown(a);                                              // simulate having just fought
    out.readyAfterFighting=isReady(a);
    out.wFlagStillThere=!!a.w;                                // the flag rides along, it just costs nothing

    // --- FEEL 3: nothing standing in the open country ---------------------------------------
    let freeField=0, freeCityGar=0;
    for(const cid in G.armies){
      const x=G.armies[cid]; if(x.e!=='neutral')continue;
      if(MAPD5.cells[cid]&&MAPD5.cells[cid].city)freeCityGar+=cnt(x.u); else freeField++;
    }
    out.freeFieldArmies=freeField; out.freeCityTroops=freeCityGar;
    out.freeCities=Object.keys(MAPD5.provs).filter(p=>ownerOf(p)==='neutral').length;

    // --- BUG 2: one total per stack when zoomed out -----------------------------------------
    const cc=MAPD5.cells[cells[40]];
    const look=w=>{VB={x:cc.x-w/2,y:cc.y-(w/2.2)/2,w,h:w/2.2};lastW=null;applyVB();updateMap();};
    look(500);        // the width his screenshot was taken at: past CHIPTH, inside GAR_SHOW
    const g=()=>document.querySelector('#gArmy g[data-a="'+cells[40]+'"]');
    out.badgesZoomedOut=g()?g().querySelectorAll('rect').length:-1;
    out.totalZoomedOut=g()&&g().querySelector('text')?g().querySelector('text').textContent:null;
    look(200);
    out.badgesZoomedIn=g()?g().querySelectorAll('rect').length:-1;

    // --- ART: shaded close in, flat far out -------------------------------------------------
    look(400);  out.artCloseHasGradient=/url\(#aocLit\)/.test(document.getElementById('gArmy').innerHTML);
    look(1600); out.artFarHasGradient=/url\(#aocLit\)/.test(document.getElementById('gArmy').innerHTML);
    out.defsInPage=!!document.getElementById('aocLit');
    out.panelArtShaded=/url\(#aocLit\)/.test(artSvg('sword',34,'#c9a227'));

    // --- INSTALL ------------------------------------------------------------------------------
    const ml=document.querySelector('link[rel="manifest"]');
    out.hasManifest=!!ml;
    if(ml){
      try{
        const j=JSON.parse(decodeURIComponent(ml.href.replace(/^data:application\/manifest\+json;charset=utf-8,/,'')));
        out.manName=j.name; out.manDisplay=j.display;
        out.manStartAbs=/^https?:|^file:/.test(j.start_url);
        out.manIcons=j.icons.length;
        out.manIconIsPng=j.icons.every(i=>i.src.startsWith('data:image/png;base64,'));
      }catch(e){out.manParse=String(e);}
    }
    out.appleIcon=!!document.querySelector('link[rel="apple-touch-icon"]');
    out.appleCapable=!!document.querySelector('meta[name="apple-mobile-web-app-capable"]');
    return out;
  });

  const ok=[];
  const say=(c,m)=>{ok.push(c);console.log((c?'  PASS  ':'  FAIL  ')+m);};

  console.log('BUG 1 — the build queue read "1.0004166666666667t"');
  say(!r.rawFloat,'no raw float anywhere in the cities list');
  say(/\d+(\.\d)?\s*(hrs?|days?|min)/.test(r.cityRow),'it reads in hours or days like everything else'
    +(/\d+(\.\d)?\s*(hrs?|days?|min)/.test(r.cityRow)?'':'  <<< row was: '+JSON.stringify(r.cityRow.slice(0,200))));
  console.log('');
  console.log('PACE — "building time should be reduced", "movement speed is too slow"');
  console.log('  a unit by tier  '+r.trainT1+'h / '+r.trainT2+'h / '+r.trainT3+'h  (was 24 / 48 / 72)');
  console.log('  a building    '+r.bldL1+'h (was 48)   walls L3     '+r.bldWall3+'h (was 48)');
  console.log('  a road        '+r.road+'h (was 48)   one cell     '+r.march+'h (was 2.25)');
  console.log('  foot cross the whole world in '+r.worldDays+' days (was 2.72)');
  say(r.trainT1===6&&r.trainT2===12&&r.trainT3===20,'units are priced in hours by tier');
  say(r.bldL1===8&&r.bldWall3===24,'buildings cost more for a higher level instead of a flat 2 days');
  say(r.march===1.5,'a cell of open country takes 1.5 hours');
  console.log('');
  console.log('FEEL 4 — "army unit should not get wounded or tired"');
  say(r.cooldown===0,'the 6 hour pause after a fight is gone');
  say(r.readyAfterMarch,'an army that has just marched can fight at once');
  say(r.readyAfterFighting,'an army that has just fought can fight again at once');
  console.log('');
  console.log('FEEL 3 — "having AI in each and every land location is not a good idea"');
  console.log('  free armies standing in open country: '+r.freeFieldArmies+'  (v9.1 seeded about 195)');
  console.log('  free troops behind city walls: '+r.freeCityTroops+' across '+r.freeCities+' free cities');
  say(r.freeFieldArmies===0,'the countryside is empty');
  // v9.4: every crown now plays every game, so 48 of the 80 cities start owned and only 32 are
  // free, against 56 before. The same garrison over fewer cities is a smaller total. What is
  // worth asserting is the garrison PER CITY, which is the thing v9.2 actually changed.
  say(r.freeCityTroops/Math.max(1,r.freeCities)>=15,
      'and those men are in the cities instead: '+(r.freeCityTroops/Math.max(1,r.freeCities)).toFixed(1)+' per free city');
  console.log('');
  console.log('BUG 2 — "when zooming out, units should show total count"');
  say(r.badgesZoomedOut===1,'zoomed out past the chip line, one badge (got '+r.badgesZoomedOut+')');
  say(r.totalZoomedOut==='8','and it reads the stack total, 8 (got '+r.totalZoomedOut+')');
  say(r.badgesZoomedIn>=2,'zoomed in, still a chip per unit type (got '+r.badgesZoomedIn+')');
  console.log('');
  console.log('THE NEW UNIT ART');
  say(r.defsInPage,'the shared gradients are in the page');
  say(r.artCloseHasGradient,'zoomed in on a front, figures are shaded');
  say(!r.artFarHasGradient,'whole world on screen, figures are flat (the speed gate)');
  say(r.panelArtShaded,'panel and card icons are always the shaded art');
  console.log('');
  console.log('ADD TO HOME SCREEN');
  say(r.hasManifest,'a manifest is attached');
  say(r.manName==='Age of Crowns','it names the game ('+r.manName+')');
  say(r.manDisplay==='standalone','it opens standalone, with no browser bars');
  say(r.manStartAbs,'start_url is absolute, so the installed icon opens the game');
  say(r.manIcons===3&&r.manIconIsPng,'3 real PNG icons, rasterised at load from 1.4KB of SVG');
  say(r.appleIcon&&r.appleCapable,'iOS has its touch icon and its meta tags');
  console.log('');
  say(errs.length===0,'no page errors'+(errs.length?': '+errs.slice(0,2).join(' | '):''));

  await p.screenshot({path:'/home/claude/age-of-crowns/docs/shots/v92-phone.png'});
  await b.close();
  const bad=ok.filter(x=>!x).length;
  console.log('');
  console.log(bad?('  '+bad+' FAILED'):'  ALL GREEN');
  process.exit(bad?1:0);
})();
